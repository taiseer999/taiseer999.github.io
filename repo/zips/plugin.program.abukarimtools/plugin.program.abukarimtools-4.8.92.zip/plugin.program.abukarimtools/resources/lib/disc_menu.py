# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2025-2026 Taiseer (Abukarim) - AB Tools, see LICENSE.txt
"""
disc_menu.py - ABUKARIM TOOLS (4.7.36)

The runtime half of Toggles > "AF3: Disc Menu for ISO Streams" (skin bool
abk.discmenu, af3_discmenu_toggle.py). Two AF3 OSD buttons call it while a
Blu-ray ISO plays from a stream (http... .iso):

  go=menu    the ISO plays as the main movie (normal AF3 player): reopen the
             same ISO in disc-menu mode (HDMV / BD-J menus).
  go=normal  the ISO plays in disc-menu mode: back to the main movie in the
             normal player, at the same point.

Kodi paths (xbmc/utils/URIUtils.cpp, GetBlurayPath / GetBlurayMenuPath):
  udf://<enc iso url>/                       the ISO opened as a disc
  bluray://<enc udf path>/menu               disc-menu mode
  bluray://<enc udf path>/root/main          directory: the main movie playlist
  bluray://<enc udf path>/BDMV/PLAYLIST/00800.mpls   one playlist = main movie
The new item carries the ListItem property playlist_chosen=true, so Kodi's own
"Blu-ray playback mode" setting (Settings > Player > Discs) does not turn the
path into something else again (ApplicationPlay GetMenuDecisions).
"""
import hashlib
import os
import stat
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.i18n import T

TITLE = 'ABUKARIM TOOLS'
_HOME = 10000
_POS_PROP = 'abk.discmenu.pos.%s'
_RFC1738 = '-._!()'                 # what Kodi's URIUtils::URLEncode leaves alone
_MAIN_MIN = 40 * 60                 # a title this long is the movie, not a menu loop


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[AbukarimTools DiscMenu] %s' % msg, level)


def _enc(text):
    """Kodi's URIUtils::URLEncode (RFC1738 set, lower-case hex)."""
    out = []
    for b in text.encode('utf-8'):
        c = chr(b)
        if c.isascii() and (c.isalnum() or c in _RFC1738):
            out.append(c)
        else:
            out.append('%%%02x' % b)
    return ''.join(out)


def _host(url, proto):
    """Decoded host part of proto://<host>/... (Kodi encodes nested URLs there)."""
    rest = url[len(proto):]
    return unquote(rest.split('/', 1)[0])


def _iso_url(path):
    """The stream URL of the ISO behind a raw / udf:// / bluray:// path, or a
    disc served by disc_stream (4.8.79: also links with no .iso in them that
    the rescue opened as a disc - Home abk.disc.source)."""
    from resources.lib import disc_stream
    key = disc_stream.key_of(path)
    if key:
        disc = disc_stream.disc_for(key)
        return (disc or {}).get('link', '')
    source = xbmcgui.Window(_HOME).getProperty(disc_stream.SOURCE_PROP)
    for _ in range(3):
        low = path.lower()
        if low.startswith('bluray://'):
            path = _host(path, 'bluray://')
        elif low.startswith('udf://'):
            path = _host(path, 'udf://')
        else:
            break
    low = path.lower()
    if low.startswith('http') and '.iso' in low:
        return path
    if source and low.startswith('http') and path.split('|', 1)[0] == source.split('|', 1)[0]:
        return source
    return ''


def _bluray_base(iso):
    """bluray://<enc udf://<enc iso>/>/ - as URIUtils::GetBlurayPath builds it."""
    return 'bluray://%s/' % _enc('udf://%s/' % _enc(iso))


def _playing_path():
    for label in ('Player.Filenameandpath',):
        p = xbmc.getInfoLabel(label)
        if p and _iso_url(p):
            return p
    try:
        p = xbmc.Player().getPlayingFile()
        if p and _iso_url(p):
            return p
    except Exception:
        pass
    return ''


def _key(iso):
    return hashlib.md5(iso.encode('utf-8')).hexdigest()[:12]


def _listitem(path, start=0.0, chosen=True):
    """A ListItem for path that keeps what the OSD shows (title, art, ids)."""
    gi = xbmc.getInfoLabel
    title = gi('VideoPlayer.Title') or gi('Player.Title')
    li = xbmcgui.ListItem(label=title, path=path, offscreen=True)
    try:
        src = xbmc.Player().getVideoInfoTag()
    except Exception:
        src = None
    tag = li.getVideoInfoTag()

    def _set(fn, *val):
        try:
            if all(v not in (None, '', -1, 0) for v in val):
                fn(*val)
        except Exception:
            pass

    if src is not None:
        _set(tag.setTitle, src.getTitle() or title)
        _set(tag.setOriginalTitle, src.getOriginalTitle())
        _set(tag.setMediaType, src.getMediaType())
        _set(tag.setYear, src.getYear())
        _set(tag.setPlot, src.getPlot())
        _set(tag.setTvShowTitle, src.getTVShowTitle())
        _set(tag.setSeason, src.getSeason())
        _set(tag.setEpisode, src.getEpisode())
        _set(tag.setIMDBNumber, src.getIMDBNumber())
        _set(tag.setGenres, src.getGenres())
        _set(tag.setDuration, src.getDuration())
        try:
            ids = {}
            for k in ('tmdb', 'imdb', 'tvdb', 'trakt'):
                v = src.getUniqueID(k)
                if v:
                    ids[k] = v
            if ids:
                tag.setUniqueIDs(ids, 'tmdb' if 'tmdb' in ids else list(ids)[0])
        except Exception:
            pass
    else:
        _set(tag.setTitle, title)
    art = {}
    for k in ('poster', 'fanart', 'thumb', 'clearlogo', 'landscape', 'banner',
              'keyart', 'discart', 'tvshow.poster', 'tvshow.fanart', 'tvshow.clearlogo'):
        v = gi('Player.Art(%s)' % k)
        if v:
            art[k] = v
    if art:
        li.setArt(art)
    # Kodi's "Blu-ray playback mode" must not rewrite the path we chose
    if chosen:
        li.setProperty('playlist_chosen', 'true')
    if start > 1:
        li.setProperty('StartOffset', '%.3f' % start)
    return li


def _main_playlist(base):
    """bluray://.../BDMV/PLAYLIST/xxxxx.mpls of the main movie, or ''."""
    for sub in ('root/main', 'root/titles'):
        try:
            _dirs, files = xbmcvfs.listdir(base + sub)
        except Exception as e:
            _log('listdir %s failed: %s' % (sub, e), xbmc.LOGWARNING)
            continue
        for f in files:
            if f.lower().endswith('.mpls'):
                _log('main movie playlist (%s): %s' % (sub, f))
                return base + 'BDMV/PLAYLIST/' + f
    return ''


def _play(path, li):
    xbmc.executebuiltin('Dialog.Close(videoosd,true)')
    xbmc.Player().play(path, li)


def _busy(on):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)' if on
                        else 'Dialog.Close(busydialognocancel,true)')


# ── Java for BD-J menus (4.7.38) ──
# Most UHD and many newer Blu-rays have Java (BD-J) menus; libbluray runs them
# with the JRE from Team CoreELEC's "JRE for BD-J menus" (tools.jre.zulu).
# HDMV menus need nothing. The add-on's profile.d/jre.profile sets JAVA_HOME
# and LIBBLURAY_CP at boot only, so right after an install libbluray would
# not find Java until a reboot - the same two variables are put into Kodi's
# process environment here (os.environ -> putenv), which libbluray reads
# when it starts BD-J.
_JRE = 'tools.jre.zulu'
_JRE_REPO = 'repository.taiseer'          # fallback source: Taiseer repo zip
_JRE_ASKED = 'abk.discmenu.jre_asked'


def _jre_dir():
    return os.path.join(xbmcvfs.translatePath('special://home/addons/'), _JRE)


def _jre_present():
    return os.path.isfile(os.path.join(_jre_dir(), 'addon.xml'))


def _jre_install():
    """Kodi's installer (enabled repos) first, then the repository.taiseer zip."""
    from resources.lib import addon_portal as ap
    _busy(True)
    try:
        if ap._kodi_install(_JRE, timeout_ms=180000):
            return True
        _log('%s not in the enabled repos - trying %s' % (_JRE, _JRE_REPO), xbmc.LOGWARNING)
        try:
            url, ver = ap._resolve_zip_in_repo(_JRE_REPO, _JRE)
        except Exception as e:
            url, ver = None, ''
            _log('repo lookup failed: %s' % e, xbmc.LOGWARNING)
        if url and ap._install_zip(url, _JRE):
            _log('%s %s installed from %s' % (_JRE, ver, _JRE_REPO))
            return True
        return _jre_present()
    finally:
        _busy(False)


def _jre_fix_modes(root):
    """Python's zip extract drops the exec bits; Java needs them on its binaries."""
    jre = os.path.join(root, 'jre')
    for base, _dirs, files in os.walk(jre):
        for f in files:
            if base.endswith(os.sep + 'bin') or '.so' in f or f == 'jexec':
                fp = os.path.join(base, f)
                try:
                    mode = os.stat(fp).st_mode
                    if not mode & stat.S_IXUSR:
                        os.chmod(fp, mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
                except OSError:
                    pass


def _jre_env(root):
    root = root.rstrip('/\\')
    if os.environ.get('JAVA_HOME') != root:
        os.environ['JAVA_HOME'] = root
        _log('JAVA_HOME=%s (process env, no reboot needed)' % root)
    if not os.environ.get('LIBBLURAY_CP'):
        os.environ['LIBBLURAY_CP'] = root + '/'


def _ensure_jre():
    """Java ready for BD-J menus, or a clear note why not. Never blocks the
    menu itself - HDMV discs open without Java."""
    win = xbmcgui.Window(_HOME)
    if not _jre_present():
        if win.getProperty(_JRE_ASKED):
            return False                      # asked this session - no nagging
        win.setProperty(_JRE_ASKED, '1')
        if not xbmcgui.Dialog().yesno(TITLE, T(32110)):
            return False
        if not _jre_install():
            xbmcgui.Dialog().ok(TITLE, T(32111))
            return False
        xbmcgui.Dialog().notification(TITLE, T(32112), xbmcgui.NOTIFICATION_INFO, 3000)
    try:
        from resources.lib import addon_portal as ap
        ap._wait_registered(_JRE, timeout_ms=10000)
        ap._enable(_JRE)
    except Exception as e:
        _log('enable %s: %s' % (_JRE, e), xbmc.LOGWARNING)
    root = _jre_dir()
    _jre_fix_modes(root)
    _jre_env(root)
    return True


def _served(iso, playing=''):
    """4.8.79: away from CoreELEC / LibreELEC, Kodi hangs on a streamed udf://
    image - the disc is served as a folder by disc_stream instead.
    {'base', 'java', 'main', ...} or None."""
    from resources.lib import disc_stream
    key = disc_stream.key_of(playing)
    if key:
        disc = disc_stream.disc_info(key)
        if disc:
            return disc
    _busy(True)
    try:
        if iso.startswith('debrid:'):
            # 4.8.81: a whole disc in a debrid torrent (disc_debrid)
            from resources.lib import disc_debrid
            try:
                return disc_debrid.open_disc(disc_debrid.current_pick(), playing)
            except disc_debrid.DebridError as e:
                _log('debrid disc: %s' % e, xbmc.LOGWARNING)
                text = T(e.sid)
                if '%s' in text:
                    text = text % e.arg
                xbmcgui.Dialog().notification(TITLE, text, xbmcgui.NOTIFICATION_WARNING, 6000)
                return False
            except Exception as e:
                _log('debrid disc failed: %s' % e, xbmc.LOGWARNING)
                return None
        return disc_stream.open_image(iso)
    finally:
        _busy(False)


def _on_coreelec():
    from resources.lib import disc_stream
    return disc_stream.on_coreelec()


def _to_menu(iso, playing=''):
    player = xbmc.Player()
    try:
        pos = player.getTime()
    except Exception:
        pos = 0.0
    if _on_coreelec() and not iso.startswith('debrid:'):
        _ensure_jre()
        path = _bluray_base(iso) + 'menu'
    else:
        disc = _served(iso, playing)
        if disc is False:                   # already said why
            return
        if not disc:
            xbmcgui.Dialog().notification(TITLE, T(32271), xbmcgui.NOTIFICATION_WARNING, 4000)
            return
        if _on_coreelec():
            _ensure_jre()
        elif disc['java']:
            # libbluray without Java stops at the first Java title
            _log('Java (BD-J) menus - only CoreELEC / LibreELEC run them')
            xbmcgui.Dialog().notification(TITLE, T(32270), xbmcgui.NOTIFICATION_WARNING, 5000)
            return
        path = disc['base'] + 'menu'
    xbmcgui.Window(_HOME).setProperty(_POS_PROP % _key(iso), '%.3f' % pos)
    _log('to disc menu (left the main movie at %.0fs): %s' % (pos, path))
    xbmcgui.Dialog().notification(TITLE, T(32107), xbmcgui.NOTIFICATION_INFO, 2500)
    _play(path, _listitem(path))


def _to_normal(iso, playing=''):
    player = xbmc.Player()
    win = xbmcgui.Window(_HOME)
    key = _POS_PROP % _key(iso)
    # Started the movie from the disc menu? Then keep its place; otherwise
    # go back to where the main movie was left for the menu.
    start = 0.0
    try:
        cur, total = player.getTime(), player.getTotalTime()
        if total >= _MAIN_MIN and cur > 5:
            start = cur
    except Exception:
        pass
    if not start:
        try:
            start = float(win.getProperty(key) or 0)
        except ValueError:
            start = 0.0
    win.clearProperty(key)
    if _on_coreelec() and not iso.startswith('debrid:'):
        base = _bluray_base(iso)
        _busy(True)
        try:
            path = _main_playlist(base)
        finally:
            _busy(False)
    else:
        disc = _served(iso, playing)
        path = (disc['base'] + 'BDMV/PLAYLIST/' + disc['main']) if disc and disc.get('main') else ''
        if not path and iso.startswith('debrid:'):
            xbmcgui.Dialog().notification(TITLE, T(32109), xbmcgui.NOTIFICATION_WARNING, 4000)
            return
    if not path:
        # Not readable here: the plain ISO as the stream add-on played it
        # (Kodi's own Blu-ray playback mode decides; no resume point).
        _log('main movie playlist not found - plain ISO', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(TITLE, T(32109), xbmcgui.NOTIFICATION_WARNING, 4000)
        _play(iso, _listitem(iso, chosen=False))
        return
    _log('to normal player at %.0fs: %s' % (start, path))
    xbmcgui.Dialog().notification(TITLE, T(32108), xbmcgui.NOTIFICATION_INFO, 2500)
    _play(path, _listitem(path, start))


def run(go):
    if not xbmc.getCondVisibility('Player.HasVideo'):
        return
    path = _playing_path()
    iso = _iso_url(path) if path else ''
    if not iso:
        # 4.8.81: one .m2ts of a whole disc in a debrid torrent picked in Search All
        from resources.lib import disc_debrid
        try:
            raw = xbmc.Player().getPlayingFile() or ''
        except Exception:
            raw = ''
        pick = disc_debrid.current_pick()
        if go == 'menu' and pick and disc_debrid.is_disc_part(raw):
            path, iso = raw, disc_debrid.source_id(pick)
    if not iso:
        _log('not an ISO stream: %r' % path)
        xbmcgui.Dialog().notification(TITLE, T(32106), xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    if go == 'normal':
        _to_normal(iso, path)
    else:
        _to_menu(iso, path)
