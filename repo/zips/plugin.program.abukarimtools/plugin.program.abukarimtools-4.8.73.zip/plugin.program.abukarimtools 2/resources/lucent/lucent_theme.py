# -*- coding: utf-8 -*-
# Lucent theme helper - injected by AB Tools (plugin.program.abukarimtools).
# LUCENT_HELPER_VERSION = 14
#
# Normalises each add-on's own source-list and meta properties into one shared
# 'lucent.*' property set, so a single Lucent window layout works for Fen Light,
# Red Light, POV and Umbrella. Everything here is best-effort: any failure is
# swallowed so the add-on's own window always keeps working.
import os
import re

# Property names each add-on already puts on its source list items.
_ITEM_KEYS = {
	'fen': {'name': 'name', 'quality': 'quality', 'provider': 'provider', 'type': 'source_type',
			'size': 'size_label', 'site': 'source_site', 'info': 'extraInfo', 'icon': 'provider_icon'},
	'pov': {'name': 'tikiskins.name', 'quality': 'tikiskins.quality', 'provider': 'tikiskins.provider',
			'type': 'tikiskins.source_type', 'size': 'tikiskins.size_label', 'site': 'tikiskins.source_site',
			'info': 'tikiskins.extra_info', 'icon': 'tikiskins.provider_icon'},
	'umbrella': {'name': 'umbrella.name', 'quality': 'umbrella.quality', 'provider': 'umbrella.debrid',
				'type': 'umbrella.source', 'size': 'umbrella.size_label', 'site': 'umbrella.provider',
				'info': 'umbrella.extra_info', 'icon': ''},
}

# Release tag (as any of the add-ons spell it) -> Lucent badge file name.
_BADGES = {
	'DV': 'DV', 'D/VISION': 'DV', 'DOLBY-VISION': 'DV', 'DOLBY VISION': 'DV', 'DOLBY_VISION': 'DV', 'DOVI': 'DV',
	'DV2': 'DV2', 'DOVI2': 'DV2', 'DV 2': 'DV2', 'DOLBY VISION 2': 'DV2', 'DOLBY-VISION-2': 'DV2', 'DOLBY_VISION_2': 'DV2',
	'HDR': 'HDR', 'HDR_TRUE': 'HDR',
	'HDR10': 'HDR10', 'HDR10+': 'HDR10+', 'HDR10PLUS': 'HDR10+', 'HDR10_PLUS': 'HDR10+', 'HDR10P': 'HDR10+',
	'HLG': 'HLG', 'SDR': 'SDR', 'HYBRID': 'HYBRID',
	'HEVC': 'HEVC', 'H265': 'HEVC', 'H.265': 'HEVC', 'X265': 'HEVC', 'CODEC_H265': 'HEVC',
	'AVC': 'AVC', 'H264': 'AVC', 'H.264': 'AVC', 'X264': 'AVC', 'CODEC_H264': 'AVC',
	'AV1': 'AV1', 'CODEC_AV1': 'AV1', 'VP9': 'VP9', 'XVID': 'XVID', 'DIVX': 'DIVX',
	'MPEG': 'MPEG', 'WMV': 'WMV', 'MP4': 'MP4',
	'3D': '3D', 'VIDEO_3D': '3D',
	'REMUX': 'REMUX', 'BLURAY': 'BLURAY', 'BLU-RAY': 'BLURAY', 'BDRIP': 'BLURAY',
	'WEB': 'WEB', 'WEB-DL': 'WEB', 'WEBDL': 'WEB', 'WEBRIP': 'WEB',
	'HDTV': 'HDTV', 'PDTV': 'PDTV', 'HDRIP': 'HD-RIP', 'HD-RIP': 'HD-RIP', 'DVD': 'DVDRIP', 'DVDRIP': 'DVDRIP',
	'CAM': 'CAM', 'SCR': 'SCR', 'TELE': 'CAM', 'HC': 'HC',
	'ATMOS': 'ATMOS',
	'TRUEHD': 'TRUEHD', 'DOLBY-TRUEHD': 'TRUEHD', 'DOLBY_TRUEHD': 'TRUEHD', 'DOLBY TRUEHD': 'TRUEHD',
	'DTS-X': 'DTS-X', 'DTSX': 'DTS-X', 'DTS:X': 'DTS-X',
	'DTS-HD MA': 'DTS-HDMA', 'DTS-HDMA': 'DTS-HDMA', 'DTS_HDMA': 'DTS-HDMA', 'DTS-HD HR': 'DTS-HDHR', 'DTS-HDHR': 'DTS-HDHR',
	'DTS-HD': 'DTS-HD', 'DTS_HD': 'DTS-HD', 'DTS': 'DTS', 'DTS_PLAIN': 'DTS',
	'DD+': 'DD+', 'DDP': 'DD+', 'EAC3': 'DD+', 'E-AC3': 'DD+', 'DOLBY_DIGITALPLUS': 'DD+', 'DOLBYDIGITALPLUS': 'DD+',
	'DD': 'DD', 'DD-EX': 'DD', 'AC3': 'DD', 'DOLBYDIGITAL': 'DD', 'DOLBY_DIGITALEX': 'DD',
	'PCM': 'PCM', 'LPCM': 'PCM', 'FLAC': 'FLAC',
	'AAC': 'AAC', 'MP3': 'MP3', 'OPUS': 'OPUS', 'WMA': 'WMA',
	'8CH': '7.1', '7.1': '7.1', 'AUDIO_8CH': '7.1', '7CH': '6.1', '6.1': '6.1', 'AUDIO_7CH': '6.1',
	'6CH': '5.1', '5.1': '5.1', 'AUDIO_6CH': '5.1', '2CH': '2.0', '2.0': '2.0', 'AUDIO_2CH': '2.0',
	'1CH': '1.0', '1.0': '1.0', 'MONO': '1.0', 'AUDIO_1CH': '1.0',
}
# Display order: release type, picture, codec, audio, channels, extras.
_ORDER = ('CAM', 'SCR', 'HC', 'REMUX', 'BLURAY', 'WEB', 'HDTV', 'PDTV', 'HD-RIP', 'DVDRIP',
		'DV2', 'DV', 'HDR10+', 'HDR10', 'HDR', 'HLG', 'HYBRID', 'SDR', 'HEVC', 'AV1', 'AVC', 'VP9', 'XVID', 'DIVX', 'MPEG', 'WMV', 'MP4',
		'ATMOS', 'TRUEHD', 'DTS-X', 'DTS-HDMA', 'DTS-HDHR', 'DTS-HD', 'DTS', 'DD+', 'DD', 'PCM', 'FLAC', 'AAC', 'OPUS', 'MP3', 'WMA',
		'7.1', '6.1', '5.1', '2.0', '1.0', '3D')
_RANK = {b: n for n, b in enumerate(_ORDER)}
# Within a family only the best badge is kept (DTS-X beats DTS-HD beats DTS ...).
_FAMILY = {'DTS-X': 'dts', 'DTS-HDMA': 'dts', 'DTS-HDHR': 'dts', 'DTS-HD': 'dts', 'DTS': 'dts',
		'DD+': 'dd', 'DD': 'dd', '7.1': 'ch', '6.1': 'ch', '5.1': 'ch', '2.0': 'ch', '1.0': 'ch',
		'DV2': 'dv', 'DV': 'dv', 'HDR10+': 'hdr', 'HDR10': 'hdr', 'HDR': 'hdr', 'HLG': 'hdr',
		'REMUX': 'src', 'BLURAY': 'src', 'WEB': 'src', 'HDTV': 'src', 'PDTV': 'src', 'HD-RIP': 'src', 'DVDRIP': 'src'}
_MAX_BADGES = 7
_LOWQ = ('CAM', 'SCR', 'TELE', 'HC')
_TAG_RE = re.compile(r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|COLOR[^\]]*)\]', re.I)
_SPLIT_RE = re.compile(r'\s*[|/]\s*')


def _clean(text):
	try: return _TAG_RE.sub('', str(text or '')).strip()
	except Exception: return ''


# Dolby Vision 2 in a release name (no add-on parser has a tag for it yet).
_DV2_RE = re.compile(r'(?<![A-Z0-9])(?:DV2|DOVI2|DOLBY[ ._-]?VISION[ ._-]?2)(?![A-Z0-9])', re.I)


def badges(info, quality='', name=''):
	"""Ordered list of Lucent badge names for an info string (+ release name)."""
	found = []
	if name and _DV2_RE.search(_clean(name)): found.append('DV2')
	text = _clean(info).upper().replace('D/VISION', 'DV')
	for token in _SPLIT_RE.split(text):
		token = token.strip()
		if not token: continue
		badge = _BADGES.get(token)
		if badge is None: badge = _BADGES.get(token.replace(' ', '-'))
		if badge is None and token.endswith(' PACK'): continue
		if badge and badge not in found: found.append(badge)
	q = _clean(quality).upper()
	if q in ('CAM', 'SCR', 'TELE') and _BADGES[q] not in found: found.append(_BADGES[q])
	found.sort(key=lambda b: _RANK.get(b, 999))
	seen_family, result = set(), []
	for b in found:
		fam = _FAMILY.get(b)
		if fam:
			if fam in seen_family: continue
			seen_family.add(fam)
		result.append(b)
	return result[:_MAX_BADGES]


# AB Tools 4.8.50: the stream order of AB Tools Search All, for the add-on's own
# source window (called from the window's __init__ on its results list, in
# place, so the add-on's play / next-source fallback follows the same order):
# quality 4K > 1080p > 720p > SD (8K / 2160p / UHD count as 4K; CAM / SCR etc.
# after SD), biggest file first, the add-on's own order last. Uncached results, which
# Search All leaves out, go to the end.
_QRANK = {'4K': 0, '1080P': 1, '720P': 2, 'SD': 3}


def _sort_key(pair):
	pos, item = pair
	try:
		get = item.get
		q = _clean(get('quality') or 'SD').upper() or 'SD'
		if q in ('2160P', 'UHD', '8K'): q = '4K'
		group = q if q in _QRANK else 'SD'
		try: size = float(get('size') or 0)
		except Exception: size = 0.0
		uncached = 'Uncached' in str(get('cache_provider', ''))
		return (uncached, _QRANK[group], q != group, -size, pos)
	except Exception:
		return (True, 9, True, 0.0, pos)


def lucent_sort(results, meta=None):
	"""Sort the add-on's results list in place like Search All. meta: the
	window's meta (running time for the bitrate tile, 4.8.51)."""
	_set_runtime(meta)
	try:
		if not isinstance(results, list) or len(results) < 2: return results
		ordered = [item for _pos, item in sorted(enumerate(results), key=_sort_key)]
		results[:] = ordered
	except Exception as e:
		_log('sort: %s' % e)
	return results


# Approximate advance widths (px at 1080p) of a skin's font12. Text is fitted in
# Python because Kodi trims an overflowing label from the START when the GUI
# language is right-to-left (Arabic), which hid the first characters.
_TITLE_PX, _META_PX = 690, 690


def _px(text):
	w = 0.0
	for ch in text:
		if ch in ' .,:;|\'!': w += 7
		elif ch in '-_()[]/': w += 10
		elif ch.isdigit(): w += 15.5
		elif ch.isupper(): w += 17
		elif ch == '·': w += 8
		else: w += 13.5
	return w


def _fit(text, limit):
	if _px(text) <= limit: return text
	while text and _px(text + '…') > limit: text = text[:-1]
	return text.rstrip(' .-_') + '…'


# Resolution flag (Arctic Fuse 3 media/flags/color/resolution) per quality.
_RES = {'8K': '8k', '4K': '4k', '2160P': '4k', 'UHD': '4k', '1080P': '1080', '1080': '1080', 'FHD': '1080',
		'720P': '720', '720': '720', 'HD': '720', 'SD': '480', '480P': '480', '576P': '480'}
# Debrid / service icon (AB Wizard account manager artwork) per provider name.
_PROVIDERS = (('realdebrid', ('REAL-DEBRID', 'REALDEBRID', 'RD', 'RD_CLOUD', 'RD CLOUD')),
			('alldebrid', ('ALLDEBRID', 'AD', 'AD_CLOUD', 'AD CLOUD')),
			('premiumize', ('PREMIUMIZE', 'PREMIUMIZE.ME', 'PM', 'PM_CLOUD', 'PM CLOUD')),
			('torbox', ('TORBOX', 'TB', 'TB_CLOUD', 'TB CLOUD')),
			('offcloud', ('OFFCLOUD', 'OC', 'OC_CLOUD', 'OC CLOUD')),
			('easydebrid', ('EASYDEBRID', 'ED')),
			('easynews', ('EASYNEWS', 'EN')))
_PROVIDER_OF = {alias: icon for icon, aliases in _PROVIDERS for alias in aliases}


def _provider_icon(*names):
	for name in names:
		key = _clean(name).upper().strip()
		if key in _PROVIDER_OF: return 'lucent/providers_bw/%s.png' % _PROVIDER_OF[key]
		for alias, icon in _PROVIDER_OF.items():
			if len(alias) > 3 and alias in key: return 'lucent/providers_bw/%s.png' % icon
	return ''


# AB Tools > Toggles > Lucent Theme: "Colored resolution & service icons".
# Read from AB Tools' own state file (re-read at most every 5 s).
_COLORED = {'at': -99.0, 'on': True}
try:
	import threading
	_COLORED_LOCK = threading.Lock()
except Exception:
	_COLORED_LOCK = None


def _read_state():
	try:
		import json, os, xbmcvfs
		path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/'),
							'plugin.program.abukarimtools', 'lucent.json')
		with open(path, 'r', encoding='utf-8') as f:
			data = json.load(f)
		return data if isinstance(data, dict) else {}
	except Exception:
		return {}


def _read_colored():
	# AB Tools 4.6.0: coloured resolution flags / service icons removed - the
	# option is gone from Toggles > Glass Theme, always plain now
	return False


def _colored():
	"""Red Light builds its list items on several threads at once: the setting
	is read under a lock and the timestamp only moves AFTER the read, so no
	thread can see a fresh timestamp with a stale value (helper v6 bug: the
	first rows built in parallel kept the colored icons)."""
	import time
	if time.monotonic() - _COLORED['at'] < 5: return _COLORED['on']
	if _COLORED_LOCK is None:
		_COLORED['on'] = _read_colored(); _COLORED['at'] = time.monotonic()
		return _COLORED['on']
	with _COLORED_LOCK:
		if time.monotonic() - _COLORED['at'] >= 5:
			_COLORED['on'] = _read_colored()
			_COLORED['at'] = time.monotonic()
		return _COLORED['on']


# ───────────── Selected stream tiles (AB Tools 4.8.51) ─────────────
# The same 3 x 3 details as AB Tools Search All (ab_search._stream_specs):
# resolution, size, bitrate, video, HDR, audio, channels, release, service, read
# from the add-on's info string and the release name. Bitrate = size / running
# time; the running time comes from the window's meta (lucent_sort / window).
_RUNTIME = [0]
_SP_SEP = re.compile(r'[\s._\[\]()|/,]+')
_SP_RES = {'4K': ('4K', '3840 × 2160'), '1080P': ('1080p', '1920 × 1080'), '720P': ('720p', '1280 × 720'),
		'SD': ('SD', ''), 'CAM': ('CAM', ''), 'SCR': ('SCR', ''), 'TELE': ('TELESYNC', ''), 'HC': ('HC', '')}
_SP_REL = (('Remux', r'REMUX\b'), ('Blu-ray', r'\bBLU[- ]?RAY\b|\bBDRIP\b|\bBRRIP\b'),
		('WEB-DL', r'\bWEB[- ]?DL\b'), ('WEBRip', r'\bWEB[- ]?RIP\b'), ('WEB', r'\bWEB\b'),
		('HDTV', r'\bHDTV\b'), ('DVD', r'\bDVD(?:RIP)?\b'), ('HDRip', r'\bHD[- ]?RIP\b'))
_SP_VIDEO = (('AV1', r'\bAV1\b'), ('HEVC', r'\bHEVC\b|\b[HX][- ]?265\b'), ('AVC', r'\bAVC\b|\b[HX][- ]?264\b'),
		('VP9', r'\bVP9\b'), ('XviD', r'\bXVID\b'), ('MPEG-2', r'\bMPEG[- ]?2\b'))
_SP_AUDIO = (('TrueHD', r'\bTRUE[- ]?HD\b'), ('DTS:X', r'\bDTS[- ]?X\b|\bDTS:X\b'),
		('DTS-HD MA', r'\bDTS[- ]?HD[- ]?MA\b|\bDTS-HDMA\b'), ('DTS-HD', r'\bDTS[- ]?HD\b'), ('DTS', r'\bDTS\b'),
		('DD+', r'\bDDP|\bDD\+|\bE[- ]?AC[- ]?3\b|\bDOLBY[- ]?DIGITAL[- ]?PLUS\b|\bDOLBYDIGITALPLUS\b'),
		('DD', r'\bDD(?![A-Z+])|\bAC[- ]?3\b|\bDOLBY[- ]?DIGITAL\b'),
		('FLAC', r'\bFLAC\b'), ('PCM', r'\bL?PCM\b'), ('AAC', r'\bAAC'), ('Opus', r'\bOPUS\b'), ('MP3', r'\bMP3\b'))
_SP_AUDIO_LONG = {'TrueHD': 'Dolby TrueHD', 'DD+': 'Dolby Digital Plus', 'DD': 'Dolby Digital',
		'DTS-HD MA': 'Master Audio', 'DTS-HD': 'High Resolution', 'DTS:X': 'DTS:X'}
_SP_CH_TAG = {'8': '7.1', '7': '6.1', '6': '5.1', '2': '2.0', '1': '1.0'}
_SP_LANG = {'ENG': 'ENG', 'ENGLISH': 'ENG', 'ITA': 'ITA', 'ITALIAN': 'ITA', 'GER': 'GER', 'DEU': 'GER',
		'GERMAN': 'GER', 'FRE': 'FRE', 'FRA': 'FRE', 'FRENCH': 'FRE', 'VFF': 'FRE', 'SPA': 'SPA',
		'ESP': 'SPA', 'SPANISH': 'SPA', 'LATINO': 'LAT', 'RUS': 'RUS', 'RUSSIAN': 'RUS', 'UKR': 'UKR',
		'ARA': 'ARA', 'ARABIC': 'ARA', 'TUR': 'TUR', 'TURKISH': 'TUR', 'JPN': 'JPN', 'JAP': 'JPN',
		'JAPANESE': 'JPN', 'KOR': 'KOR', 'KOREAN': 'KOR', 'HIN': 'HIN', 'HINDI': 'HIN', 'POR': 'POR',
		'POL': 'POL', 'CHI': 'CHI', 'MULTI': 'MULTI', 'DUAL': 'DUAL'}
_SP_GROUP = re.compile(r'-([A-Za-z0-9]{2,15})(?:\.(?:mkv|mp4|avi|ts|m2ts|iso))?\s*$')
_SP_PACK = re.compile(r'\b(?:COMPLETE|SEASONS?[ ._-]?\d|S\d{1,2}(?![ ._-]?E\d))\b', re.I)
_SP_SIZE = re.compile(r'([\d.,]+)\s*([KMGT])I?B', re.I)
_SP_PRETTY = {'ALLDEBRID': 'AllDebrid', 'AD': 'AllDebrid', 'REAL-DEBRID': 'Real-Debrid', 'REALDEBRID': 'Real-Debrid',
		'RD': 'Real-Debrid', 'TORBOX': 'TorBox', 'TB': 'TorBox', 'PREMIUMIZE': 'Premiumize', 'PM': 'Premiumize',
		'OFFCLOUD': 'Offcloud', 'OC': 'Offcloud', 'EASYNEWS': 'Easynews', 'EN': 'Easynews',
		'EASYDEBRID': 'EasyDebrid', 'ED': 'EasyDebrid', 'DEBRID-LINK': 'Debrid-Link', 'DEBRIDLINK': 'Debrid-Link'}
_SP_KEYS = ('res', 'size', 'rate', 'video', 'hdr', 'audio', 'ch', 'rel', 'svc')
_SP_LABELS = (('heading', 'Selected stream'), ('res', 'Resolution'), ('size', 'Size'), ('rate', 'Bitrate'),
		('video', 'Video'), ('hdr', 'HDR'), ('audio', 'Audio'), ('ch', 'Channels'), ('rel', 'Release'),
		('svc', 'Service'))


def _sp_first(table, text):
	for label, rx in table:
		if re.search(rx, text): return label
	return ''


def _set_runtime(meta):
	"""Running time (minutes) of the title in this window; a new window with no
	running time clears the previous title's."""
	if meta is None: return
	try: _RUNTIME[0] = _minutes(meta.get('duration') or meta.get('runtime')) or 0
	except Exception: _RUNTIME[0] = 0


def _size_gb(label):
	m = _SP_SIZE.search(label or '')
	if not m: return 0.0
	try: value = float(m.group(1).replace(',', '.'))
	except Exception: return 0.0
	return value * {'K': 1e-6, 'M': 1e-3, 'G': 1.0, 'T': 1e3}[m.group(2).upper()]


def stream_specs(name, info, quality, provider, size_label, site=''):
	"""lucent.sp_* properties (value + _sub per tile, and the languages line)."""
	name, info = _clean(name), _clean(info)
	raw = '%s | %s' % (info, name)
	up = raw.upper().replace('D/VISION', 'DOLBY-VISION')
	text = ' %s ' % _SP_SEP.sub(' ', up)
	q = _clean(quality).upper() or 'SD'
	if q in ('2160P', 'UHD', '8K'): q = '4K'
	out = {}
	out['res'], out['res_sub'] = _SP_RES.get(q, (q, ''))
	size = _clean(size_label)
	if size.upper() in ('N/A', 'NA', 'NONE', '0', '0 B'): size = ''
	pack = bool(_SP_PACK.search(name))
	out['size'], out['size_sub'] = size, (_t('Season pack') if pack else '')
	gb, minutes = _size_gb(size), _RUNTIME[0]
	rate = gb * 8000.0 / (minutes * 60.0) if (gb > 0 and minutes and not pack) else 0
	out['rate'] = ('~%d Mbps' % round(rate)) if rate else ''
	out['rate_sub'] = _t('estimated') if rate else ''
	out['video'] = _sp_first(_SP_VIDEO, text)
	m = re.search(r'\b(10|12)[- ]?BITS?\b|\bHI10P?\b', text)
	out['video_sub'] = ('%s-bit' % (m.group(1) or '10')) if m else ''
	dv = re.search(r'\b(?:DV|DOVI|DOLBY[- ]?VISION|DOLBYVISION)(?:[- ]?P?([4578]))?\b', text)
	dv2 = re.search(r'\b(?:DV2|DOVI2|DOLBY[- ]?VISION[- ]?2)\b', text)
	layer = ('HDR10+' if re.search(r'\bHDR10(?:\+|PLUS|P)', text) else
			'HDR10' if re.search(r'\bHDR10\b', text) else
			'HDR' if re.search(r'\bHDR\b', text) else
			'HLG' if re.search(r'\bHLG\b', text) else '')
	if dv2 or dv:
		out['hdr'] = 'Dolby Vision 2' if dv2 else 'Dolby Vision'
		bits = []
		if dv and dv.group(1): bits.append('P%s' % dv.group(1))
		if layer: bits.append(layer)
		elif re.search(r'\bHYBRID\b', text): bits.append('Hybrid')
		out['hdr_sub'] = ' · '.join(bits)
	elif layer: out['hdr'], out['hdr_sub'] = layer, ''
	elif re.search(r'\bSDR\b', text): out['hdr'], out['hdr_sub'] = 'SDR', ''
	else: out['hdr'] = out['hdr_sub'] = ''
	codec = _sp_first(_SP_AUDIO, text)
	atmos = bool(re.search(r'\bATMOS\b', text))
	if codec:
		out['audio'] = codec
		out['audio_sub'] = 'Dolby Atmos' if atmos else _SP_AUDIO_LONG.get(codec, '')
	else:
		out['audio'], out['audio_sub'] = ('Dolby Atmos' if atmos else ''), ''
	ch = ''
	m = re.search(r'(?<![\d.])([1-9])[ ._]([01])(?![\d])', raw)
	if m and m.group(1) in '125678': ch = '%s.%s' % (m.group(1), m.group(2))
	if not ch:
		m = re.search(r'\b(?:AUDIO_)?([12678])CH\b', up)
		ch = _SP_CH_TAG.get(m.group(1), '') if m else ''
	out['ch'] = ch
	out['ch_sub'] = (_t('Surround') if ch[:1] in '5678' else _t('Stereo') if ch == '2.0'
			else _t('Mono') if ch == '1.0' else '') if ch else ''
	rel = _sp_first(_SP_REL, text)
	if not rel and q in ('CAM', 'SCR', 'TELE', 'HC'): rel = _SP_RES[q][0]
	out['rel'] = rel
	g = _SP_GROUP.search(name)
	out['rel_sub'] = g.group(1) if g and not re.match(r'^(?:DL|RIP|HD|X|MA|\d+)$', g.group(1), re.I) else ''
	prov = _clean(provider)
	up_p = prov.upper().replace(' ', '')
	out['svc'] = _SP_PRETTY.get(up_p, prov if up_p not in ('N/A', 'NA', 'NONE') else '')
	site = _clean(site)
	out['svc_sub'] = site if site and site.upper() not in ('N/A', 'NA', 'NONE') and site.upper() != up_p else ''
	langs = []
	for tok in text.split():
		code = _SP_LANG.get(tok.strip('-+'))
		if code and code not in langs: langs.append(code)
	out['lang'] = '  ·  '.join(langs[:5])
	return dict(('lucent.sp_%s' % k, v) for k, v in out.items())


def lucent_item(listitem, profile):
	"""Add lucent.* properties to one source list item (reads the add-on's own ones)."""
	try:
		keys = _ITEM_KEYS[profile]
		get = listitem.getProperty
		name = _clean(get(keys['name']))
		quality = _clean(get(keys['quality'])).upper()
		provider = _clean(get(keys['provider']))
		source_type = _clean(get(keys['type']))
		size = _clean(get(keys['size']))
		site = _clean(get(keys['site']))
		meta = []
		for part in (provider, source_type, size, site):
			if not part or part.upper() in ('N/A', 'NA', 'NONE'): continue
			if any(part.upper() in m.upper() or m.upper() in part.upper() for m in meta): continue
			meta.append(part)
		while len(meta) > 1 and _px('  ·  '.join(meta).upper()) > _META_PX: meta.pop()
		props = {'lucent.title': _fit(name, _TITLE_PX), 'lucent.quality': quality or 'SD',
				'lucent.meta': _fit('  ·  '.join(meta), _META_PX),
				'lucent.lowq': 'true' if quality in _LOWQ else '',
				'lucent.uncached': 'true' if 'UNCACHED' in source_type.upper() else '',
				'lucent.res': '', 'lucent.icon': ''}
		# AB Tools 4.6.1: monochrome service icon (RD / AD / PM ...), never a
		# coloured resolution flag
		props['lucent.icon'] = _provider_icon(provider, site)
		if not props['lucent.icon'] and keys['icon']:
			props['lucent.icon'] = get(keys['icon'])     # the add-on's own provider icon
		found = badges(get(keys['info']), quality, get(keys['name']))
		for n in range(_MAX_BADGES):
			props['lucent.badge_%d' % (n + 1)] = found[n] if n < len(found) else ''
		# AB Tools 4.8.51: the selected-stream tiles
		try: props.update(stream_specs(get(keys['name']), get(keys['info']), quality, provider, size, site))
		except Exception: pass
		listitem.setProperties(props)
	except Exception:
		pass


def _num(value):
	try: return int(value)
	except Exception: return None


def _from_focused_item(meta):
	"""Logo / rating / MPAA / genre of the focused Kodi item - only when its
	TMDb or IMDb id is the one being played (Umbrella started from TMDbHelper
	gets a slim meta without them)."""
	try:
		import xbmc
		info = xbmc.getInfoLabel
		ids = set()
		for k in ('tmdb', 'tmdb_id', 'imdb', 'imdb_id', 'imdbnumber'):
			v = str(meta.get(k) or '').strip()
			if v and v not in ('0', 'None'): ids.add(v)
		if not ids: return {}
		seen = {info(i).strip() for i in ('ListItem.UniqueID(tmdb)', 'ListItem.UniqueID(imdb)', 'ListItem.IMDBNumber',
				'ListItem.UniqueID(tvshow.tmdb)', 'ListItem.Property(tvshow.tmdb_id)', 'ListItem.Property(tmdb_id)')}
		if not ids & (seen - {''}): return {}
		return {'clearlogo': info('ListItem.Art(clearlogo)') or info('ListItem.Art(tvshow.clearlogo)'),
				'rating': info('ListItem.Rating'), 'mpaa': info('ListItem.Mpaa'), 'genre': info('ListItem.Genre').replace(' / ', ', '),
				'year': info('ListItem.Year'), 'fanart': info('ListItem.Art(fanart)')}
	except Exception:
		return {}


_COUNTS_RE = re.compile(r'4K:\s*(\d+)\s*\|\s*1080p:\s*(\d+)\s*\|\s*720p:\s*(\d+)\s*\|\s*SD:\s*(\d+)(?:\s*\|\s*Total:\s*(\d+))?', re.I)


def lucent_progress(window, content, percent=0):
	"""Umbrella / POV progress: pull the 4K/1080p/720p/SD counts out of the text
	into lucent.c_* properties (shown as tiles) and return the rest of the text."""
	try:
		text = str(content or '')
		lines = re.split(r'\[CR\]|\n', text)
		totals, kept, found = [0, 0, 0, 0], [], False
		for line in lines:
			m = _COUNTS_RE.search(_clean(line))
			if m:
				found = True
				for n in range(4): totals[n] += int(m.group(n + 1))
			else:
				kept.append(line)
		if found: window._lucent_counts_seen = True
		seen = getattr(window, '_lucent_counts_seen', False)
		window.setProperty('lucent.counts', 'true' if found else '')
		if found:
			for key, value in zip(('c_4k', 'c_1080p', 'c_720p', 'c_sd'), totals):
				window.setProperty('lucent.' + key, str(value))
			window.setProperty('lucent.c_total', str(sum(totals)))
		window.setProperty('lucent.heading', _t('Searching for streams') if found else _t('Opening stream'))
		try: window.setProperty('lucent.percent', str(int(float(percent))))
		except Exception: pass
		if not found: return content
		while kept and not _clean(kept[0]): kept.pop(0)
		return '[CR]'.join(kept)
	except Exception:
		return content


def lucent_window(window, meta, fanart='', clearlogo=None):
	"""Add lucent.* title/meta properties to a results or progress window."""
	try:
		meta = dict(meta or {})
		extra = {}
		if not (clearlogo or meta.get('clearlogo')) or not meta.get('rating') or not meta.get('mpaa'):
			extra = _from_focused_item(meta)
		for k, v in extra.items():
			if v and not meta.get(k): meta[k] = v
		if not clearlogo and extra.get('clearlogo'): clearlogo = extra['clearlogo']
		get = meta.get
		season, episode = _num(get('season')), _num(get('episode'))
		is_episode = season is not None and episode is not None and get('media_type', get('mediatype', 'episode')) != 'movie'
		if is_episode and 'ep_name' in meta:
			show, ep_title = get('title') or '', get('ep_name') or ''
		elif is_episode and get('tvshowtitle'):
			show, ep_title = get('tvshowtitle') or '', get('title') or ''
		else:
			show, ep_title = get('title') or get('tvshowtitle') or '', ''
		year = str(get('year') or '').strip()
		if year in ('0', 'None'): year = ''
		try:
			rating = float(get('rating') or 0)
			rating = '%.1f' % rating if rating > 0 else ''
		except Exception: rating = ''
		mpaa = str(get('mpaa') or '').strip()
		if mpaa.upper() in ('NA', 'N/A', 'NONE', 'NR', 'NOT RATED'): mpaa = ''
		genre = get('genre') or ''
		if isinstance(genre, (list, tuple)): genre = ', '.join(str(i) for i in genre[:3])
		plot = get('plot') or get('tvshow_plot') or ''
		ep_code = 'S%02d · E%02d' % (season, episode) if is_episode else ''
		subtitle = '   '.join(i for i in (ep_code, ep_title) if i) if is_episode else '  ·  '.join(i for i in (year, mpaa, genre) if i)
		window.setProperty('lucent.show_title', _clean(show))
		window.setProperty('lucent.ep_code', ep_code)
		window.setProperty('lucent.ep_title', _clean(ep_title))
		window.setProperty('lucent.year', year)
		window.setProperty('lucent.rating', rating)
		window.setProperty('lucent.mpaa', mpaa)
		window.setProperty('lucent.genre', _clean(genre))
		window.setProperty('lucent.plot', _clean(plot))
		window.setProperty('lucent.subtitle', _clean(subtitle))
		window.setProperty('lucent.fanart', fanart or get('fanart') or '')
		window.setProperty('lucent.clearlogo', clearlogo if clearlogo is not None else (get('clearlogo') or ''))
		# 4.8.4: Fen Light+ style lines - "year | running time | ends at" and
		# "certificate | genres | rating" (Umbrella progress window)
		line1, line2 = [year] if year else [], []
		minutes = _minutes(get('duration') or get('runtime'))
		if minutes:
			line1.append(_t('%dh %dm') % (minutes // 60, minutes % 60) if minutes >= 60 else _t('%dm') % minutes)
			import time as _time
			line1.append(_t('Ends at %s') % _time.strftime('%H:%M', _time.localtime(_time.time() + minutes * 60)))
		for v in (mpaa, _clean(str(genre).replace(' / ', ', ')), rating):
			if v: line2.append(v)
		_set_runtime(meta)
		for key, text in _SP_LABELS: window.setProperty('lucent.sl_%s' % key, _t(text))   # 4.8.51
		window.setProperty('lucent.line1', '  |  '.join(line1))
		window.setProperty('lucent.line2', '  |  '.join(line2))
	except Exception:
		pass


# ───────────── Themed filter menu (lucent_select.xml, shipped by AB Tools) ─────────────
_AR = {'Filter results': 'تصفية النتائج', 'Show all results': 'عرض كل النتائج',
	'Show %s only': 'عرض %s فقط', 'Source: %s': 'المصدر: %s', 'Filter by title...': 'تصفية حسب العنوان...',
	'Filter by info (HDR, Atmos ...)...': 'تصفية حسب المعلومات (HDR وAtmos ...)...',
	'Filter by info': 'تصفية حسب المعلومات', 'Keywords (comma separated)': 'كلمات مفتاحية (مفصولة بفواصل)',
	'No results': 'لا توجد نتائج', 'Apply': 'تطبيق', '%s results': '%s نتيجة', '%d selected': 'المحدد: %d',
	'Choose one or more, then Apply': 'اختر عنصرًا أو أكثر ثم اضغط تطبيق', 'Title: %s': 'العنوان: %s',
	# 4.8.51: selected-stream tiles
	'Selected stream': 'المصدر المحدد', 'Resolution': 'الدقة', 'Size': 'الحجم', 'Bitrate': 'معدل البت',
	'Video': 'الفيديو', 'HDR': 'المدى الديناميكي', 'Audio': 'الصوت', 'Channels': 'القنوات',
	'Release': 'الإصدار', 'Service': 'الخدمة', 'estimated': 'تقديري', 'Surround': 'صوت محيطي',
	'Stereo': 'ستيريو', 'Mono': 'أحادي', 'Season pack': 'حزمة موسم'}


def _minutes(value):
	"""Running time in minutes from seconds (Kodi / Umbrella 'duration') or
	minutes (Search All 'runtime'); 0 when unknown."""
	try:
		v = float(str(value).strip())
	except Exception:
		return 0
	if v <= 0:
		return 0
	return int(round(v / 60.0)) if v > 600 else int(round(v))


def _t(text):
	try:
		import xbmc
		if xbmc.getLanguage(xbmc.ISO_639_1) == 'ar': return _AR.get(text, text)
	except Exception:
		pass
	return text


def _addon_root():
	# <add-on>/resources/lib/modules/lucent_theme.py
	return os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


_COUNT_RE = re.compile(r'^(.*?)\s*\|\s*(?:\[B\])?\s*(\d+)\s*(?:\[/B\])?\s*(?:Results?|نتيجة|نتائج)?\s*$', re.I)


def _split_count(label):
	m = _COUNT_RE.match(label or '')
	return (m.group(1).strip(), m.group(2)) if m else (label, '')


def lucent_select(heading, labels, subtitle='', multi=False, counts=None, live=None, icons=None, preselect=0):
	"""Themed replacement for Dialog().select / multiselect. Returns the picked
	index (-1 on Back) or, with multi=True, the list of picked indexes (None on
	Back). Falls back to Kodi's own dialog if the window can't be shown.
	live(checked_set) -> {index: count, None: count_of_all_checked} refreshes
	the multi-select counts after every tick."""
	import xbmcgui
	rows = []
	for n, lab in enumerate(labels):
		main, cnt = _split_count(lab)
		if counts and n < len(counts) and counts[n] is not None: cnt = str(counts[n])
		rows.append((main, cnt))
	path = _addon_root()
	if not os.path.isfile(os.path.join(path, 'resources', 'skins', 'Default', '1080i', 'lucent_select.xml')):
		d = xbmcgui.Dialog()
		return d.multiselect(heading, labels) if multi else d.select(heading, labels)

	class _Select(xbmcgui.WindowXMLDialog):
		def __init__(self, *a, **k):
			self.result = None if multi else -1
			self.checked = set()

		def onInit(self):
			self.setProperty('lucent.heading', heading)
			self.setProperty('lucent.subtitle', subtitle or (_t('Choose one or more, then Apply') if multi else ''))
			self.setProperty('lucent.multi', 'true' if multi else '')
			self.setProperty('lucent.icons', 'true' if icons else '')
			self.setProperty('lucent.rows', str(max(1, min(8, len(rows) + (1 if multi else 0)))))
			self.ctrl = self.getControl(5000)
			items = []
			if multi:
				li = xbmcgui.ListItem(_t('Apply'), '', offscreen=True)
				li.setProperty('lucent.kind', 'apply')
				items.append(li)
			for n, (main, cnt) in enumerate(rows):
				li = xbmcgui.ListItem(main, cnt, offscreen=True)
				if icons and n < len(icons) and icons[n]:
					li.setArt({'icon': icons[n][0] or '', 'thumb': icons[n][1] or ''})
				items.append(li)
			self.ctrl.addItems(items)
			self._focus()
			if preselect:
				try: self.ctrl.selectItem(preselect)
				except Exception: pass

		def _has_focus(self):
			try: return self.getFocusId() == 5000
			except Exception: return False

		def _focus(self):
			# Kodi can refuse focus while the list is still being laid out
			# ("Control 5000 ... can't focus"); with no focused control every
			# key - arrows, OK, Apply - is ignored. Retry until it takes.
			import xbmc
			for _ in range(40):
				try: self.setFocusId(5000)
				except Exception: pass
				if self._has_focus(): return
				xbmc.sleep(25)
			_log('select window: list never took focus')

		def onClick(self, control_id):
			if control_id != 5000: return
			pos = self.ctrl.getSelectedPosition()
			if not multi:
				self.result = pos
				return self.close()
			if pos == 0:
				self.result = sorted(self.checked)
				return self.close()
			n = pos - 1
			li = self.ctrl.getListItem(pos)
			if n in self.checked:
				self.checked.discard(n); li.setProperty('lucent.checked', '')
			else:
				self.checked.add(n); li.setProperty('lucent.checked', 'true')
			self.ctrl.getListItem(0).setLabel('%s (%d)' % (_t('Apply'), len(self.checked)) if self.checked else _t('Apply'))
			if live:
				try:
					fresh = live(set(self.checked))
					for i in range(len(rows)):
						if i in fresh: self.ctrl.getListItem(i + 1).setLabel2(str(fresh[i]))
					self.ctrl.getListItem(0).setLabel2(str(fresh.get(None, '')) if self.checked else '')
				except Exception as e:
					_log('live counts failed: %r' % e)

		def onAction(self, action):
			if action.getId() in _BACK:
				self.result = None if multi else -1
				self.close()
			elif not self._has_focus():
				self._focus()                    # recover a lost focus on any key

	try:
		win = _Select('lucent_select.xml', path, 'Default', '1080i')
		win.doModal()
		result = win.result
		del win
		return result
	except Exception as e:
		_log('themed select failed, using Kodi dialog: %r' % e)
		d = xbmcgui.Dialog()
		return d.multiselect(heading, labels) if multi else d.select(heading, labels)


# ───────────── Umbrella: RIGHT on the stream list opens a filter ─────────────
_RIGHT, _BACK = 2, (9, 10, 13, 92)
_Q_ORDER = ('4K', '1080P', '720P', 'SD', 'SCR', 'CAM')


def _apply_filter(window, list_id, items, info):
	ctrl = window.getControl(list_id)
	ctrl.reset()
	ctrl.addItems(items)
	window.item_list = items
	window.setProperty('umbrella.total_results', str(len(items)))
	window.setProperty('lucent.filter_info', info)
	try: window.setFocusId(list_id); ctrl.selectItem(0)
	except Exception: pass


def lucent_filter(window, action_id, list_id):
	"""Umbrella result windows: RIGHT on the list -> filter menu, BACK -> clear.
	Returns True when the action was handled here."""
	try:
		full = getattr(window, '_lucent_full', None)
		if action_id in _BACK and full is not None:
			window._lucent_full = None
			_apply_filter(window, list_id, full, '')
			return True
		if action_id != _RIGHT or window.getFocusId() != list_id: return False
		import xbmcgui
		dialog = xbmcgui.Dialog()
		items = full if full is not None else list(window.item_list)
		if not items: return True
		get = lambda li, k: _clean(li.getProperty(k))
		qualities = sorted({get(i, 'umbrella.quality').upper() for i in items} - {''},
						key=lambda q: _Q_ORDER.index(q) if q in _Q_ORDER else 99)
		services = sorted({get(i, 'umbrella.debrid') for i in items} - {''})
		sites = sorted({get(i, 'umbrella.provider') for i in items} - {''})
		count = lambda key, v: sum(1 for i in items if get(i, key).upper() == v.upper())
		choices = [(_t('Show %s only') % q, 'quality', q, count('umbrella.quality', q)) for q in qualities]
		choices += [(_t('Show %s only') % d, 'debrid', d, count('umbrella.debrid', d)) for d in services]
		choices += [(_t('Source: %s') % p, 'site', p, count('umbrella.provider', p)) for p in sites]
		choices += [(_t('Filter by title...'), 'title', '', None), (_t('Filter by info (HDR, Atmos ...)...'), 'info', '', None)]
		if full is not None: choices.insert(0, (_t('Show all results'), 'all', '', len(full)))
		pick = lucent_select(_t('Filter results'), [c[0] for c in choices], _t('%s results') % len(window.item_list), counts=[c[3] for c in choices])
		if pick < 0: return True
		label, kind, value = choices[pick][:3]
		if kind == 'all':
			window._lucent_full = None
			_apply_filter(window, list_id, items, '')
			return True
		if kind in ('quality', 'debrid', 'site'): label = value
		if kind == 'quality': result = [i for i in items if get(i, 'umbrella.quality').upper() == value]
		elif kind == 'debrid': result = [i for i in items if get(i, 'umbrella.debrid') == value]
		elif kind == 'site': result = [i for i in items if get(i, 'umbrella.provider') == value]
		elif kind == 'title':
			text = dialog.input(_t('Keywords (comma separated)'))
			words = [w.strip().upper() for w in (text or '').split(',') if w.strip()]
			if not words: return True
			result = [i for i in items if all(w in get(i, 'umbrella.name').upper() for w in words)]
			label = _t('Title: %s') % ', '.join(words)
		else:
			present = []
			for i in items:
				for n in range(1, _MAX_BADGES + 1):
					b = i.getProperty('lucent.badge_%d' % n)
					if b and b not in present: present.append(b)
			present.sort(key=lambda b: _RANK.get(b, 999))
			if not present: return True
			sel = lucent_select(_t('Filter by info'), present, multi=True,
								counts=[sum(1 for i in items if b in [i.getProperty('lucent.badge_%d' % n) for n in range(1, _MAX_BADGES + 1)]) for b in present])
			if not sel: return True
			want = [present[n] for n in sel]
			result = [i for i in items if all(w in [i.getProperty('lucent.badge_%d' % n) for n in range(1, _MAX_BADGES + 1)] for w in want)]
			label = ' + '.join(want)
		if not result:
			dialog.ok(_t('Filter results'), _t('No results'))
			return True
		window._lucent_full = items
		_apply_filter(window, list_id, result, label)
		return True
	except Exception:
		return False


# ───────────── Fen Light / Red Light: RIGHT on the stream list ─────────────
def _log(msg):
	try:
		import xbmc
		xbmc.log('[Lucent] %s' % msg, xbmc.LOGINFO)
	except Exception:
		pass


def _fen_base(window):
	"""The rows currently shown: the last filtered list while a filter is
	active, else the full list - so a new filter narrows what is on screen."""
	if getattr(window, 'filter_applied', False):
		cur = getattr(window, '_lucent_current', None)
		if cur: return cur
	return list(getattr(window, 'item_list', None) or [])


def _fen_count(base, ftype, fvalue):
	vals = fvalue.split('/') if '/' in fvalue else [fvalue]
	return sum(1 for i in base if i.getProperty(ftype) in vals)


def lucent_fen_filter(window):
	"""RIGHT on the Fen Light / Red Light stream list: the add-on's own filter
	entries in the themed menu, applied through its own filter_action, but
	(1) on top of the filter already active, (2) with counts for what is on
	screen, (3) "Filter by Info" in the themed multi-select with live counts."""
	try:
		import sys
		entries = list(getattr(window, 'filter_list', None) or [])
		applied = bool(getattr(window, 'filter_applied', False))
		base = _fen_base(window)
		_log('RIGHT -> filter menu (%d entries, filter applied=%s, %d rows on screen)' % (len(entries), applied, len(base)))
		if not entries: return
		labels, counts, index = [], [], []
		if applied:
			labels.append(_t('Show all results')); counts.append(len(getattr(window, 'item_list', []) or [])); index.append(-1)
		for n, li in enumerate(entries):
			ftype, fvalue = li.getProperty('filter_type'), li.getProperty('filter_value')
			main = _split_count(li.getProperty('label'))[0]
			cnt = _fen_count(base, ftype, fvalue) if ftype in ('quality', 'provider') else None
			if cnt == 0: continue                    # nothing on screen would match
			labels.append(main); counts.append(cnt); index.append(n)
		pick = lucent_select(_t('Filter results'), labels, _t('%s results') % len(base), counts=counts)
		if pick is None or pick < 0: return
		if index[pick] == -1:
			window._lucent_current = None
			window.clear_filter()
			return
		window.select_item(window.filter_window_id, index[pick])
		mod = sys.modules.get(type(window).__module__)
		original = getattr(mod, 'select_dialog', None) if mod else None
		full, orig_set_filter = window.item_list, window.set_filter
		def capture(filtered_list):
			window._lucent_current = list(filtered_list)
			return orig_set_filter(filtered_list)
		if original is not None:
			mod.select_dialog = _themed_select_dialog(window, original, base)
		window.item_list = base                  # filter_action filters self.item_list
		window.set_filter = capture
		before = getattr(window, '_lucent_current', None)
		try:
			window.filter_action(window.selection_actions[0])
		finally:
			window.item_list = full
			after = getattr(window, '_lucent_current', None)
			_log('filter result: %s' % ('%d rows on screen' % len(after) if after is not before and after is not None else 'no change'))
			del window.set_filter                # back to the class method
			if original is not None:
				mod.select_dialog = original
	except Exception as e:
		_log('filter menu failed: %r' % e)


def _themed_select_dialog(window, original, base=None):
	"""Drop-in for Fen Light / Red Light select_dialog(function_list, **kwargs):
	same return values (an entry of function_list, a list of them for
	multi_choice, None on Back). Info filters count the rows on screen and the
	counts follow the ticks (all ticked tags must match, as the add-on does)."""
	def themed(function_list, **kwargs):
		try:
			import json
			items = json.loads(kwargs.get('items') or '[]')
			labels = [i.get('line1', '') for i in items]
			multi = kwargs.get('multi_choice', 'false') == 'true'
			counts, tags, live = None, [], None
			if multi:
				rows = base if base is not None else (getattr(window, 'item_list', None) or [])
				extras = [li.getProperty('extraInfo') or '' for li in rows]
				for entry in function_list:
					tag = entry[1] if isinstance(entry, (tuple, list)) and len(entry) > 1 else None
					tags.append(tag if isinstance(tag, str) and tag != 'ENG-OR-UNTAGGED' else None)
				counts = [sum(1 for e in extras if t in e) if t else None for t in tags]
			shown = [n for n in range(len(labels)) if not counts or counts[n] is None or counts[n] > 0]
			if multi:
				def live(checked):
					want = [tags[shown[c]] for c in checked if tags[shown[c]]]
					pool = [e for e in extras if all(w in e for w in want)]
					out = {None: len(pool)}
					for i, n in enumerate(shown):
						if tags[n] and i not in checked: out[i] = sum(1 for e in pool if tags[n] in e)
						elif tags[n]: out[i] = len(pool)
					return out
			heading = _t('Filter by info') if multi else (kwargs.get('heading') or _t('Filter results'))
			r = lucent_select(heading, [labels[n] for n in shown], multi=multi,
							counts=[counts[n] for n in shown] if counts else None, live=live)
			if multi:
				_log('filter by info: %s' % ('cancelled' if not r else ', '.join(str(tags[shown[n]]) for n in r)))
				return [function_list[shown[n]] for n in r] if r else None
			return function_list[shown[r]] if r is not None and r >= 0 else None
		except Exception as e:
			_log('themed select_dialog failed, using the add-on dialog: %r' % e)
			return original(function_list, **kwargs)
	return themed



# ───────────── Totals screen before the stream list (Fen Light / Red Light) ─────────────
_GROUP_Q = ('4K', '1080P', '720P', 'SD', 'CAM/SCR/TELE')
_PRETTY = {'ALLDEBRID': 'AllDebrid', 'REAL-DEBRID': 'Real-Debrid', 'REALDEBRID': 'Real-Debrid', 'TORBOX': 'TorBox',
		'PREMIUMIZE': 'Premiumize', 'OFFCLOUD': 'Offcloud', 'EASYNEWS': 'Easynews', 'EASYDEBRID': 'EasyDebrid'}
_AR.update({'All streams': 'كل المصادر', 'Choose what to show': 'اختر ما تريد عرضه'})
_AR.update({'Ends at %s': 'ينتهي في %s', '%dh %dm': '%d س %d د', '%dm': '%d د',
	'Searching for streams': 'جارٍ البحث عن المصادر', 'Opening stream': 'جارٍ فتح المصدر'})


def _layer1_on():
	return bool(_read_state().get('layer1', True))


def _group_key(li):
	q = (li.getProperty('quality') or 'SD').upper()
	if q in ('CAM', 'SCR', 'TELE'): q = 'CAM/SCR/TELE'
	return q, (li.getProperty('provider') or '').upper()


def lucent_layer1(window):
	"""Show the totals (quality x service) and narrow the list to the pick.
	Returns 'back' when the user leaves the totals screen, True when a group
	(or all) was applied, False when the screen does not apply (off / one group)."""
	try:
		if not _layer1_on(): return False
		every = list(getattr(window, 'item_list', None) or [])
		extra = [li for li in every if li.getProperty('perform_full_search') == 'true']
		rows = [li for li in every if li.getProperty('perform_full_search') != 'true']
		groups = {}
		for li in rows: groups.setdefault(_group_key(li), []).append(li)
		if len(groups) < 2: return False
		order = sorted(groups, key=lambda k: (_GROUP_Q.index(k[0]) if k[0] in _GROUP_Q else 9, -len(groups[k]), k[1]))
		colored = _colored()
		labels, counts, icons = [_t('All streams')], [len(rows)], [None]
		for q, prov in order:
			labels.append('[B]%s[/B]  ·  %s' % (q, _PRETTY.get(prov, prov.title()) if prov else '-'))
			counts.append(len(groups[(q, prov)]))
			res = '' if q == 'CAM/SCR/TELE' else _RES.get(q, '')
			icons.append(('', _provider_icon(prov)))
		title = window.getProperty('title') or _t('Filter results')
		current = getattr(window, '_lucent_layer1_pick', 0)
		pick = lucent_select(title, labels, _t('Choose what to show'), counts=counts,
							icons=icons if any(i and i[1] for i in icons) else None, preselect=current)
		window._lucent_layer1_shown = True
		_log('totals screen: %s' % ('back' if pick is None or pick < 0 else labels[pick]))
		if pick is None or pick < 0: return 'back'
		window._lucent_layer1_pick = pick
		if pick == 0:
			window._lucent_current = None
			if getattr(window, 'filter_applied', False): window.clear_filter()
			return True
		subset = groups[order[pick - 1]] + extra
		window._lucent_current = list(subset)
		window.set_filter(subset)
		return True
	except Exception as e:
		_log('totals screen failed: %r' % e)
		return False


def lucent_layer1_open(window):
	"""onInit hook: totals first; leaving it closes the stream list."""
	if getattr(window, '_lucent_layer1_done', False): return
	window._lucent_layer1_done = True
	if lucent_layer1(window) == 'back':
		window.selected = (None, '')
		window.close()


def lucent_layer1_back(window, action):
	"""onAction hook: BACK on the stream list returns to the totals screen."""
	if action not in getattr(window, 'closing_actions', ()): return False
	if not getattr(window, '_lucent_layer1_shown', False): return False
	if lucent_layer1(window) == 'back':
		window.selected = (None, '')
		window.close()
	return True
