# -*- coding: utf-8 -*-
"""
Add-on Portal – pick one or more video add-ons from a fixed catalogue and
install each one FROM ITS CHOSEN REPOSITORY.

Why not just InstallAddon(id) for everything?
  Kodi picks the source itself when several enabled repos carry the same id
  (highest version, official repo wins). Two catalogue entries collide:
  YouTube (repository.xbmc.org / umbrella / redwizard) and RedLight
  (repository.taiseerKODI22 v3.x vs repository.redwizard). The catalogue
  pins a repo per add-on, so the MAIN add-on zip is resolved and downloaded
  from that repo's own addons.xml, deterministically.

Flow per run:
  1. Repos: every repo the selection needs is installed if missing. All five
     repo zips are mirrored in repository.taiseer's datadir, so they are
     resolved from there (current version read from its addons.xml).
     Then UpdateAddonRepos + wait, so Kodi has listings for dependencies.
  2. Main add-on: read the pinned repo's LOCAL addon.xml -> every <dir> that
     matches this Kodi version -> its addons.xml -> highest version of the id
     -> datadir/<id>/<id>-<ver>.zip -> download, CRC-verify, stage-extract.
  3. Dependencies: every non-optional <import> not already present is handed
     to Kodi's own InstallAddon(dep) (resolves nested deps across all repos);
     its "Install add-on?" prompt is auto-answered Yes by a watchdog thread.
  4. UpdateLocalAddons, enable, and write installed.origin = pinned repo so
     the add-on keeps updating from THAT repo.
  Any resolve/download failure for step 2 falls back to InstallAddon(id).
"""

import os
import re
import gzip
import shutil
import time
import json
import threading
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.i18n import T

import xbmcaddon as _xbmcaddon
ADDON_ID    = 'plugin.program.abukarimtools'
ADDON_PATH  = xbmcvfs.translatePath(_xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))
if not ADDON_PATH.endswith(os.sep):
    ADDON_PATH += os.sep
ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')

TITLE       = 'ABUKARIM – Add-on Portal'
PORTAL_ICON = os.path.join(ADDON_PATH, 'resources', 'icons', 'addon_portal.png')

# Bootstrap source for repository zips (all five are mirrored here).
TAISEER_ZIPS = ('https://raw.githubusercontent.com/taiseer999/'
                'taiseer999.github.io/main/repo/zips/')

# (addon id, display name, pinned repo, remote icon fallback)
CATALOG = [
    ('plugin.video.dexhub',      'Dex Hub',     'repository.dexworld',
     'https://dexworld.cc/kodi/plugin.video.dexhub/resources/media/icon.png'),
    ('plugin.video.dplex',       'DPlex',       'repository.dexworld',
     'https://dexworld.cc/kodi/plugin.video.dplex/resources/media/icon.png'),
    ('plugin.video.fenlight',    'Fen Light+',  'repository.taiseer',
     TAISEER_ZIPS + 'plugin.video.fenlight/resources/media/fenlight_plus_icon.png'),
    ('plugin.video.abukarim.lastplayed', 'Last Played', 'repository.taiseer',
     TAISEER_ZIPS + 'plugin.video.abukarim.lastplayed/resources/media/icon.png'),
    ('plugin.video.pov',         'POV',         'repository.kodifitzwell',
     ''),
    ('plugin.video.redlight',    'Red Light',   'repository.redwizard',
     'https://repo.redwizard.xyz/redwizardrepo/main/plugin.video.redlight/'
     'resources/media/addon_icons/icon.png'),
    ('plugin.video.seren',       'Seren',       'repository.taiseer',
     TAISEER_ZIPS + 'plugin.video.seren/resources/images/ico-seren-3.png'),
    ('script.tinyppi',           'TinyPPI',     'repository.jamal2362',
     TAISEER_ZIPS + 'script.tinyppi/icon.png'),
    ('plugin.video.umbrella',    'Umbrella',    'repository.umbrella',
     'https://raw.githubusercontent.com/umbrellaplug/umbrellaplug.github.io/'
     'master/nexus/zips/plugin.video.umbrella/icon.png'),
    ('plugin.video.youtube',     'YouTube',     'repository.redwizard',
     'https://repo.redwizard.xyz/redwizardrepo/main/plugin.video.youtube/'
     'resources/media/icon.png'),
]

# Optional one-line note shown after the repository name in the list
# (string id from strings.po, or plain text from portal.json "note").
NOTES = {}

# 3.4.24: add-ons that exist ONLY where their upstream requirements are met.
# TinyPPI = CoreELEC + Kodi 22+ (xbmc.python 3.1.0), installed from
# repository.jamal2362 - on any other system AB Tools does nothing with it:
# not listed in the portal / phone setup / presets, never installed by a
# restore, no fallback to the old ABUKARIM build in repository.taiseer.
UPSTREAM_ONLY = {'script.tinyppi'}

# 3.4.10: add-ons that come from their AUTHOR'S repository whenever this box
# meets the upstream add-on's own requirements; every other box keeps the
# catalogue repo above (for TinyPPI: the ABUKARIM all-device build).
#   addon id -> (upstream repo, name of the local requirement check)
UPSTREAM = {
    'script.tinyppi': ('repository.jamal2362', '_tinyppi_upstream_ok'),
}

# Where a repository's own zip is found when it is NOT mirrored in
# repository.taiseer (resolved from that repo's own addons.xml).
REPO_SOURCES = {
    'repository.jamal2362': ('https://raw.githubusercontent.com/CE-Repo/'
                             'repository.jamal2362/main/addons/zips/'),
}

# addon id -> catalogue repo, for entries switched to UPSTREAM (fallback).
_FALLBACK = {}

REPO_NAMES = {
    'repository.jamal2362':    'Jamal2362',
    'repository.dexworld':     'DexWorld',
    'repository.taiseer':      'ABUKARIM',
    'repository.kodifitzwell': 'kodifitzwell',
    'repository.redwizard':    'The Red Repo',
    'repository.umbrella':     'Umbrella',
}


def _remote_portal():
    try:
        from resources.lib import remote_config
        return remote_config.load('portal.json', {}) or {}
    except Exception:
        return {}


def _catalog():
    """The built-in CATALOG, merged with abukarim/portal.json.

    3.3.6: the remote list no longer REPLACES the catalog. It used to, so the
    day the remote URL was fixed a stale portal.json (old Last Played, no
    TinyPPI) would have shrunk every box's portal. Now a remote entry
    overrides the built-in one with the same id or is appended; "remove":
    [ids] drops built-ins; "replace": true restores the old full replace.

    portal.json: {"schema": 1,
                  "addons": [{"id": .., "name": .., "repo": .., "icon": ..,
                              "note": ".. (optional)"}],
                  "repo_names": {"repository.x": "Nice Name"},
                  "repo_zips": {"repository.x": "https://.../repository.x-1.0.zip"}}
    A broken or empty list falls back to the built-in CATALOG.
    """
    data = _remote_portal()
    remote = []
    for e in data.get('addons') or []:
        try:
            if e['id'] and e['repo']:
                remote.append((e['id'], e.get('name') or e['id'], e['repo'],
                               e.get('icon', '')))
                if isinstance(e.get('note'), str) and e['note']:
                    NOTES[e['id']] = e['note']
        except Exception:
            continue
    names = data.get('repo_names') or {}
    REPO_NAMES.update({k: v for k, v in names.items() if isinstance(v, str)})
    if remote and data.get('replace') is True:
        return remote
    drop = set(x for x in (data.get('remove') or []) if isinstance(x, str))
    by_id = {r[0]: r for r in remote}
    out = [by_id.pop(c[0], c) for c in CATALOG if c[0] not in drop]
    out += [r for r in remote if r[0] in by_id and r[0] not in drop]
    out = [e for e in out
           if e[0] not in UPSTREAM_ONLY or _upstream_local_ok(e[0])]
    return [_prefer_upstream(e) for e in out]


# ---------------------------------------------------------------------------
# upstream repository when the add-on's own requirements are met (3.4.10)
# ---------------------------------------------------------------------------

def _is_coreelec():
    if os.path.isdir('/etc/coreelec'):
        return True
    try:
        with open('/etc/os-release') as f:
            return any('coreelec' in line.lower() for line in f)
    except OSError:
        return False


def _abi_version(abi_id):
    """Version Kodi provides for a core ABI id (xbmc.python, xbmc.gui ...)."""
    try:
        return xbmc.getInfoLabel('System.AddonVersion(%s)' % abi_id) or ''
    except Exception:
        return ''


def _tinyppi_upstream_ok():
    """jamal2362's TinyPPI: Kodi 22+ (xbmc.python 3.1.0) on CoreELEC only -
    its overlay refuses to open anywhere else."""
    if not _is_coreelec():
        return False
    if _kodi_version() < (22,):
        return False
    py = _abi_version('xbmc.python')
    return not py or _vtuple(py) >= (3, 1, 0)


def _upstream_local_ok(addon_id):
    spec = UPSTREAM.get(addon_id)
    if not spec:
        return False
    try:
        return bool(globals()[spec[1]]())
    except Exception as e:
        _log('%s: requirement check failed: %s' % (addon_id, e), xbmc.LOGWARNING)
        return False


def _prefer_upstream(entry):
    aid, name, rid, icon = entry
    spec = UPSTREAM.get(aid)
    if not spec or rid == spec[0] or not _upstream_local_ok(aid):
        return entry
    _FALLBACK[aid] = rid
    return (aid, name, spec[0], icon)


# Kodi <platform> tags -> condition that must hold on this box.
_PLATFORM_COND = {
    'linux':   'System.Platform.Linux + !System.Platform.Android',
    'android': 'System.Platform.Android',
    'osx':     'System.Platform.OSX',
    'osx64':   'System.Platform.OSX',
    'osxarm64': 'System.Platform.OSX',
    'ios':     'System.Platform.IOS',
    'tvos':    'System.Platform.TVOS',
    'windx':   'System.Platform.Windows',
    'windows': 'System.Platform.Windows',
    'freebsd': 'System.Platform.Linux',
}


def _platform_ok(tags):
    tags = [t.strip().lower() for t in (tags or '').split() if t.strip()]
    if not tags or 'all' in tags:
        return True
    for t in tags:
        cond = _PLATFORM_COND.get(t) or _PLATFORM_COND.get(t.split('-')[0])
        if cond and xbmc.getCondVisibility(cond):
            return True
    return False


def _listing_block(listing, addon_id):
    """<addon ...>...</addon> of addon_id from an addons.xml (highest version)."""
    try:
        root = ET.fromstring(listing)
    except Exception:
        return None
    best = None
    for a in root.findall('addon'):
        if a.get('id') == addon_id and (
                best is None or _ver_key(a.get('version')) > _ver_key(best.get('version'))):
            best = a
    return best


def _upstream_meta_ok(addon_id, repo_id):
    """Check the upstream add-on's OWN addon.xml (from its repository
    listing): platform tag, core ABI versions, and that every required
    add-on is present here or carried by the same repository."""
    base = REPO_SOURCES.get(repo_id)
    if not base:
        return True
    try:
        listing = _http_get(base + 'addons.xml')
    except Exception as e:
        _log('%s: listing failed: %s' % (repo_id, e), xbmc.LOGWARNING)
        return False
    node = _listing_block(listing, addon_id)
    if node is None:
        _log('%s: %s not listed' % (repo_id, addon_id), xbmc.LOGWARNING)
        return False
    carried = set(a.get('id') for a in ET.fromstring(listing).findall('addon'))
    for ext in node.findall('extension'):
        if ext.get('point') == 'xbmc.addon.metadata':
            plat = ext.find('platform')
            if plat is not None and not _platform_ok(plat.text):
                _log('%s %s: platform "%s" not met' % (addon_id, node.get('version'),
                                                     plat.text), xbmc.LOGINFO)
                return False
    for imp in node.findall('./requires/import'):
        dep = imp.get('addon') or ''
        if not dep or (imp.get('optional') or '').lower() == 'true':
            continue
        need = imp.get('version') or ''
        if dep.startswith(_SKIP_DEP_PREFIXES):
            have = _abi_version(dep)
            if need and have and _vtuple(have) < _vtuple(need):
                _log('%s: needs %s %s, Kodi has %s' % (addon_id, dep, need, have))
                return False
        elif not _has_addon(dep) and dep not in carried:
            _log('%s: dependency %s unavailable' % (addon_id, dep))
            return False
    return True


def _route_upstream(entries):
    """Final say before installing, whoever asked (portal, phone setup,
    backup restore): an UPSTREAM add-on goes to its author's repository only
    when this box meets that add-on's own requirements (local check + its
    addon.xml in the repo listing); otherwise to the catalogue repo - also
    when a restored backup recorded the upstream repo from another box."""
    out = []
    for aid, name, rid in entries:
        spec = UPSTREAM.get(aid)
        if spec and aid in UPSTREAM_ONLY:
            # 3.4.24: upstream or nothing (TinyPPI: CoreELEC 22 only).
            if _upstream_local_ok(aid) and _upstream_meta_ok(aid, spec[0]):
                _log('%s: upstream requirements met -> %s' % (aid, spec[0]))
                out.append((aid, name, spec[0]))
            else:
                _log('%s: not for this system (upstream only) - skipped' % aid)
            continue
        if spec:
            fb = _FALLBACK.get(aid) or next(
                (c[2] for c in CATALOG if c[0] == aid), rid)
            if fb == spec[0]:
                fb = rid if rid != spec[0] else 'repository.taiseer'
            if _upstream_local_ok(aid) and _upstream_meta_ok(aid, spec[0]):
                _log('%s: upstream requirements met -> %s' % (aid, spec[0]))
                rid = spec[0]
            else:
                _log('%s: upstream requirements not met -> %s' % (aid, fb))
                rid = fb
        out.append((aid, name, rid))
    return out


def _note(addon_id, repo_id=None):
    spec = UPSTREAM.get(addon_id)
    if spec and repo_id == spec[0]:
        return ''                 # the "for non CE22" note is for the fallback
    note = NOTES.get(addon_id)
    if isinstance(note, int):
        try:
            return T(note)
        except Exception:
            return ''
    return note or ''


# Import ids that are never fetched (core ABIs / always present).
_SKIP_DEP_PREFIXES = ('xbmc.', 'kodi.')


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------

def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[AbukarimTools AddonPortal] %s' % msg, level)


def _is_local(addon_id):
    return os.path.isfile(os.path.join(ADDONS_PATH, addon_id, 'addon.xml'))


def _has_addon(addon_id):
    return bool(xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id))


def _http_get(url, timeout=20):
    req = urllib.request.Request(url, headers={'User-Agent': 'Kodi'})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    if data[:2] == b'\x1f\x8b':          # addons.xml.gz / compressed info
        data = gzip.decompress(data)
    return data


def _ver_key(v):
    """Loose Kodi-style version ordering: numeric parts compared as ints,
    anything after '~' (pre-release) sorts lower."""
    v = (v or '').strip()
    pre = 0 if '~' in v else 1
    core = v.split('~')[0].split('+')[0]
    parts = []
    for p in re.split(r'[.\-_]', core):
        m = re.match(r'(\d+)(.*)', p)
        if m:
            parts.append((int(m.group(1)), m.group(2)))
        elif p:
            parts.append((-1, p))
    return (parts, pre, v)


def _kodi_version():
    raw = xbmc.getInfoLabel('System.BuildVersion') or ''
    m = re.match(r'(\d+(?:\.\d+)*)', raw)
    return tuple(int(x) for x in m.group(1).split('.')) if m else (22, 0)


def _vtuple(s):
    try:
        return tuple(int(x) for x in re.findall(r'\d+', s))
    except Exception:
        return ()


def _local_icon(addon_id, remote):
    """Installed add-on's own icon, else the remote URL, else the portal icon."""
    base = os.path.join(ADDONS_PATH, addon_id)
    try:
        root = ET.parse(os.path.join(base, 'addon.xml')).getroot()
        el = root.find('.//assets/icon')
        if el is not None and el.text:
            p = os.path.join(base, el.text.strip())
            if os.path.isfile(p):
                return p
    except Exception:
        pass
    p = os.path.join(base, 'icon.png')
    if os.path.isfile(p):
        return p
    return remote or PORTAL_ICON


# ---------------------------------------------------------------------------
# repository resolution
# ---------------------------------------------------------------------------

def _addons_xml_version(addons_xml_bytes, addon_id):
    m = re.search(br'<addon\b[^>]*\bid="%s"[^>]*>' % re.escape(addon_id.encode()),
                  addons_xml_bytes)
    if not m:
        return ''
    v = re.search(br'\bversion="([^"]+)"', m.group(0))
    return v.group(1).decode('utf-8', 'replace') if v else ''


def _repo_dirs(repo_id):
    """[(info_url, datadir, zip_bool)] from the INSTALLED repo's addon.xml,
    filtered to <dir> blocks whose min/maxversion match this Kodi."""
    path = os.path.join(ADDONS_PATH, repo_id, 'addon.xml')
    if not os.path.isfile(path):
        return []
    kv = _kodi_version()
    out = []
    try:
        root = ET.parse(path).getroot()
    except Exception as e:
        _log('cannot parse %s: %s' % (path, e), xbmc.LOGWARNING)
        return []
    for ext in root.findall('extension'):
        if ext.get('point') != 'xbmc.addon.repository':
            continue
        blocks = ext.findall('dir') or [ext]     # legacy: info/datadir directly
        for d in blocks:
            mn, mx = d.get('minversion'), d.get('maxversion')
            if mn and kv < _vtuple(mn):
                continue
            if mx and kv > _vtuple(mx):
                continue
            info = d.find('info')
            data = d.find('datadir')
            if info is None or data is None or not info.text or not data.text:
                continue
            datadir = data.text.strip()
            if not datadir.endswith('/'):
                datadir += '/'
            out.append((info.text.strip(), datadir,
                        (data.get('zip') or 'false').lower() == 'true'))
    return out


def _resolve_zip_in_repo(repo_id, addon_id):
    """Highest version of addon_id across the repo's matching dirs.
    Returns (zip_url, version) or (None, '')."""
    best = None
    for info_url, datadir, is_zip in _repo_dirs(repo_id):
        if not is_zip:
            continue
        try:
            ver = _addons_xml_version(_http_get(info_url), addon_id)
        except Exception as e:
            _log('%s: listing %s failed: %s' % (repo_id, info_url, e))
            continue
        if ver and (best is None or _ver_key(ver) > _ver_key(best[1])):
            best = ('%s%s/%s-%s.zip' % (datadir, addon_id, addon_id, ver), ver)
    return best or (None, '')


def _resolve_repo_zip(repo_id):
    """Repository zips come from the repository.taiseer mirror (or an explicit
    URL published in portal.json's repo_zips map)."""
    override = (_remote_portal().get('repo_zips') or {}).get(repo_id)
    if override:
        return override
    for base in (REPO_SOURCES.get(repo_id), TAISEER_ZIPS):
        if not base:
            continue
        try:
            ver = _addons_xml_version(_http_get(base + 'addons.xml'), repo_id)
        except Exception as e:
            _log('listing %s failed: %s' % (base, e), xbmc.LOGWARNING)
            continue
        if ver:
            return '%s%s/%s-%s.zip' % (base, repo_id, repo_id, ver)
    return None


# ---------------------------------------------------------------------------
# install primitives (reuse the skin installer's proven helpers)
# ---------------------------------------------------------------------------

def _si():
    from resources.lib import skin_installer
    return skin_installer


def _install_zip(url):
    si = _si()
    tmp = si._download_zip_silent(url)
    if not tmp:
        return False
    return si._extract_zip_silent(tmp)


def _enable(addon_id, timeout_ms=8000):
    si = _si()
    if si._addon_is_enabled(addon_id):
        return True
    si._enable_addon(addon_id)
    return si._wait_addon_enabled(addon_id, timeout_ms=timeout_ms)


def _force_origin(addon_id, repo_id, timeout_ms=10000):
    """installed.origin = repo_id (overwrites, unlike origin_fix.set_origin,
    because a reinstall from a different repo must re-point updates)."""
    from resources.lib import origin_fix
    db = origin_fix._find_addons_db()
    if not db:
        return False
    waited = 0
    while waited <= timeout_ms:
        conn = None
        try:
            conn = origin_fix._connect(db)
            cur = conn.cursor()
            cur.execute('UPDATE installed SET origin = ? WHERE addonID = ?',
                        (repo_id, addon_id))
            conn.commit()
            if cur.rowcount:
                _log('origin %s -> %s' % (addon_id, repo_id))
                return True
        except Exception as e:
            _log('origin write failed for %s: %s' % (addon_id, e))
        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass
        xbmc.sleep(500)           # not registered yet -> wait for Kodi
        waited += 500
    return False


def _required_imports(addon_id):
    path = os.path.join(ADDONS_PATH, addon_id, 'addon.xml')
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return []
    deps = []
    for imp in root.findall('./requires/import'):
        dep = imp.get('addon') or ''
        if not dep or dep.startswith(_SKIP_DEP_PREFIXES):
            continue
        if (imp.get('optional') or '').lower() == 'true':
            continue
        deps.append(dep)
    return deps


class _YesWatchdog(object):
    """Answers Kodi's 'Install add-on?' / dependency yes-no prompts while a
    Kodi-side InstallAddon runs. Only alive during that window, so it can
    never click one of the portal's own dialogs."""

    def __init__(self):
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._run)
        self._t.daemon = True

    def _run(self):
        while not self._stop.is_set():
            if xbmc.getCondVisibility('Window.IsActive(yesnodialog)'):
                xbmc.executebuiltin('SendClick(yesnodialog, 11)')   # 11 = Yes
                _log('auto-confirmed install prompt')
                xbmc.sleep(400)
            xbmc.sleep(100)

    def __enter__(self):
        self._t.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._t.join(2)
        return False


def _kodi_install(addon_id, timeout_ms=90000):
    """Hand one id to Kodi's own installer (resolves nested deps). Blocks
    until it is present or times out."""
    if _has_addon(addon_id):
        return True
    with _YesWatchdog():
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
        waited = 0
        mon = xbmc.Monitor()
        while waited < timeout_ms and not mon.abortRequested():
            if _has_addon(addon_id):
                xbmc.sleep(1500)          # let the extract/registration settle
                return True
            xbmc.sleep(500)
            waited += 500
    _log('InstallAddon(%s) timed out' % addon_id, xbmc.LOGWARNING)
    return _has_addon(addon_id)


def _wait_repo_listings(repo_ids, timeout_ms=40000):
    """After UpdateAddonRepos: wait until every repo has a cached listing
    (repo.lastcheck set), so InstallAddon can resolve dependencies."""
    from resources.lib import origin_fix
    db = origin_fix._find_addons_db()
    if not db or not repo_ids:
        xbmc.sleep(5000)
        return
    waited = 0
    pending = set(repo_ids)
    while pending and waited < timeout_ms:
        conn = None
        try:
            conn = origin_fix._connect(db)
            rows = conn.execute("SELECT addonID FROM repo WHERE "
                                "lastcheck IS NOT NULL AND lastcheck != ''"
                                ).fetchall()
            have = set(r[0].lower() for r in rows)
            pending = set(r for r in pending if r.lower() not in have)
        except Exception:
            pass
        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass
        if pending:
            xbmc.sleep(1000)
            waited += 1000
    if pending:
        _log('repo listings still pending: %s' % sorted(pending))


# ---------------------------------------------------------------------------
# the install run
# ---------------------------------------------------------------------------

def _install_selection(entries):
    """entries = [(addon_id, name, repo_id)]. Returns [(name, ok, note)]."""
    asked = list(entries)
    entries = _route_upstream(entries)
    kept = set(e[0] for e in entries)
    # 3.4.24: an upstream-only add-on this system cannot take (TinyPPI off
    # CoreELEC 22) is reported, not installed.
    results = [(n, False, T(30777)) for a, n, _r in asked if a not in kept]
    if not entries:
        return results
    prog = xbmcgui.DialogProgress()
    prog.create(TITLE, T(30401))
    # Answer every "Add-on required / enable this add-on?" (and install)
    # yes/no for the WHOLE run, plus a short tail after it: freshly enabled
    # add-ons can fire EnableAddon() on themselves from their own service
    # (POV re-enables itself right after its service starts - the prompt in
    # the 3.1.0.21 log came 1 s after POV's service started). Nothing of ours
    # asks a yes/no during this window, so auto-Yes is safe here.
    guard = _YesWatchdog()
    guard.__enter__()
    try:
        # 1) repositories -------------------------------------------------
        repos = []
        for _aid, _n, rid in entries:
            if rid not in repos:
                repos.append(rid)
        new_repos = []
        for i, rid in enumerate(repos):
            prog.update(int(i * 15 / max(len(repos), 1)),
                        T(30402) % REPO_NAMES.get(rid, rid))
            if not _is_local(rid):
                url = _resolve_repo_zip(rid)
                if url and _install_zip(url):
                    new_repos.append(rid)
                    _log('repo installed: %s' % rid)
                else:
                    _log('repo install failed: %s' % rid, xbmc.LOGWARNING)
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2500)
        for rid in repos:
            if _is_local(rid):
                _enable(rid)
        for rid in new_repos:
            _force_origin(rid, rid)
        prog.update(18, T(30403))
        xbmc.executebuiltin('UpdateAddonRepos')
        _wait_repo_listings([r for r in repos if _is_local(r)])

        # 2+3) each add-on ------------------------------------------------
        n = len(entries)
        for i, (aid, name, rid) in enumerate(entries):
            if prog.iscanceled():
                results.append((name, False, T(30410)))
                continue
            base = 20 + int(i * 75 / n)
            prog.update(base, T(30404) % (name, REPO_NAMES.get(rid, rid)))

            via = 'zip'
            ok = False
            if _is_local(rid):
                zip_url, ver = _resolve_zip_in_repo(rid, aid)
                if zip_url:
                    _log('%s %s <- %s' % (aid, ver, zip_url))
                    ok = _install_zip(zip_url)
            if not ok:
                # Could not pin the source (repo missing / host down):
                # let Kodi resolve it from whatever repo carries it.
                via = 'kodi'
                _log('%s: falling back to InstallAddon' % aid, xbmc.LOGWARNING)
                ok = _kodi_install(aid)
            if not ok:
                results.append((name, False, T(30411)))
                continue

            if via == 'zip':
                deps = [d for d in _required_imports(aid) if not _has_addon(d)]
                for j, dep in enumerate(deps):
                    prog.update(base + int(60 / n), T(30405) % (name, dep))
                    if not _kodi_install(dep):
                        _log('%s: dependency %s not installed' % (aid, dep),
                             xbmc.LOGWARNING)
                xbmc.executebuiltin('UpdateLocalAddons')
                xbmc.sleep(2000)
                # deps installed while disabled (rare) must be enabled too
                for dep in _required_imports(aid):
                    if _is_local(dep):
                        _enable(dep, timeout_ms=4000)

            enabled = _enable(aid)
            _force_origin(aid, rid)
            missing = [d for d in _required_imports(aid) if not _has_addon(d)]
            if missing:
                results.append((name, enabled, T(30412) % ', '.join(missing)))
            else:
                results.append((name, enabled, '' if enabled else T(30413)))
        prog.update(100, T(30406))
        # tail: catch self-enable prompts from add-on services starting now
        mon = xbmc.Monitor()
        mon.waitForAbort(8)
    finally:
        guard.__exit__(None, None, None)
        prog.close()
    return results


# ---------------------------------------------------------------------------
# the window
# ---------------------------------------------------------------------------

class AddonPortal(xbmcgui.WindowXMLDialog):

    LIST, BTN_INSTALL, BTN_ALL = 100, 201, 202

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.catalog = kwargs.get('catalog') or _catalog()
        ids = {c[0] for c in self.catalog}
        self.checked = set(a for a in (kwargs.get('preselect') or ()) if a in ids)
        self.result = None           # list of (aid, name, repo) on Install

    def onInit(self):
        self.setProperty('portal_icon', PORTAL_ICON)
        lst = self.getControl(self.LIST)
        lst.reset()
        for aid, name, rid, remote in self.catalog:
            li = xbmcgui.ListItem(name)
            icon = _local_icon(aid, remote)
            li.setArt({'icon': icon, 'thumb': icon})
            li.setProperty('addonid', aid)
            repo = REPO_NAMES.get(rid, rid)
            note = _note(aid, rid)
            li.setProperty('repo', '%s  ·  %s' % (repo, note) if note else repo)
            li.setProperty('installed', 'true' if _is_local(aid) else '')
            li.setProperty('status', T(30407) if _is_local(aid) else '')
            li.setProperty('checked', 'true' if aid in self.checked else '')
            lst.addItem(li)
        for cid, sid in ((9001, 30400), (9002, 30408),
                         (self.BTN_INSTALL, 30409)):
            try:
                self.getControl(cid).setLabel(T(sid))
            except Exception:
                pass
        self._refresh()
        for _ in range(10):
            self.setFocusId(self.LIST)
            if self.getFocusId() == self.LIST:
                break
            xbmc.sleep(100)

    def _refresh(self):
        try:
            self.getControl(9003).setLabel(T(30414) % len(self.checked))
            self.getControl(self.BTN_ALL).setLabel(
                T(30416) if len(self.checked) == len(self.catalog) else T(30415))
        except Exception:
            pass

    def _set(self, idx, on):
        aid = self.catalog[idx][0]
        li = self.getControl(self.LIST).getListItem(idx)
        if on:
            self.checked.add(aid)
        else:
            self.checked.discard(aid)
        li.setProperty('checked', 'true' if on else '')

    def onClick(self, control_id):
        if control_id == self.LIST:
            idx = self.getControl(self.LIST).getSelectedPosition()
            if 0 <= idx < len(self.catalog):
                self._set(idx, self.catalog[idx][0] not in self.checked)
                self._refresh()
        elif control_id == self.BTN_ALL:
            on = len(self.checked) != len(self.catalog)
            for i in range(len(self.catalog)):
                self._set(i, on)
            self._refresh()
        elif control_id == self.BTN_INSTALL:
            if not self.checked:
                xbmcgui.Dialog().notification(TITLE, T(30417), PORTAL_ICON, 2500)
                return
            self.result = [(a, n, r) for a, n, r, _i in self.catalog
                           if a in self.checked]
            self.close()

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK,
                               xbmcgui.ACTION_PREVIOUS_MENU):
            self.close()


def _patch_now():
    """Patch what was just installed right away (3.1.0.27) instead of waiting
    for the watchdog poll. Idempotent, never raises."""
    try:
        from resources.lib import patch_watchdog
        patch_watchdog.patch_after_install(reason='addon-portal')
    except Exception as e:
        _log('post-install patch failed: %s' % e)


def _open_portal(preselect):
    import time
    selection = None
    # A window closed in under 1.5 s with no choice was swallowed by a skin
    # reload / add-on rescan, not dismissed by the user: open it again.
    for attempt in range(3):
        started = time.time()
        win = AddonPortal('addon_portal.xml', ADDON_PATH, 'Default', '1080i',
                          preselect=preselect)
        win.doModal()
        selection = win.result
        del win
        if selection or time.time() - started > 1.5:
            break
        _log('portal closed instantly (attempt %d) - reopening' % (attempt + 1))
        xbmc.sleep(1500)
    return selection


def run(first_run=False, preselect=None, confirm_skip=None):
    """confirm_skip (Installation Wizard, 3.4.21): called when the portal is
    left without installing (Back, or No on the install question). True =
    skip the step; False = the portal opens again with the same ticks."""
    while True:
        selection = _open_portal(preselect)
        if selection:
            names = ', '.join(n for _a, n, _r in selection)
            if xbmcgui.Dialog().yesno(TITLE, T(30418) % names):
                break
            preselect = {a for a, _n, _r in selection}
        if confirm_skip is None or confirm_skip():
            return False
        _log('skip cancelled - reopening the portal')

    results = _install_selection(selection)
    ok = [n for n, good, _ in results if good]
    lines = []
    for name, good, note in results:
        mark = '[COLOR FF33D17A]OK[/COLOR]' if good else '[COLOR FFFF5555]X[/COLOR]'
        lines.append('%s  %s%s' % (mark, name, ('  - ' + note) if note else ''))
    xbmcgui.Dialog().textviewer(TITLE, '\n'.join(lines))

    # First-run applies patches as its own next step.
    if ok and not first_run:
        _patch_now()

    # Menus / widgets that point at the add-ons just installed come back.
    try:
        from resources.lib import menu_reconcile
        menu_reconcile.run(rebuild=True)
    except Exception as e:
        _log('menu reconcile failed: %s' % e, xbmc.LOGWARNING)

    if ok and not first_run:
        try:
            from resources.lib import origin_fix
            origin_fix.recommend_restart(message=T(30419))
        except Exception as e:
            _log('restart recommendation failed: %s' % e)
    return bool(ok)


TINYPPI_DONE = os.path.join(
    xbmcvfs.translatePath('special://profile/addon_data/'
                          'plugin.program.abukarimtools/'),
    'tinyppi_ce22.done')

# Origins that mean "the old ABUKARIM build" (empty = installed from a zip).
_TINYPPI_OLD_ORIGINS = ('', 'repository.taiseer', 'repository.taiseerce',
                        'repository.taiseerkodi22')


def _installed_origin(addon_id):
    """installed.origin from Addons33.db, or None when unknown."""
    try:
        from resources.lib import origin_fix
        db = origin_fix._find_addons_db()
        if not db:
            return None
        conn = origin_fix._connect(db)
        try:
            row = conn.execute('SELECT origin FROM installed WHERE addonID = ?',
                               (addon_id,)).fetchone()
        finally:
            conn.close()
        return (row[0] or '') if row else None
    except Exception as e:
        _log('origin of %s unreadable: %s' % (addon_id, e), xbmc.LOGWARNING)
        return None


def _mark_tinyppi_done(state):
    try:
        os.makedirs(os.path.dirname(TINYPPI_DONE), exist_ok=True)
        with open(TINYPPI_DONE, 'w') as f:
            f.write('%s %d' % (state, int(time.time())))
    except Exception:
        pass


def _jamal_tinyppi_zip():
    """(zip_url, version) of TinyPPI in jamal2362's repo, straight from its
    published listing (works before the repository add-on is installed)."""
    base = REPO_SOURCES['repository.jamal2362']
    try:
        ver = _addons_xml_version(_http_get(base + 'addons.xml'), 'script.tinyppi')
    except Exception as e:
        _log('TinyPPI: jamal2362 listing failed: %s' % e, xbmc.LOGWARNING)
        return None, ''
    if not ver:
        return None, ''
    return '%sscript.tinyppi/script.tinyppi-%s.zip' % (base, ver), ver


def ensure_tinyppi(force=False):
    """3.4.24/3.4.25 - TinyPPI on CoreELEC 22 comes from repository.jamal2362.

    CoreELEC 22:
      * missing                         -> install from jamal2362
      * installed from repository.taiseer / taiseerCE / taiseerKODI22 or a
        zip (the old ABUKARIM build)    -> REPLACE with jamal2362's
      * installed from jamal2362 / a system copy -> nothing
    Any other system: nothing at all.

    Runs from the Installation Wizard (force=True) and once per box from the
    service at boot (marker TINYPPI_DONE: an uninstall afterwards is
    respected). A failed download keeps the old copy and retries next boot.
    """
    aid = 'script.tinyppi'
    jamal = UPSTREAM[aid][0]
    if not _upstream_local_ok(aid):
        _log('TinyPPI: not CoreELEC 22 - nothing to do')
        return False
    if not force and os.path.exists(TINYPPI_DONE):
        return True

    replace = False
    if _is_local(aid) or os.path.isdir(os.path.join(ADDONS_PATH, aid)):
        origin = _installed_origin(aid)
        user_copy = os.path.isdir(os.path.join(ADDONS_PATH, aid))
        if origin is None or not user_copy or \
                origin.lower() not in _TINYPPI_OLD_ORIGINS:
            _log('TinyPPI: already installed (origin %r) - nothing to do'
                 % origin)
            _mark_tinyppi_done('kept')
            return True
        _log('TinyPPI: installed from %r (old ABUKARIM build) - replacing '
             'with %s' % (origin or 'zip', jamal))
        replace = True

    if not _upstream_meta_ok(aid, jamal):
        _log('TinyPPI: %s does not offer it for this box right now - retry '
             'next boot' % jamal, xbmc.LOGWARNING)
        return False

    if replace:
        # Prove the new zip is reachable BEFORE the old copy is removed.
        url, ver = _jamal_tinyppi_zip()
        tmp = _si()._download_zip_silent(url) if url else None
        if not tmp:
            _log('TinyPPI: jamal2362 zip not reachable - old copy kept, retry '
                 'next boot', xbmc.LOGWARNING)
            return False
        try:
            os.remove(tmp)
        except OSError:
            pass
        try:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': aid, 'enabled': False}}))
        except Exception:
            pass
        xbmc.sleep(1500)                  # let its service stop
        try:
            shutil.rmtree(os.path.join(ADDONS_PATH, aid))
        except Exception as e:
            _log('TinyPPI: could not remove the old copy (%s) - installing '
                 'over it' % e, xbmc.LOGWARNING)
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2500)

    res = _install_selection([(aid, 'TinyPPI', jamal)])
    ok = bool(res) and all(r[1] for r in res)
    _log('TinyPPI (CoreELEC 22) %s from %s: %s'
         % ('replaced' if replace else 'installed', jamal, res))
    if ok:
        _mark_tinyppi_done('replaced' if replace else 'installed')
        try:
            xbmcgui.Dialog().notification(
                'TinyPPI', T(30778), xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass
    return ok
