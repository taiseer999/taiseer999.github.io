# -*- coding: utf-8 -*-
"""
ab_search.py - ABUKARIM TOOLS (3.4.48, EasyNews 4.7.16)

"Search All": one stream list collected from every supported video add-on,
in the style of Dex Hub's source browser (filter chips per add-on and per
quality, one row per release with the add-ons that found it).

How the streams are collected - each add-on scrapes with its own settings,
scrapers and debrid accounts, and plays with its own resolver:

  plugin://<add-on>/?mode=app_list_sources&request_id=<id>&media_type=...
      run through JSON-RPC Files.GetDirectory, one thread per add-on. The
      add-on scrapes with no window and saves its sorted results to
      addon_data/<add-on>/device_select/<id>.json (Fen Light's own
      device-select protocol; Red Light gets the same two modes from the
      "Search All bridge" patch, lucent_sources.SPECS['redlight_search']).
  RunPlugin(plugin://<add-on>/?mode=app_play_source&request_id=<id>&selected_index=N...)
      plays results[N] through that add-on (resolve + failover through the rest).

Started from TMDbHelper's player list ("AB Search All", players JSON injected
by the patcher) as plugin://plugin.program.abukarimtools/?mode=ab_search&...

4.6.32 - AIOStreams (plugin.video.aiostreams) joins the list while it is
installed and has a manifest URL. It has no device-select modes: AB Tools
asks the AIOStreams instance itself (the add-on's own manifest URL, timeout
and SSL settings, an "AIO..." User-Agent so every stream carries streamData)
and turns the streams into rows. Playing one writes the add-on's
last_streams.json and runs its own play_index, so the add-on resolves it
(proxy headers, subtitles, P2P handler) exactly like its own stream list.

4.7.13 - Dex Hub (plugin.video.dexhub) joins the list. The "Search All
bridge" patch (lucent_sources.SPECS['dexhub_search']) adds the same two modes
to its dispatcher (action=app_list_sources / app_play_source): Dex Hub asks
every one of its own stream add-ons with no window and saves the rows to
device_select/<id>.json; playing one runs Dex Hub's own play() on the row's
stream key (resolve, subtitles, resume, scrobbling), with the next rows as
fallbacks.

4.7.16 - EasyNews (plugin.video.easynewsx) joins the list while it is
installed and signed in. Like AIOStreams it has no device-select modes: AB
Tools searches EasyNews itself (members.easynews.com solr search, the same
request Fen Light's EasyNews scraper makes) with the add-on's own login -
the one Account Manager writes into it (general.username / general.password;
AM's own easynews.* login is copied over when the add-on has none yet).
Only files whose name starts with the title, then the year (or SxxEyy), are
kept. Playing one runs the add-on's own /play route through PlayMedia, so
EasyNews Video resolves it (CDN redirect, play history) like its own list.

4.6.13 - threads: every window call happens on the dialog's own thread (the
one in doModal). The four provider threads and the TMDb meta thread only
change data and post JSONRPC.NotifyAll; a Monitor created on the dialog
thread receives it there (Kodi runs Monitor and window callbacks on the
thread that created them, inside doModal's MakePendingCalls) and rebuilds
the list. kodi.log 2026-10-30 06:40 / 06:49 (macOS, Kodi 22): the window
stopped responding right after the last add-on's results were drawn from a
worker thread - the same class of freeze as 3.4.23 (window calls from a
background thread).
"""
import json
import os
import re
import threading
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.i18n import T

ADDON_ID = 'plugin.program.abukarimtools'
ADDON_PATH = xbmcvfs.translatePath('special://home/addons/%s/' % ADDON_ID)
MEDIA = 'special://home/addons/%s/resources/lucent/media/' % ADDON_ID
_DATA = xbmcvfs.translatePath('special://profile/addon_data/')

# (key, add-on id, name, tag) in play priority order; key picks the colour in ab_search.xml
ADDONS = (('rl', 'plugin.video.redlight', 'Red Light', 'RL'),
          ('fl', 'plugin.video.fenlight', 'Fen Light', 'FL'),
          ('umb', 'plugin.video.umbrella', 'Umbrella', 'UM'),
          ('pov', 'plugin.video.pov', 'POV', 'POV'),
          ('aio', 'plugin.video.aiostreams', 'AIOStreams', 'AIO'),
          ('dex', 'plugin.video.dexhub', 'Dex Hub', 'DEX'),
          ('en', 'plugin.video.easynewsx', 'EasyNews', 'EN'))
_MODULES = os.path.join('resources', 'lib', 'modules')
# file that carries the device-select modes (relative to the add-on), and the text that proves it
_SUPPORT = {'fl': (os.path.join(_MODULES, 'router.py'), 'app_list_sources'),
            'rl': (os.path.join(_MODULES, 'router.py'), 'abk_device_select'),
            'umb': (os.path.join(_MODULES, 'router.py'), 'abk_device_select'),
            'pov': (os.path.join(_MODULES, 'entry.py'), 'abk_device_select'),
            'dex': (os.path.join('resources', 'lib', 'plugin.py'), 'abk_dexhub_search')}
# Search All bridge patch (lucent_sources.SPECS) per add-on; Fen Light has the modes natively
_BRIDGE = {'rl': 'redlight_search', 'umb': 'umbrella_search', 'pov': 'pov_search', 'dex': 'dexhub_search'}

LIST, CHIPS = 2000, 2300
# 4.6.7: expanded view - the same streams over the whole page (two columns)
LIST_X, CHIPS_X = 2002, 2310
VIEW_BTN, VIEW_BTN_X = 2400, 2410
_VIEW_FILE = os.path.join(_DATA, ADDON_ID, 'ab_search_view.json')
_QUALITIES = ('4K', '1080P', '720P', 'SD')
_QRANK = {'4K': 0, '1080P': 1, '720P': 2, 'SD': 3}
_ACTION_BACK = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)
_ACTION_MENU = (101, 117)            # long press / context menu: "Play with ..."
_ACTION_RIGHT = 2                    # RIGHT on the stream list: filter menu
_SCRAPE_TIMEOUT = 240                # a listing that never answers stops counting after this


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[AbukarimTools Search All] %s' % msg, level)


# ───────────────────────── Glass theme helper (shared) ─────────────────────────

_THEME = []


def _theme():
    """resources/lucent/lucent_theme.py - the helper the add-ons' Glass windows use
    (badges, resolution flags, service icons, title/meta properties)."""
    if not _THEME:
        mod = None
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                'abk_lucent_theme', os.path.join(ADDON_PATH, 'resources', 'lucent', 'lucent_theme.py'))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        except Exception as e:
            _log('theme helper failed: %s' % e, xbmc.LOGWARNING)
        _THEME.append(mod)
    return _THEME[0]


# ───────────────────────── add-ons ─────────────────────────

def _addon_dir(aid):
    return xbmcvfs.translatePath('special://home/addons/%s/' % aid)


def _supported(key, aid):
    if key == 'aio':                        # no bridge: needs only its manifest URL
        return bool(_aio_manifest())
    if key == 'en':                         # no bridge: needs only the EasyNews login
        return all(_en_login())
    try:
        rel, mark = _SUPPORT[key]
        with open(os.path.join(_addon_dir(aid), rel), 'r', encoding='utf-8', errors='replace') as f:
            return mark in f.read()
    except Exception:
        return False


def _ensure_bridge(key, aid):
    """Bridge missing (add-on just installed / updated): add it now."""
    if key not in _BRIDGE or _supported(key, aid):
        return
    try:
        from resources.lib import lucent_sources
        ok, msg = lucent_sources.apply(_addon_dir(aid), _BRIDGE[key])
        _log('bridge: %s' % msg)
    except Exception as e:
        _log('bridge failed: %s' % e, xbmc.LOGWARNING)


def available_addons():
    """[(key, aid, name, tag, supported)] for the installed add-ons."""
    out = []
    for key, aid, name, tag in ADDONS:
        if not xbmc.getCondVisibility('System.HasAddon(%s)' % aid):
            continue
        _ensure_bridge(key, aid)
        out.append((key, aid, name, tag, _supported(key, aid)))
    return out


# ───────────────────────── collecting ─────────────────────────

class Session(object):
    def __init__(self, media, addons):
        self.media = media
        self.rid = 'abs%d' % int(time.time() * 1000)
        self.addons = addons
        self.lock = threading.Lock()
        self.started = time.time()
        self.state = {}
        for key, aid, name, tag, ok in addons:
            self.state[key] = {'state': 'searching' if ok else 'unsupported', 'results': [], 'took': 0}
        self.listener = None
        self.closed = False
        self.started_threads = False

    def request_id(self, key):
        return '%s_%s' % (self.rid, key)

    def url(self, key, aid, kind, index=None):
        """plugin:// URL of an add-on's list ('list') or play ('play') mode."""
        m = self.media
        if key == 'umb':
            m = getattr(self, 'umb_media', None) or m
        elif key == 'dex':
            m = getattr(self, 'dex_media', None) or m
        mode = 'app_list_sources' if kind == 'list' else 'app_play_source'
        if key == 'dex':                    # Dex Hub: action=..., IMDb id (show id for episodes) for its add-ons
            params = {'action': mode}
            if kind == 'list':
                params.update({'media_type': m['media_type'], 'tmdb_id': m['tmdb_id'], 'imdb_id': m.get('imdb', ''),
                               'tvdb_id': m.get('tvdb', ''),
                               'title': m.get('tvshowtitle') if m['media_type'] == 'episode' else m.get('title', '')})
                if m['media_type'] == 'episode':
                    params.update({'season': m['season'], 'episode': m['episode']})
        elif key == 'umb':                    # Umbrella: action=..., needs the names and the other ids
            params = {'action': mode, 'title': m.get('title', ''), 'year': m.get('year', ''),
                      'imdb': m.get('imdb', ''), 'tmdb': m['tmdb_id'], 'tvdb': m.get('tvdb', ''),
                      'premiered': m.get('premiered', '')}
            if m['media_type'] == 'episode':
                params.update({'tvshowtitle': m.get('tvshowtitle', ''), 'season': m['season'], 'episode': m['episode']})
        else:
            params = {'mode': mode, 'media_type': m['media_type'], 'tmdb_id': m['tmdb_id']}
            if m['media_type'] == 'episode':
                params.update({'season': m['season'], 'episode': m['episode']})
            if kind == 'list':
                params.update({'autoplay': 'false', 'prescrape': 'false'})
        params['request_id'] = self.request_id(key)
        if index is not None:
            params['selected_index'] = index
        return 'plugin://%s/?%s' % (aid, urlencode(params))

    def start(self):
        for key, aid, name, tag, ok in self.addons:
            if ok:
                threading.Thread(target=self._run, args=(key, aid, name), name='abs_' + key).start()

    def done(self):
        return all(s['state'] != 'searching' for s in self.state.values())

    def _run(self, key, aid, name):
        if key == 'aio':
            return self._run_aio(name)
        if key == 'en':
            return self._run_en(name)
        rid = self.request_id(key)
        if key == 'umb':
            self.umb_media = _english_names(self.media)
        elif key == 'dex':
            self.dex_media = _english_names(self.media)
        url = self.url(key, aid, 'list')
        path = os.path.join(_DATA, aid, 'device_select', '%s.json' % rid)
        t0 = time.time()
        _log('%s: %s' % (name, url))
        answer = ''
        try:
            answer = xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
                'params': {'directory': url, 'media': 'files'}}))
        except Exception as e:
            answer = str(e)
        results, found = [], False
        for _ in range(10):                    # the file is written just before the listing ends
            if os.path.isfile(path):
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        results = json.load(f)
                    found = True
                    break
                except Exception:
                    pass
            xbmc.sleep(200)
        took = time.time() - t0
        if not found:
            _log('%s: no result file after %.1fs - %s' % (name, took, (answer or '')[:300]), xbmc.LOGWARNING)
        else:
            _log('%s: %d sources in %.1fs' % (name, len(results), took))
        with self.lock:
            self.state[key] = {'state': 'done' if found else 'failed', 'results': results if isinstance(results, list) else [],
                               'took': took}
        listener = self.listener
        if listener and not self.closed:
            try:
                listener()
            except Exception as e:
                _log('update failed: %s' % e, xbmc.LOGWARNING)


    def _run_aio(self, name):
        t0 = time.time()
        self.aio_media = _english_names(self.media)     # IMDb id (show id for episodes)
        results, raw, found = [], [], False
        try:
            raw, vid, type_ = _aio_streams(self.aio_media)
            results = [_aio_item(st) for st in raw]
            self.aio_play = {'type': type_, 'id': vid, 'streams': raw,
                             'title': self.aio_media.get('tvshowtitle') or self.aio_media.get('title') or ''}
            found = True
            _log('%s: %d sources in %.1fs' % (name, len(results), time.time() - t0))
        except Exception as e:
            _log('%s: failed after %.1fs - %s' % (name, time.time() - t0, e), xbmc.LOGWARNING)
        with self.lock:
            self.state['aio'] = {'state': 'done' if found else 'failed', 'results': results,
                                 'took': time.time() - t0}
        listener = self.listener
        if listener and not self.closed:
            try:
                listener()
            except Exception as e:
                _log('update failed: %s' % e, xbmc.LOGWARNING)


    def _run_en(self, name):
        t0 = time.time()
        self.en_media = _english_names(self.media)      # English title + year for the search
        results, found = [], False
        try:
            results = _en_search(self.en_media)
            found = True
            _log('%s: %d sources in %.1fs' % (name, len(results), time.time() - t0))
        except Exception as e:
            _log('%s: failed after %.1fs - %s' % (name, time.time() - t0, e), xbmc.LOGWARNING)
        with self.lock:
            self.state['en'] = {'state': 'done' if found else 'failed', 'results': results,
                                'took': time.time() - t0}
        listener = self.listener
        if listener and not self.closed:
            try:
                listener()
            except Exception as e:
                _log('update failed: %s' % e, xbmc.LOGWARNING)


# ───────────────────────── EasyNews ─────────────────────────
# plugin.video.easynewsx keeps its login in general.username / .password;
# Account Manager (script.module.acctmgr, easynews_sync "Easynews Video")
# writes it there. The search is members.easynews.com's solr search with the
# parameters Fen Light's EasyNews scraper uses (relevance order, video files
# only, spam filter); every row carries the members /dl/ link that the
# add-on's /play route resolves.

_EN_ID = 'plugin.video.easynewsx'
_EN_AM = 'script.module.acctmgr'
_EN_SEARCH = 'https://members.easynews.com/2.0/search/solr-search/advanced'
_EN_EXT = ('mkv', 'mp4', 'avi', 'm4v', 'ts', 'm2ts', 'mts', 'mov', 'wmv', 'webm', 'mpg', 'mpeg', 'divx', 'xvid', 'flv',
           'vob', 'iso')
_EN_PARAMS = {'st': 'adv', 'sb': 1, 'fex': ', '.join(_EN_EXT), 'fty[]': 'VIDEO', 'spamf': 1, 'u': 1, 'gx': 1,
              'pno': 1, 'sS': 3, 's1': 'relevance', 's1d': '-', 's2': 'dsize', 's2d': '-', 'pby': 250, 'safeO': 0}
_EN_JUNK = re.compile(r'(?<![a-z])(sample|trailer|teaser|featurette|extras?|behind[ ._-]the[ ._-]scenes)(?![a-z])', re.I)
_EN_WORD = re.compile(r'[a-z0-9]+')


def _en_addon(aid=_EN_ID):
    import xbmcaddon
    return xbmcaddon.Addon(aid)


def _en_login():
    """(username, password) EasyNews Video uses. When it has none yet but Account
    Manager holds an EasyNews login, AM's login is written into the add-on first
    (the same keys AM's own Easynews sync writes)."""
    try:
        addon = _en_addon()
        user = (addon.getSetting('general.username') or '').strip()
        pwd = addon.getSetting('general.password') or ''
    except Exception:
        return '', ''
    if user and pwd:
        return user, pwd
    try:
        am = _en_addon(_EN_AM)
        am_user = (am.getSetting('easynews.username') or '').strip()
        am_pwd = am.getSetting('easynews.password') or ''
    except Exception:
        am_user = am_pwd = ''
    if am_user and am_pwd:
        try:
            addon.setSetting('general.username', am_user)
            addon.setSetting('general.password', am_pwd)
            _log('EasyNews: login copied from Account Manager')
        except Exception as e:
            _log('EasyNews: login not copied from Account Manager: %s' % e, xbmc.LOGWARNING)
        return am_user, am_pwd
    return user, pwd


def en_sync_from_am():
    """Add-on Portal, after an install: give EasyNews Video the AM login now."""
    try:
        if xbmc.getCondVisibility('System.HasAddon(%s)' % _EN_ID):
            _en_login()
    except Exception as e:
        _log('EasyNews: login sync failed: %s' % e, xbmc.LOGWARNING)


def _en_words(text):
    t = str(text or '').lower().replace('&', ' and ').replace("'", '').replace('’', '')
    return _EN_WORD.findall(t)


def _en_query(media):
    """(search text, title words, year, season, episode)."""
    ep = media['media_type'] == 'episode'
    title = (media.get('tvshowtitle') if ep else media.get('title')) or media.get('title') or ''
    words = _en_words(title)
    if not words:
        raise ValueError('no title')
    year = str(media.get('year') or '')[:4]
    if ep:
        season, episode = int(media['season']), int(media['episode'])
        return '%s S%02dE%02d' % (' '.join(words), season, episode), words, year, season, episode
    return ('%s %s' % (' '.join(words), year)).strip(), words, year, None, None


def _en_match(name, words, year, season, episode):
    """The file name starts with the title, then the year (movies) or SxxEyy."""
    fw = _en_words(name)
    if fw[:1] == ['the'] and words[:1] != ['the']:
        fw = fw[1:]
    if words[:1] == ['the'] and fw[:1] != ['the']:
        words = words[1:]
    if fw[:len(words)] != words:
        return False
    rest = fw[len(words):]
    if season is None:
        if not year.isdigit():
            return True
        ys = {str(int(year) + d) for d in (-1, 0, 1)}
        return any(w in ys for w in rest[:3])
    if year.isdigit() and rest[:1] and rest[0].isdigit() and len(rest[0]) == 4:
        rest = rest[1:]                                   # "Show 2019 S01E02"
    for w in rest[:3]:
        m = re.match(r'^s(\d{1,2})e(\d{1,3})(?:e\d{1,3})*$', w)
        if m and int(m.group(1)) == season and int(m.group(2)) == episode:
            return True
        m = re.match(r'^(\d{1,2})x(\d{1,3})$', w)
        if m and int(m.group(1)) == season and int(m.group(2)) == episode:
            return True
    return False


def _en_quality(width, name):
    m = _AIO_RES.search(re.sub(r'[._]', ' ', name or ''))
    if m:
        q = m.group(1).upper()
        if q in ('4K', 'UHD', '2160P'):
            return '4K'
        return 'SD' if q in ('576P', '480P', '360P') else q
    try:
        width = int(width or 0)
    except (TypeError, ValueError):
        width = 0
    if width > 1920:
        return '4K'
    if width > 1280:
        return '1080P'
    if width > 720:
        return '720P'
    return 'SD'


def _en_rows(data, words, year, season, episode, no_erotica=False):
    """EasyNews solr answer -> Fen Light style rows (+ 'abk_en' for the /play route)."""
    from urllib.parse import quote
    farm, port = data.get('dlFarm'), data.get('dlPort')
    out, seen = [], set()
    min_secs = 300 if season is not None else 1200        # leave samples / clips out
    for f in data.get('data') or []:
        try:
            if not isinstance(f, dict):
                continue
            if str(f.get('type') or 'VIDEO').upper() != 'VIDEO' or f.get('virus') or f.get('passwd'):
                continue
            post_hash, name, ext = str(f['0']), str(f['10']), str(f['11'])
            if ext.lstrip('.').lower() not in _EN_EXT:
                continue
            if no_erotica and 'erotica' in str(f.get('9') or ''):
                continue
            if _EN_JUNK.search(name) or not _en_match(name, words, year, season, episode):
                continue
            try:
                secs = int(float(f.get('runtime') or 0))
            except (TypeError, ValueError):
                secs = 0
            if 0 < secs < min_secs:
                continue
            try:
                gb = round(float(f.get('rawSize') or 0) / 1073741824.0, 2)
            except (TypeError, ValueError):
                gb = 0.0
            key = (name.lower(), gb)
            if key in seen:
                continue
            seen.add(key)
            path = quote('%s%s/%s%s' % (post_hash, ext, name, ext))
            if farm and port:
                dl = 'https://members.easynews.com/dl/%s/%s/%s' % (farm, port, path)
            else:
                dl = 'https://members.easynews.com/dl/' + path
            langs = f.get('alangs') or []
            if isinstance(langs, str):
                langs = [langs]
            info = [ext.lstrip('.').upper()] + [str(x).upper() for x in langs[:3] if x]
            display = re.sub(r'[._]+', ' ', name).strip()
            out.append({'name': name + ext, 'display_name': display, 'quality': _en_quality(f.get('width'), name),
                        'size': gb, 'size_label': ('%.2f GB' % gb) if gb else '',
                        'scrape_provider': 'easynews', 'source': 'easynews', 'debrid': '',
                        'extraInfo': ' | '.join(info),
                        'abk_en': {'video': dl, 'title': display, 'runtime': str(secs),
                                   'thumb': 'https://th.easynews.com/thumbnails-%s/pr-%s.jpg' % (
                                       post_hash[0:3], post_hash[:41]),
                                   'newsgroups': str(f.get('9') or '').strip()}})
        except Exception as e:
            _log('EasyNews: row skipped: %s' % e, xbmc.LOGDEBUG)
    return out


def _en_search(media):
    """EasyNews files for the media (signed in with the add-on's own login)."""
    import base64
    import urllib.request
    from urllib.parse import quote
    user, pwd = _en_login()
    if not (user and pwd):
        raise ValueError('not signed in')
    text, words, year, season, episode = _en_query(media)
    url = _EN_SEARCH + '?' + urlencode(dict(_EN_PARAMS, gps=text))
    auth = base64.b64encode(('%s:%s' % (user, pwd)).encode('utf-8')).decode('ascii')
    try:
        addon = _en_addon()
        version = addon.getAddonInfo('version') or ''
        no_erotica = (addon.getSetting('general.newsgroup_exclusions.erotica') or '').lower() == 'true'
    except Exception:
        version, no_erotica = '', False
    req = urllib.request.Request(url, headers={
        'Authorization': 'Basic ' + auth, 'Accept': 'application/json',
        'Cookie': 'chickenlicker=%s%%3A%s' % (quote(user, safe=''), quote(pwd, safe='')),
        'User-Agent': '%s %s' % (_EN_ID, version)})
    _log('EasyNews: search "%s"' % text)
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read().decode('utf-8', 'replace'))
    if not isinstance(data, dict):
        raise ValueError('unexpected answer')
    out = _en_rows(data, words, year, season, episode, no_erotica)
    _log('EasyNews: %d of %d files match' % (len(out), len(data.get('data') or [])))
    return out


def _en_play(session, index):
    """Hand the picked file to plugin.video.easynewsx (its /play route)."""
    with session.lock:
        results = list(session.state.get('en', {}).get('results') or [])
    if not (0 <= index < len(results)):
        return
    play = {k: v for k, v in (results[index].get('abk_en') or {}).items() if v and v != '0'}
    if not play.get('video'):
        return
    url = 'plugin://%s/play?%s' % (_EN_ID, urlencode(play))
    _log('play: plugin://%s/play (%s)' % (_EN_ID, play.get('title', '')))
    xbmc.executebuiltin('PlayMedia(%s)' % url)


# ───────────────────────── AIOStreams ─────────────────────────
# Same requests as plugin.video.aiostreams resources/lib/api.py (Stremio
# protocol at <host>/stremio/<uuid>/<password>/...), read with the add-on's
# own settings. Streams it cannot play (errors, statistics, usenet/archive,
# P2P without a handler) are left out exactly as the add-on does.

_AIO_ID = 'plugin.video.aiostreams'
_AIO_SVC = {'realdebrid': 'Real-Debrid', 'alldebrid': 'AllDebrid', 'premiumize': 'Premiumize',
            'torbox': 'TorBox', 'offcloud': 'Offcloud', 'easynews': 'Easynews', 'easydebrid': 'EasyDebrid',
            'debridlink': 'Debrid-Link', 'debrider': 'Debrider', 'putio': 'Put.io', 'pikpak': 'PikPak',
            'seedr': 'Seedr'}
_AIO_RES = re.compile(r'\b(2160p|4k|uhd|1440p|1080p|720p|576p|480p|360p)\b', re.I)


def _aio_addon():
    import xbmcaddon
    return xbmcaddon.Addon(_AIO_ID)


def _aio_manifest():
    try:
        return (_aio_addon().getSetting('manifest_url') or '').strip()
    except Exception:
        return ''


def _aio_int(addon, key, default):
    try:
        return int(addon.getSetting(key) or default)
    except (TypeError, ValueError):
        return default


def _aio_base(url):
    """(base, query) like the add-on's normalise_manifest_url."""
    from urllib.parse import urlsplit, urlunsplit
    if url.startswith('stremio://'):
        url = 'https://' + url[len('stremio://'):]
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    parts = urlsplit(url)
    path = parts.path.rstrip('/')
    for suffix in ('/manifest.json', '/configure'):
        if path.endswith(suffix):
            path = path[:-len(suffix)]
            break
    if '/stremio/' not in path + '/':
        raise ValueError('not an AIOStreams manifest URL')
    return urlunsplit((parts.scheme, parts.netloc, path, '', '')), parts.query


def _aio_streams(media):
    """(playable raw streams, video id, stremio type) for the media."""
    import ssl
    import urllib.request
    from urllib.parse import quote
    imdb = media.get('imdb') or ''
    if not str(imdb).startswith('tt'):
        raise ValueError('no IMDb id')
    if media['media_type'] == 'episode':
        type_, vid = 'series', '%s:%s:%s' % (imdb, int(media['season']), int(media['episode']))
    else:
        type_, vid = 'movie', imdb
    addon = _aio_addon()
    base, query = _aio_base(_aio_manifest())
    url = '%s/stream/%s/%s.json' % (base, type_, quote(vid, safe=''))
    if query:
        url += '?' + query
    ctx = ssl.create_default_context()
    if (addon.getSetting('insecure_ssl') or '').lower() == 'true':
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    version = addon.getAddonInfo('version') or '1.0.0'
    req = urllib.request.Request(url, headers={'User-Agent': 'AIOStreams-Kodi/%s (Kodi)' % version,
                                               'Accept': 'application/json'})
    timeout = max(10, min(_aio_int(addon, 'timeout', 60), _SCRAPE_TIMEOUT))
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        data = json.loads(r.read().decode('utf-8'))
    streams = (data.get('streams') or []) if isinstance(data, dict) else []
    p2p = _aio_int(addon, 'p2p_handler', 0) > 0
    out = []
    for st in streams:
        if not isinstance(st, dict):
            continue
        sd = st.get('streamData') or {}
        if sd.get('type') in ('error', 'statistic'):
            continue
        if st.get('url') or (p2p and st.get('infoHash')):
            out.append(st)
    return out, vid, type_


def _aio_gb(st):
    sd = st.get('streamData') or {}
    try:
        return float(sd.get('size') or (st.get('behaviorHints') or {}).get('videoSize') or 0) / 1073741824.0
    except (TypeError, ValueError):
        return 0.0


def _aio_item(st):
    """An AIOStreams stream as a Fen Light style result row."""
    sd = st.get('streamData') or {}
    pf = sd.get('parsedFile') or {}
    hints = st.get('behaviorHints') or {}
    name = sd.get('filename') or hints.get('filename') or ''
    if not name:
        lines = [ln.strip() for ln in str(st.get('description') or st.get('title') or '').splitlines() if ln.strip()]
        name = lines[0] if lines else _clean(st.get('name')).replace('\n', ' ')
    res = str(pf.get('resolution') or '').strip()
    if not res:
        m = _AIO_RES.search('%s %s' % (name, st.get('name') or ''))
        res = m.group(1) if m else 'SD'
    res = res.upper()
    if res in ('4K', 'UHD', '2160P'):
        res = '4K'
    elif res in ('576P', '480P', '360P'):
        res = 'SD'
    gb = _aio_gb(st)
    svc = sd.get('service') or {}
    sid = str(svc.get('id') or '')
    info = []
    for part in (list(pf.get('visualTags') or []) + [pf.get('encode')] + list(pf.get('audioTags') or [])
                 + list(pf.get('audioChannels') or []) + str(pf.get('quality') or '').split()):
        if part and str(part) not in info:
            info.append(str(part))
    item = {'name': name, 'display_name': name, 'quality': res, 'size': gb,
            'size_label': ('%.2f GB' % gb) if gb else '', 'scrape_provider': 'external',
            'debrid': _AIO_SVC.get(sid, sid.title()) if sid else ('P2P' if st.get('infoHash') else ''),
            'source': sd.get('addon') or 'AIOStreams', 'extraInfo': ' | '.join(info),
            'hash': st.get('infoHash') or (sd.get('torrent') or {}).get('infoHash') or ''}
    if sid and svc.get('cached') is False:
        item['cache_provider'] = 'Uncached'
    if pf.get('seasonPack') or (pf.get('seasons') and not pf.get('episodes')):
        item['package'] = True
    return item


def _aio_play(session, index):
    """Hand the picked stream to plugin.video.aiostreams (its play_index)."""
    data = getattr(session, 'aio_play', None)
    if not data:
        return
    path = os.path.join(_DATA, _AIO_ID, 'last_streams.json')
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        _log('AIOStreams: last_streams.json not written: %s' % e, xbmc.LOGWARNING)
        return
    url = 'plugin://%s/?%s' % (_AIO_ID, urlencode({'action': 'play_index', 'idx': index}))
    _log('play: %s' % url)
    xbmc.executebuiltin('RunPlugin(%s)' % url)


# ───────────────────────── Umbrella: English names ─────────────────────────
# Umbrella scrapes by title. With Kodi in Arabic, TMDbHelper (and the focused
# item) give the Arabic title, and title-based scrapers then find nothing
# (kodi.log 2026-10-29: "Koko" sent as "كوكو", 0 results). Ask TMDb for the
# English names, with Umbrella's own TMDb key.

_UMB_TMDB_KEY = 'edde6b5e41246ab79a2697cd125e1781'     # Umbrella's built-in default


def _latin(text):
    return all(ord(c) < 0x250 for c in str(text or ''))


def _tmdb(path, lang='en-US'):
    import urllib.request
    key = ''
    try:
        import xbmcaddon
        key = xbmcaddon.Addon('plugin.video.umbrella').getSetting('tmdb.apikey')
    except Exception:
        pass
    url = 'https://api.themoviedb.org/3/%s%sapi_key=%s&language=%s' % (path, '&' if '?' in path else '?', key or _UMB_TMDB_KEY, lang)
    with urllib.request.urlopen(url, timeout=6) as r:
        return json.loads(r.read().decode('utf-8'))


def _english_names(media):
    m = dict(media)
    if _latin(m.get('title')) and _latin(m.get('tvshowtitle')) and m.get('imdb'):
        return m
    try:
        if m['media_type'] == 'movie':
            d = _tmdb('movie/%s?append_to_response=external_ids' % m['tmdb_id'])
            m['title'] = d.get('title') or m.get('title', '')
            m['year'] = (d.get('release_date') or '')[:4] or m.get('year', '')
            m['imdb'] = m.get('imdb') or d.get('imdb_id') or ''
        else:
            d = _tmdb('tv/%s?append_to_response=external_ids' % m['tmdb_id'])
            ext = d.get('external_ids') or {}
            m['tvshowtitle'] = d.get('name') or m.get('tvshowtitle', '')
            m['year'] = (d.get('first_air_date') or '')[:4] or m.get('year', '')
            m['imdb'] = m.get('imdb') or ext.get('imdb_id') or ''
            m['tvdb'] = m.get('tvdb') or str(ext.get('tvdb_id') or '')
            try:
                e = _tmdb('tv/%s/season/%s/episode/%s' % (m['tmdb_id'], m['season'], m['episode']))
                m['title'] = e.get('name') or m.get('title', '')
            except Exception:
                pass
        _log('Umbrella names: %s / %s (%s) %s' % (m.get('title'), m.get('tvshowtitle'), m.get('year'), m.get('imdb')))
    except Exception as e:
        _log('Umbrella names from TMDb failed (%s) - using the ones given' % e, xbmc.LOGWARNING)
    return m


# ───────────────────────── window meta from TMDb ─────────────────────────
# Logo, backdrop, plot, rating, certificate and genres for the left column.
# TMDbHelper's player URL carries only ids and names, and the focused item is
# often not the title any more by the time AB Tools runs (screenshot
# 2026-10-29: title and year only). Kodi's language first, English fallback.

_IMG = 'https://image.tmdb.org/t/p/%s%s'


def _ui_lang():
    try:
        return xbmc.getLanguage(xbmc.ISO_639_1) or 'en'
    except Exception:
        return 'en'


def _pick_logo(logos, lang):
    for want in (lang, 'en', None):
        for lg in logos or []:
            if lg.get('iso_639_1') == want and lg.get('file_path', '').endswith('.png'):
                return _IMG % ('w500', lg['file_path'])
    return ''


def tmdb_window_meta(media):
    """{'fanart', 'clearlogo', 'plot', 'rating', 'mpaa', 'genre', 'year', ...} or {}."""
    lang = _ui_lang()
    tag = 'en-US' if lang == 'en' else lang
    imgs = 'include_image_language=%s,en,null' % lang
    out = {}
    try:
        if media['media_type'] == 'movie':
            d = _tmdb('movie/%s?append_to_response=images,release_dates&%s' % (media['tmdb_id'], imgs), tag)
            out['year'] = (d.get('release_date') or '')[:4]
            for c in (d.get('release_dates') or {}).get('results', []):
                if c.get('iso_3166_1') == 'US':
                    cert = [r.get('certification') for r in c.get('release_dates', []) if r.get('certification')]
                    if cert:
                        out['mpaa'] = cert[0]
        else:
            d = _tmdb('tv/%s?append_to_response=images,content_ratings&%s' % (media['tmdb_id'], imgs), tag)
            out['year'] = (d.get('first_air_date') or '')[:4]
            for c in (d.get('content_ratings') or {}).get('results', []):
                if c.get('iso_3166_1') == 'US' and c.get('rating'):
                    out['mpaa'] = c['rating']
            try:
                e = _tmdb('tv/%s/season/%s/episode/%s' % (media['tmdb_id'], media['season'], media['episode']), tag)
                out['ep_plot'] = e.get('overview') or ''
                out['ep_runtime'] = e.get('runtime') or 0
                out['ep_name_tmdb'] = e.get('name') or ''
            except Exception:
                pass
        out['plot'] = out.pop('ep_plot', '') or d.get('overview') or ''
        if not out['plot'] and tag != 'en-US':
            try:
                path = 'movie/%s' if media['media_type'] == 'movie' else 'tv/%s'
                out['plot'] = _tmdb(path % media['tmdb_id']).get('overview') or ''
            except Exception:
                pass
        if d.get('backdrop_path'):
            out['fanart'] = _IMG % ('w1280', d['backdrop_path'])
        out['clearlogo'] = _pick_logo((d.get('images') or {}).get('logos'), lang)
        if d.get('vote_average'):
            out['rating'] = d['vote_average']
        out['genre'] = ', '.join(g.get('name', '') for g in (d.get('genres') or [])[:3])
        # running time (minutes) for the bitrate estimate
        if media['media_type'] == 'movie':
            out['runtime'] = d.get('runtime') or 0
        else:
            out['runtime'] = out.pop('ep_runtime', 0) or ((d.get('episode_run_time') or [0])[0])
    except Exception as e:
        _log('window meta from TMDb failed: %s' % e, xbmc.LOGWARNING)
        return {}
    return {k: v for k, v in out.items() if v}


# ───────────────────────── merging ─────────────────────────

_TAG_RE = re.compile(r'\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|COLOR[^\]]*)\]', re.I)


def _clean(text):
    return _TAG_RE.sub('', str(text or '')).strip()


def _quality(item):
    q = _clean(item.get('quality') or 'SD').upper()
    if q in ('2160P', 'UHD', '8K'):
        return '4K'
    return q or 'SD'


def _group(q):
    return q if q in _QRANK else 'SD'


def _provider(item):
    get = item.get
    sp = get('scrape_provider', '')
    if sp == 'folders':
        return _clean(get('source', ''))
    if sp == 'external' or get('debrid'):
        return _clean(get('debrid') or get('source', '')).replace('.me', '')
    return _clean(sp or get('source', ''))


def _site(item):
    return _clean(item.get('abk_site') or ((item.get('source') or item.get('provider'))
                                           if item.get('scrape_provider') == 'external' else ''))


_PRETTY = {'ALLDEBRID': 'AllDebrid', 'REAL-DEBRID': 'Real-Debrid', 'REALDEBRID': 'Real-Debrid', 'TORBOX': 'TorBox',
           'PREMIUMIZE': 'Premiumize', 'OFFCLOUD': 'Offcloud', 'EASYNEWS': 'Easynews', 'EASYDEBRID': 'EasyDebrid',
           'DEBRID-LINK': 'Debrid-Link', 'DEBRIDLINK': 'Debrid-Link'}


# 4.5.8: short service code on the card (replaces the coloured icon)
_SHORT = (('REAL', 'RD'), ('ALLDEBRID', 'AD'), ('ALL-DEBRID', 'AD'), ('PREMIUMIZE', 'PM'),
          ('TORBOX', 'TB'), ('OFFCLOUD', 'OC'), ('EASYNEWS', 'EN'), ('EASYDEBRID', 'ED'),
          ('DEBRID-LINK', 'DL'), ('DEBRIDLINK', 'DL'))


def _service_code(provider):
    up = (provider or '').upper().replace(' ', '')
    for key, code in _SHORT:
        if up.startswith(key):
            return code
    if up in ('RD', 'AD', 'PM', 'TB', 'OC', 'EN', 'ED', 'DL'):
        return up
    return ''


_SERVICE_ORDER = ('RD', 'AD', 'PM', 'TB', 'OC', 'EN', 'ED', 'DL')


_SERVICE_ICON = {'RD': 'realdebrid', 'AD': 'alldebrid', 'PM': 'premiumize', 'TB': 'torbox',
                 'OC': 'offcloud', 'EN': 'easynews', 'ED': 'easydebrid'}


def _service_icon(code):
    name = _SERVICE_ICON.get(code or '')
    return (MEDIA + 'lucent/providers/%s.png' % name) if name else ''


def _row_service(row):
    code = row.get('svc')
    if code is None:
        code = row['svc'] = _service_code(_provider(row['item']))
    return code


def _pretty(name):
    return _PRETTY.get(name.upper(), name.title() if name.isupper() else name)


# Title fit for the stream cards, in lucent_theme._px units: Kodi in Arabic
# cut an overflowing label from the START ("sion 2025 ..." for "Obsession
# 2025 ...", screenshot 2026-10-29), so titles are fitted here.
# 4.7.8: the cards use abk_srch_s (22 px). Measured on AF3's Inter, real
# width = 0.865 x _px at 22 px; the label is 740 wide; a 16:10 screen (Mac)
# draws the 1080i window ~11 % wider-per-height -> 740 / 0.865 / 1.11 = 770.
# The FOCUSED card shows the whole title (lucent.title_full, scrolling).
_TITLE_PX = 760

# size buckets in the filter menu (GB, string id)
_SIZES = ((0, 5, 30830), (5, 15, 30831), (15, 40, 30832), (40, 1e9, 30833))
# estimated bitrate buckets (Mbit/s, string id)
_BITRATES = ((40, 1e9, 30837), (20, 40, 30838), (10, 20, 30839), (0, 10, 30840))


def _size(item):
    try:
        return float(item.get('size') or 0)
    except Exception:
        return 0.0


def _row_key(item):
    h = str(item.get('hash') or '').strip().lower()
    if h:
        return 'h:' + h
    return 'n:%s|%s' % (_clean(item.get('name') or item.get('display_name')).lower(), _clean(item.get('size_label')))


def merge(session):
    """One row per release: {'item', 'refs': [(key, index)], 'q', 'group', 'size', 'order'}."""
    rows, order = {}, 0
    with session.lock:
        snapshot = [(key, list(session.state.get(key, {}).get('results') or [])) for key, _a, _n, _t, _ok in session.addons]
    for key, results in snapshot:
        for idx, item in enumerate(results):
            if not isinstance(item, dict) or 'Uncached' in str(item.get('cache_provider', '')):
                continue
            rk = _row_key(item)
            row = rows.get(rk)
            if row is None:
                q = _quality(item)
                rows[rk] = {'item': item, 'refs': [(key, idx)], 'q': q, 'group': _group(q),
                            'size': _size(item), 'order': order}
                order += 1
            elif all(k != key for k, _i in row['refs']):
                row['refs'].append((key, idx))
    out = list(rows.values())
    out.sort(key=lambda r: (_QRANK.get(r['group'], 9), r['q'] != r['group'], -r['size'], r['order']))
    return out


# ───────────────────────── the window ─────────────────────────

def _load_expanded():
    try:
        with open(_VIEW_FILE, 'r', encoding='utf-8') as f:
            return bool(json.load(f).get('expanded'))
    except Exception:
        return False


def _save_expanded(on):
    try:
        os.makedirs(os.path.dirname(_VIEW_FILE), exist_ok=True)
        with open(_VIEW_FILE, 'w', encoding='utf-8') as f:
            json.dump({'expanded': bool(on)}, f)
    except Exception as e:
        _log('view not saved: %s' % e, xbmc.LOGWARNING)


class SearchWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.session = kwargs['session']
        self.meta = kwargs.get('meta') or {}
        self.tags = {key: (name, tag) for key, _a, name, tag, _ok in self.session.addons}
        self.rows, self.shown = [], []
        self.f_addon, self.f_quality = None, None
        self.f_service = None         # 4.5.9: service chip (RD / AD / PM ...)
        self.chips = []
        self.picked = None
        self.ui_lock = threading.RLock()
        self.ready = False
        self.focused_key = None
        self.runtime = 0              # minutes, from TMDb: bitrate = size / running time
        self.filters = []            # filter menu (RIGHT / "Filter" chip): [{'kind', 'value', 'label'}]
        self._badge_cache = {}
        self.expanded = _load_expanded()   # 4.6.7: last view is kept
        self._dirty = False           # 4.6.13: new data waiting for the dialog thread
        self._dirty_at = 0.0
        self._pending_meta = None     # TMDb meta fetched by the meta thread
        self._busy = 0                # nested dialog open (filter menu / "Play with")

    # ---- view (4.6.7) ----
    def _lid(self):
        return LIST_X if self.expanded else LIST

    def _cid(self):
        return CHIPS_X if self.expanded else CHIPS

    def _bid(self):
        return VIEW_BTN_X if self.expanded else VIEW_BTN

    def _view_props(self):
        self.setProperty('abs.expanded', 'true' if self.expanded else '')
        self.setProperty('abs.viewlabel', T(30842) if self.expanded else T(30841))

    def _toggle_view(self):
        with self.ui_lock:
            try:
                pos = self.getControl(self._lid()).getSelectedPosition()
                if 0 <= pos < len(self.shown):
                    self.focused_key = _row_key(self.shown[pos]['item'])
            except Exception:
                pass
            old = (self._lid(), self._cid())
            self.expanded = not self.expanded
            self._view_props()
            for cid in old:                     # the hidden view stays empty
                try:
                    self.getControl(cid).reset()
                except Exception:
                    pass
            self.shown, self.chips = [], []     # rebuild in the other view
            self._chips()
            self._rows()
        _save_expanded(self.expanded)
        _log('view: %s' % ('expanded' if self.expanded else 'default'))
        self._focus(self._bid())

    # ---- life cycle ----
    def onInit(self):
        th = _theme()
        if th:
            try:
                th.lucent_window(self, self.meta, fanart=self.meta.get('fanart', ''), clearlogo=self.meta.get('clearlogo', ''))
            except Exception as e:
                _log('window meta: %s' % e)
        self.setProperty('abs.heading', T(30817))
        self.setProperty('abs.addons_heading', T(30818))
        self._view_props()
        # always: besides any missing art / plot it brings the running time
        threading.Thread(target=self._fill_meta, name='abs_meta').start()
        self.ready = True
        self.session.listener = self.request_refresh
        self.refresh()
        self._focus(self._cid())
        if not self.session.started_threads:
            self.session.started_threads = True
            self.session.start()

    def close(self):
        self.session.closed = True
        super().close()

    # ---- cross-thread (4.6.13): workers change data only, the dialog thread draws ----
    def request_refresh(self):
        """Any thread. Mark new data and wake the dialog thread; no window call here."""
        if self.session.closed:
            return
        if not self._dirty:
            self._dirty_at = time.time()
        self._dirty = True
        try:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
                'params': {'sender': ADDON_ID, 'message': 'abs_refresh', 'data': {'rid': self.session.rid}}}))
        except Exception as e:
            _log('refresh notify failed: %s' % e, xbmc.LOGWARNING)

    def pump(self):
        """Dialog thread only: Monitor.onNotification, onAction, after a nested dialog."""
        if not self._dirty or self._busy or not self.ready or self.session.closed:
            return
        self._dirty = False
        lag = time.time() - self._dirty_at
        if lag > 2:
            _log('refresh ran %.1fs after the data arrived' % lag, xbmc.LOGWARNING)
        meta, self._pending_meta = self._pending_meta, None
        if meta:
            self._apply_meta(meta)
        self.refresh()

    def _fill_meta(self):
        """Meta thread: TMDb only, then hand the result to the dialog thread."""
        extra = tmdb_window_meta(self.session.media)
        if not extra or self.session.closed:
            return
        self._pending_meta = extra
        self.request_refresh()

    def _apply_meta(self, extra):
        """Dialog thread."""
        try:
            runtime = int(extra.pop('runtime', 0) or 0)
        except Exception:
            runtime = 0
        if runtime > 0 and not self.runtime:
            self.runtime = runtime
            _log('running time %d min - bitrate estimates on' % runtime)
            self.shown = []                   # rebuild the cards with the estimate (refresh follows)
        meta = dict(self.meta)
        for k, v in extra.items():
            if not meta.get(k):
                meta[k] = v
        self.meta = meta
        th = _theme()
        if th:
            try:
                th.lucent_window(self, meta, fanart=meta.get('fanart', ''), clearlogo=meta.get('clearlogo', ''))
            except Exception as e:
                _log('window meta: %s' % e)

    def _focus(self, cid):
        # no <defaultcontrol>: the chips are empty until onInit fills them, and
        # Kodi then logs "Control 2300 ... can't focus". Focus once they exist.
        for _ in range(40):
            try:
                self.setFocusId(cid)
                if self.getFocusId() == cid:
                    return
            except Exception:
                pass
            xbmc.sleep(25)

    # ---- building ----
    def refresh(self):
        if not self.ready or self.session.closed:
            return
        with self.ui_lock:
            self.rows = merge(self.session)
            self._status()
            self._chips()
            self._rows()

    def _status(self):
        st = self.session.state
        n = 0
        for key, _aid, name, _tag, ok in self.session.addons:
            n += 1
            s = st[key]
            if s['state'] == 'searching':
                text = T(30819)
            elif s['state'] == 'done':           # playable rows only (uncached left out)
                text = T(30820) % sum(1 for r in self.rows if any(k == key for k, _i in r['refs']))
            elif s['state'] == 'unsupported':
                text = T(30843) if key == 'aio' else (T(30844) if key == 'en' else T(30829))
            else:
                text = T(30821)
            self.setProperty('abs.s%d.key' % n, key)
            self.setProperty('abs.s%d.name' % n, name)
            self.setProperty('abs.s%d.state' % n, s['state'])
            self.setProperty('abs.s%d.status' % n, text)
        searching = sum(1 for s in st.values() if s['state'] == 'searching')
        active = len({k for r in self.rows for k, _i in r['refs']})
        if searching:
            self.setProperty('abs.subhead', T(30822) % searching)
            self.setProperty('abs.waitmsg', T(30828))
            self.setProperty('abs.empty', '')
        else:
            sub = T(30823) % (len(self.rows), active, int(time.time() - self.session.started))
            if self.filters:
                sub += '  ·  ' + T(30836) % ' + '.join(f['label'] for f in self.filters)
            self.setProperty('abs.subhead', sub)
            self.setProperty('abs.waitmsg', T(30824))
            self.setProperty('abs.empty', 'true')

    def _chip_defs(self):
        st = self.session.state
        chips = [('all', None, T(30825), len(self.rows), '', False)]
        for key, _aid, name, _tag, ok in self.session.addons:
            if not ok:
                continue
            count = sum(1 for r in self.rows if any(k == key for k, _i in r['refs']))
            chips.append(('addon', key, name, count, key, st[key]['state'] == 'searching'))
        for q in _QUALITIES:
            count = sum(1 for r in self.rows if r['group'] == q)
            if count:
                chips.append(('quality', q, q.replace('P', 'p'), count, '', False))
        # 4.5.9: one chip per debrid service (4.6.1: shown from one service on)
        svc = {}
        for r in self.rows:
            code = _row_service(r)
            if code:
                svc[code] = svc.get(code, 0) + 1
        if svc:
            for code in _SERVICE_ORDER:
                if code in svc:
                    chips.append(('service', code, code, svc[code], '', False))
        if self.rows:
            chips.append(('filter', None, T(30835), len(self.filters) or '', '', False))
        return chips

    def _chips(self):
        defs = self._chip_defs()
        ctl = self.getControl(self._cid())
        same = [(d[0], d[1]) for d in defs] == [(d[0], d[1]) for d in self.chips]
        if not same:
            pos = ctl.getSelectedPosition()
            ctl.reset()
            for _d in defs:
                ctl.addItem(xbmcgui.ListItem(''))
            if 0 <= pos < len(defs):
                ctl.selectItem(pos)
        self.chips = defs
        for n, (kind, value, label, count, key, loading) in enumerate(defs):
            li = ctl.getListItem(n)
            li.setLabel(label)
            li.setLabel2('' if loading else str(count))
            li.setProperty('abs.key', key)
            li.setProperty('abs.loading', 'true' if loading else '')
            li.setProperty('abs.chipicon', _service_icon(value) if kind == 'service' else '')
            active = (kind == 'all' and not self.f_addon and not self.f_quality and not self.f_service
                      and not self.filters) or \
                     (kind == 'addon' and value == self.f_addon) or (kind == 'quality' and value == self.f_quality) or \
                     (kind == 'service' and value == self.f_service) or \
                     (kind == 'filter' and bool(self.filters))
            li.setProperty('abs.active', 'true' if active else '')

    def _chip_rows(self):
        out = []
        for r in self.rows:
            if self.f_addon and all(k != self.f_addon for k, _i in r['refs']):
                continue
            if self.f_quality and r['group'] != self.f_quality:
                continue
            if self.f_service and _row_service(r) != self.f_service:
                continue
            out.append(r)
        return out

    def _visible_rows(self):
        return [r for r in self._chip_rows() if all(self._match(r, f) for f in self.filters)]

    # ---- filter menu ----
    def _badges(self, row):
        item = row['item']
        found = self._badge_cache.get(id(item))
        if found is None:
            th = _theme()
            try:
                found = th.badges(item.get('extraInfo', ''), row['q']) if th else []
            except Exception:
                found = []
            self._badge_cache[id(item)] = found
        return found

    def _mbps(self, row):
        """Average bitrate estimate in Mbit/s: size x 8 / running time. None for
        season / show packs (one size for many episodes) or unknown size."""
        item = row['item']
        if not self.runtime or row['size'] <= 0:
            return None
        if item.get('package') or item.get('pack') or item.get('last_season'):
            return None
        return row['size'] * 8000.0 / (self.runtime * 60.0)

    def _match(self, row, f):
        kind, value, item = f['kind'], f['value'], row['item']
        if kind == 'bitrate':
            lo, hi = value
            rate = self._mbps(row)
            return rate is not None and lo <= rate < hi
        if kind == 'service':
            return _provider(item).upper() == value
        if kind == 'site':
            return _site(item).upper() == value
        if kind == 'size':
            lo, hi = value
            return row['size'] > 0 and lo <= row['size'] < hi       # unknown size fits no bucket
        if kind == 'title':
            name = _clean(item.get('display_name') or item.get('name')).upper()
            return all(w in name for w in value)
        if kind == 'info':
            have = self._badges(row)
            return all(w in have for w in value)
        return True

    def _filter_menu(self):
        th = _theme()
        if not th:
            return
        th._addon_root = lambda: ADDON_PATH.rstrip('/\\')       # AB Tools' own lucent_select.xml
        _t = th._t
        base = self._visible_rows()
        if not base and not self.filters:
            return
        choices = []                    # (label, kind, value, count)
        if self.filters:
            choices.append((_t('Show all results'), 'clear', None, len(self._chip_rows())))
        def counted(kind, value, label):
            n = sum(1 for r in base if self._match(r, {'kind': kind, 'value': value}))
            if 0 < n < len(base):       # a filter that keeps everything (or nothing) is no filter
                choices.append((label, kind, value, n))
        services = sorted({_provider(r['item']).upper() for r in base} - {''})
        for s in services:
            counted('service', s, _t('Show %s only') % _pretty(s))
        for lo, hi, sid in _SIZES:
            counted('size', (lo, hi), T(sid))
        if self.runtime:
            for lo, hi, sid in _BITRATES:
                counted('bitrate', (lo, hi), T(sid))
        sites = {}
        for r in base:
            s = _site(r['item']).upper()
            if s:
                sites[s] = sites.get(s, 0) + 1
        for s in sorted(sites, key=lambda k: -sites[k])[:12]:
            counted('site', s, _t('Source: %s') % s.title())
        choices.append((_t('Filter by title...'), 'title', None, None))
        choices.append((_t('Filter by info (HDR, Atmos ...)...'), 'info', None, None))
        pick = th.lucent_select(_t('Filter results'), [c[0] for c in choices], _t('%s results') % len(base),
                                counts=[c[3] for c in choices])
        if pick is None or pick < 0:
            return
        label, kind, value, _n = choices[pick]
        if kind == 'clear':
            self.filters = []
            return self._apply_filters()
        if kind == 'title':
            text = xbmcgui.Dialog().input(_t('Keywords (comma separated)'))
            words = [w.strip().upper() for w in (text or '').split(',') if w.strip()]
            if not words:
                return
            value, label = words, _t('Title: %s') % ', '.join(words)
        elif kind == 'info':
            present = []
            for r in base:
                for b in self._badges(r):
                    if b not in present:
                        present.append(b)
            present.sort(key=lambda b: th._RANK.get(b, 999))
            if not present:
                return
            sets = [set(self._badges(r)) for r in base]
            def live(checked):
                want = [present[c] for c in checked]
                pool = [s for s in sets if all(w in s for w in want)]
                out = {None: len(pool)}
                for i, b in enumerate(present):
                    out[i] = len(pool) if i in checked else sum(1 for s in pool if b in s)
                return out
            sel = th.lucent_select(_t('Filter by info'), present, multi=True,
                                   counts=[sum(1 for s in sets if b in s) for b in present], live=live)
            if not sel:
                return
            value = [present[n] for n in sel]
            label = ' + '.join(value)
        elif kind == 'service':
            label = _pretty(value)
        elif kind == 'site':
            label = value.title()
        new = self.filters + [{'kind': kind, 'value': value, 'label': label}]
        if not any(all(self._match(r, f) for f in new) for r in self._chip_rows()):
            xbmcgui.Dialog().notification(_t('Filter results'), _t('No results'), xbmcgui.NOTIFICATION_INFO, 2500)
            return
        self.filters = new
        _log('filter: %s' % ' + '.join(f['label'] for f in self.filters))
        self._apply_filters()

    def _apply_filters(self):
        with self.ui_lock:
            self.focused_key = None
            self._status()
            self._chips()
            self._rows()
        if self.shown:
            self._focus(self._lid())
            try:
                self.getControl(self._lid()).selectItem(0)
            except Exception:
                pass

    def _rows(self):
        ctl = self.getControl(self._lid())
        try:
            pos = ctl.getSelectedPosition()
            if 0 <= pos < len(self.shown):
                self.focused_key = _row_key(self.shown[pos]['item'])
        except Exception:
            pass
        shown = self._visible_rows()
        if [id(r['item']) for r in shown] == [id(r['item']) for r in self.shown] and \
                [len(r['refs']) for r in shown] == [len(r['refs']) for r in self.shown]:
            return
        items = [self._listitem(r) for r in shown]
        ctl.reset()
        if items:
            ctl.addItems(items)
        self.shown = shown
        if self.focused_key:
            for n, r in enumerate(shown):
                if _row_key(r['item']) == self.focused_key:
                    ctl.selectItem(n)
                    break
        if not shown and self.getFocusId() == self._lid():
            self.setFocusId(self._cid())

    def _listitem(self, row):
        th = _theme()
        item, q = row['item'], row['q']
        # offscreen: a new row, filled before addItems and never changed after
        li = xbmcgui.ListItem(_clean(item.get('display_name') or item.get('name')), offscreen=True)
        provider = _provider(item)
        site = _site(item)
        size = _clean(item.get('size_label'))
        meta = []
        rate = self._mbps(row)
        rate = ('~%d Mbps' % round(rate)) if rate else ''
        for part in (provider, size, rate, site):
            if part and part.upper() not in ('N/A', 'NA', 'NONE') and \
                    not any(part.upper() in m.upper() or m.upper() in part.upper() for m in meta):
                meta.append(part)
        ntags = min(len(row['refs']), 4)
        meta_px = 680 - ntags * 74      # 4.7.8: 22 px font (was 610 - 70 per tag)
        title = _clean(item.get('display_name') or item.get('name'))
        props = {'lucent.quality': q, 'lucent.lowq': 'true' if q in ('CAM', 'SCR', 'TELE', 'HC') else '',
                 'lucent.uncached': '', 'lucent.res': '', 'lucent.icon': '',
                 'abs.svc': _service_code(provider), 'abs.svcicon': ''}
        if th:
            try:
                # too long: drop the site first, then the service name, keep
                # size and the bitrate estimate longest
                for drop in (site, provider, rate):
                    if len(meta) <= 1 or th._px('  ·  '.join(meta).upper()) <= meta_px:
                        break
                    if drop in meta:
                        meta.remove(drop)
                while len(meta) > 1 and th._px('  ·  '.join(meta).upper()) > meta_px:
                    meta.pop()
                props['lucent.title'] = th._fit(title, _TITLE_PX)
                props['lucent.title_full'] = title
                props['lucent.meta'] = th._fit('  ·  '.join(meta), meta_px)
                # 4.6.1: no resolution flags; service icon (AB Wizard
                # artwork, lucent/providers) under the quality pill
                icon = th._provider_icon(provider, site)
                props['abs.svcicon'] = (MEDIA + icon) if icon else ''
                found = self._badges(row)
            except Exception:
                found = []
        else:
            props['lucent.title'], props['lucent.meta'], found = title, '  ·  '.join(meta), []
            props['lucent.title_full'] = title
        for n in range(7):
            props['lucent.badge_%d' % (n + 1)] = found[n] if n < len(found) else ''
        for n in range(4):
            key = row['refs'][n][0] if n < len(row['refs']) else ''
            props['abs.tag_%d' % (n + 1)] = key
            props['abs.tagtxt_%d' % (n + 1)] = self.tags.get(key, ('', ''))[1] if key else ''
        li.setProperties(props)
        return li

    # ---- input ----
    def onClick(self, cid):
        if cid in (VIEW_BTN, VIEW_BTN_X):
            return self._toggle_view()
        if cid in (CHIPS, CHIPS_X):
            pos = self.getControl(cid).getSelectedPosition()
            if 0 <= pos < len(self.chips):
                kind, value = self.chips[pos][0], self.chips[pos][1]
                if kind == 'filter':
                    return self._menu(self._filter_menu)
                with self.ui_lock:
                    if kind == 'all':
                        self.f_addon = self.f_quality = self.f_service = None
                    elif kind == 'addon':
                        self.f_addon = None if self.f_addon == value else value
                    elif kind == 'service':
                        self.f_service = None if self.f_service == value else value
                    else:
                        self.f_quality = None if self.f_quality == value else value
                    self.focused_key = None
                    self._chips()
                    self._rows()
                if self.shown:
                    self.setFocusId(self._lid())
        elif cid in (LIST, LIST_X):
            self._play(None)

    def _menu(self, fn, *args, **kwargs):
        """A nested dialog: no list rebuild under it, catch up when it closes."""
        self._busy += 1
        try:
            return fn(*args, **kwargs)
        finally:
            self._busy -= 1
            self.pump()

    def onAction(self, action):
        self.pump()                             # fallback: any key catches up
        aid = action.getId()
        if aid in _ACTION_BACK:
            if self.filters:                    # Back first drops the filter-menu filters
                self.filters = []
                return self._apply_filters()
            if self.getFocusId() == self._lid() and (self.f_addon or self.f_quality or self.f_service):
                self.setFocusId(self._cid())    # first Back from a filtered list: back to the chips
                return
            self.close()
            return
        if aid in _ACTION_MENU and self.getFocusId() == self._lid():
            self._menu(self._play, choose=True)
        elif aid == _ACTION_RIGHT and self.getFocusId() == LIST:      # one column only: RIGHT moves in the panel
            self._menu(self._filter_menu)

    def _current(self):
        pos = self.getControl(self._lid()).getSelectedPosition()
        return self.shown[pos] if 0 <= pos < len(self.shown) else None

    def _play(self, choose=None):
        row = self._current()
        if not row:
            return
        refs = list(row['refs'])
        if choose and len(refs) > 1:
            pick = xbmcgui.Dialog().contextmenu([T(30826) % self.tags[k][0] for k, _i in refs])
            if pick < 0:
                return
            refs = [refs[pick]]
        self.picked = refs[0]
        self.close()


# ───────────────────────── entry ─────────────────────────

class _Pump(xbmc.Monitor):
    """4.6.13: created on the dialog thread, so Kodi runs onNotification there too."""

    def __init__(self, rid):
        super().__init__()
        self.rid = rid
        self.win = None

    def onNotification(self, sender, method, data):
        if not str(method).endswith('abs_refresh') or self.rid not in str(data or ''):
            return
        win = self.win
        if win is not None:
            try:
                win.pump()
            except Exception as e:
                _log('refresh failed: %s' % e, xbmc.LOGWARNING)


def _focused_meta(tmdb_id):
    """Logo / fanart / plot of the item TMDbHelper was started from."""
    info = xbmc.getInfoLabel
    ids = {info(i).strip() for i in ('ListItem.UniqueID(tmdb)', 'ListItem.Property(tmdb_id)',
                                     'ListItem.UniqueID(tvshow.tmdb)', 'ListItem.Property(tvshow.tmdb_id)')}
    if not tmdb_id or tmdb_id not in ids:
        return {}
    return {'clearlogo': info('ListItem.Art(clearlogo)') or info('ListItem.Art(tvshow.clearlogo)'),
            'fanart': info('ListItem.Art(fanart)') or info('ListItem.Art(tvshow.fanart)'),
            'plot': info('ListItem.Plot'), 'rating': info('ListItem.Rating'), 'mpaa': info('ListItem.Mpaa'),
            'genre': info('ListItem.Genre').replace(' / ', ', '), 'year': info('ListItem.Year'),
            'tvshowtitle': info('ListItem.TVShowTitle'), 'title': info('ListItem.Title'),
            'imdb': info('ListItem.UniqueID(imdb)') or info('ListItem.IMDBNumber'),
            'show_imdb': info('ListItem.UniqueID(tvshow.imdb)') or info('ListItem.Property(tvshow.imdb_id)'),
            'tvdb': info('ListItem.UniqueID(tvdb)'), 'show_tvdb': info('ListItem.UniqueID(tvshow.tvdb)'),
            'premiered': info('ListItem.Premiered')}


def run(params):
    media_type = 'episode' if params.get('media_type') in ('episode', 'tv', 'tvshow') else 'movie'
    tmdb_id = str(params.get('tmdb_id') or params.get('tmdb') or '').strip()
    if not tmdb_id:
        _log('no tmdb_id in %s' % params, xbmc.LOGWARNING)
        return
    media = {'media_type': media_type, 'tmdb_id': tmdb_id}
    if media_type == 'episode':
        media['season'] = str(params.get('season', ''))
        media['episode'] = str(params.get('episode', ''))
    addons = available_addons()
    if not any(ok for *_x, ok in addons):
        xbmcgui.Dialog().ok('ABUKARIM TOOLS', T(30827))
        return
    focused = _focused_meta(tmdb_id)
    meta = {k: v for k, v in params.items() if v and k in ('title', 'tvshowtitle', 'year', 'plot', 'fanart', 'clearlogo', 'ep_name')}
    if params.get('showname') and not meta.get('tvshowtitle'):
        meta['tvshowtitle'] = params['showname']
    # the focused item's own labels win for names: a title with "&" arrives cut from TMDbHelper's URL
    for k in ('title', 'tvshowtitle'):
        if focused.get(k):
            meta[k] = focused[k]
    for k, v in focused.items():
        if v and not meta.get(k):
            meta[k] = v
    # names and other ids for Umbrella (it scrapes by title / IMDb id)
    if media_type == 'episode':
        imdb = focused.get('show_imdb') or params.get('imdb') or ''
        tvdb = focused.get('show_tvdb') or params.get('tvdb') or ''
    else:
        imdb = params.get('imdb') or focused.get('imdb') or ''
        tvdb = ''
    media.update({'title': meta.get('title', ''), 'tvshowtitle': meta.get('tvshowtitle', ''),
                  'year': str(params.get('year') or meta.get('year') or ''), 'imdb': imdb if str(imdb).startswith('tt') else '',
                  'tvdb': tvdb, 'premiered': params.get('premiered') or focused.get('premiered') or ''})
    for k in ('imdb', 'show_imdb', 'tvdb', 'show_tvdb', 'premiered'):
        meta.pop(k, None)
    meta.update({'media_type': media_type, 'tmdb_id': tmdb_id})
    if media_type == 'episode':
        meta.update({'season': media['season'], 'episode': media['episode']})
        if meta.get('tvshowtitle'):          # lucent_window: title = show, ep_name = episode
            meta.setdefault('ep_name', meta.get('title', ''))
            meta['title'] = meta['tvshowtitle']
    session = Session(media, addons)
    pump = _Pump(session.rid)
    win = SearchWindow('ab_search.xml', ADDON_PATH, 'Default', '1080i', session=session, meta=meta)
    pump.win = win
    win.doModal()
    session.closed = True
    pump.win = None
    picked = win.picked
    del win, pump
    if not picked:
        return
    key, index = picked
    if key == 'aio':
        return _aio_play(session, index)
    if key == 'en':
        return _en_play(session, index)
    aid = dict((k, a) for k, a, _n, _t, _ok in addons)[key]
    url = session.url(key, aid, 'play', index)
    _log('play: %s' % url)
    xbmc.executebuiltin('RunPlugin(%s)' % url)
