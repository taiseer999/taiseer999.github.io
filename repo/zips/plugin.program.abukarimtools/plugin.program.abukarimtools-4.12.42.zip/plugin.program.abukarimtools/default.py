# -*- coding: utf-8 -*-
# SPDX-License-Identifier: LicenseRef-ABTools
# Copyright (C) 2025-2026 Taiseer (Abukarim) - AB Tools. All rights reserved, see LICENSE.txt
import sys
import os
from urllib.parse import parse_qsl

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs

ADDON      = xbmcaddon.Addon('plugin.program.abukarimtools')
ADDON_ID   = ADDON.getAddonInfo('id')
try:
    HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
except ValueError:
    HANDLE = -1      # RunScript(plugin.program.abukarimtools, <name>, ...) - see _script_request
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
if not ADDON_PATH.endswith('/') and not ADDON_PATH.endswith('\\'):
    ADDON_PATH += '/'

FANART = ADDON_PATH + 'fanart.jpg'
# 4.8.23: icons, categories, on/off states and values live in menu_model.py,
# shared with the settings window (settings_window.py).
from resources.lib.menu_model import (CATEGORIES, GROUPS, ICON_FILES, icon_rel as _icon_rel,
                                      switch_state as _switch_state,
                                      mode_label2 as _mode_label2)
ICONS = {k: ADDON_PATH + _icon_rel(k) for k in ICON_FILES}
ICONS['settings_view'] = ICONS['cat_toggle']

# Modes that are leaf actions (run then return), not plugin folders.
ACTION_MODES = {'skin_switch', 'settings_view', 'first_run', 'abukarimwizard',
                'total_clean', 'old_thumbs',
                # 3.4.28: Clean Unused Items (dialogs only)
                'build_cleanup',
                # 4.6.31: Fix Add-on Settings Version (dialogs only)
                'settings_v4',
                # 3.1.19: an action, not a folder - as a folder its URL became
                # the container path, so the skin reload re-ran it in a loop
                'af3_trailers', 'af3_waves',
                # 4.7.41: AF3 Plot Text Size (Normal / Small)
                'af3_plotsize',
                # 4.7.36: AF3 Disc Menu for ISO Streams (on/off switch)
                'af3_discmenu',
                # 4.10.9: AF3 Default OSD (on/off switch)
                'af3_defaultosd',
                # 4.12.31: AF3 Watched percentage (on/off switch)
                'af3_percent',
                # 4.8.17: AF3 Classic OSD Flags (on/off switch)
                # 4.8.68: AF3 OSD Flags Style (picker)
                'af3_flagstyle',
                # 4.8.57: AB Tools glass look (on/off switch, test)
                'ab_glass',
                # 4.8.12: Seek Preview (options page)
                'seek_preview',
                # 4.10.0: Search All - My folders (dialogs only)
                'search_folders',
                # 4.11.0: Search All - Usenet (dialogs only)
                'search_usenet',
                # 4.12.1: Najd Smart Subtitles (dialogs only)
                'najd_subs',
                # 4.6.14: AF3 Streaming Services (dialogs only)
                'streaming_rows',
                # 4.6.8: AF3 Lucent Look (Off / Glass / AMOLED picker)
                'af3_lucent',
                # 4.7.25: AF3 Lucent Player (on/off switch)
                'af3_lucentplayer',
                # 4.7.28: Lucent menu + widgets from AF3 (dialogs only)
                'lucent_from_af3',
                # 3.4.39: Lucent Theme per add-on (switch list dialog)
                'lucent_theme',
                # 3.4.6: Font Size (original / +5% / -5%)
                'font_scale',
                # 3.2 tools: dialogs only, never folders (same reason as above)
                'bootstrap', 'hw_tuning', 'webserver', 'log_share',
                'remote_refresh', 'menu_reconcile', 'profile_export',
                'profile_restore', 'support',
                # 3.2.43~beta3: CPU Benchmark (its own text window)
                'cpu_benchmark',
                # 3.2.43~beta7: Widgets Layout (its own window)
                'af3_shortcuts',
                # 3.2.57: Trakt Lists (its own window)
                'trakt_hubs',
                # 3.3.7: setup from the phone (QR window + local server)
                'phone_setup',
                # 4.8.11: Update TMDb Helper Players (dialogs only)
                'players_update'}


def _add_folder(label, cat_key, icon_key):
    url = sys.argv[0] + '?cat=' + cat_key
    li  = xbmcgui.ListItem(label)
    li.setArt({'icon': ICONS[icon_key], 'thumb': ICONS[icon_key], 'fanart': FANART})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def _add_item(label, mode, is_folder=True, switch=None, label2=None):
    url = sys.argv[0] + '?mode=' + mode
    if mode == 'abukarimwizard':
        # Installed: link straight into the wizard's Maintenance menu, so it
        # opens with its own add-on context and Back returns here. Missing:
        # keep our own mode, which offers to install it.
        from resources.lib import wizard_runner
        if wizard_runner.wizard_installed():
            url = wizard_runner.wizard_url(wizard_runner.MODE_MAINTENANCE)
            is_folder = True
    if switch is None:
        li  = xbmcgui.ListItem(label, label2 or '')
        li.setArt({'icon': ICONS[mode], 'thumb': ICONS[mode], 'fanart': FANART})
    else:
        # 3.2.23: on/off entries show the switch art + On/Off as label2
        from resources.lib import toggle_ui
        li = toggle_ui.item(label, switch)
        # feature glyph + switch badge (<mode>_on/off.png) when there is one
        own = ADDON_PATH + 'resources/icons/%s_%s.png' % (mode, 'on' if switch else 'off')
        from resources.lib import glass_look
        own = glass_look.icon(own)
        if os.path.isfile(own):
            li.setArt({'icon': own, 'thumb': own})
        li.setArt({'fanart': FANART})
    if not is_folder:
        li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)


def _ensure_fallback_font():
    """Self-heal: install the Arabic-capable global fallback font when the menu
    is opened, so Arabic is readable even if the boot service didn't run (e.g.
    service disabled, or on the very first open before a restart). Best-effort;
    a change only takes effect on the next Kodi start."""
    try:
        from resources.lib import font_fallback
        font_fallback.install()
    except Exception:
        pass


def _ensure_patches():
    """Self-heal: re-apply the automatic patch set when the menu is opened, in
    case the background watchdog service never ran this session.

    3.1.0.11: no longer a daemon thread inside this plugin invocation. The
    plugin exits in milliseconds and Kodi finalized the interpreter while the
    thread was mid-sweep, which on Kodi 22 / Python 3.14 stopped the menu from
    opening. The sweep now runs as its own RunPlugin invocation (mode
    'menu_sweep'), synchronously on that invocation's main thread, so the menu
    never waits on it and nothing is left running when either script ends.
    Every patch is idempotent, so a redundant sweep writes nothing.
    """
    try:
        xbmc.executebuiltin('RunPlugin(plugin://%s/?mode=menu_sweep)' % ADDON_ID)
    except Exception:
        pass


def _ensure_service():
    """3.1.10: Kodi sometimes never launches our xbmc.service at boot (zero
    [AbukarimTools] lines in a full boot log), which silently kills the
    auto-patch watchdog and the boot-time repo linking. The service sets a Home
    heartbeat property; if it is missing when the menu opens, start
    service.py ourselves as a script (it runs for the whole session)."""
    try:
        home = xbmcgui.Window(10000)
        if home.getProperty('abukarimtools.service.alive'):
            return
        if home.getProperty('abukarimtools.service.alive.kick'):
            return                      # already kicked this session
        home.setProperty('abukarimtools.service.alive.kick', '1')
        xbmc.log('[AbukarimTools Menu] service not running - starting it',
                 xbmc.LOGWARNING)
        xbmc.executebuiltin('RunPlugin(plugin://%s/?run=service)' % ADDON_ID)
    except Exception as e:
        xbmc.log('[AbukarimTools Menu] could not start service: %s' % e,
                 xbmc.LOGWARNING)


def _menu_relink():
    """Link add-ons with an empty update source whenever the menu opens,
    independent of the service. Quick: one SQLite pass over the cached repo
    listings; a repo refresh (slow) is left to the service."""
    try:
        from resources.lib import origin_fix
        res = origin_fix.fix_addons(None)
        if res.get('fixed'):
            xbmc.log('[AbukarimTools Menu] linked on menu open: %s'
                     % ', '.join('%s -> %s' % kv for kv in sorted(res['fixed'].items())),
                     xbmc.LOGINFO)
        if res.get('unmatched'):
            xbmc.log('[AbukarimTools Menu] no repository carries: %s'
                     % ', '.join(sorted(res['unmatched'])), xbmc.LOGINFO)
        # 3.2.22: no automatic UpdateAddonRepos on menu open any more (an add-on
        # that only an older listing carries kept forcing a full repo refresh
        # every session). "Fix Add-on Update Origins" refreshes on demand.
        if res.get('fixed'):
            from resources.lib.i18n import T
            xbmcgui.Dialog().notification(
                'ABUKARIM TOOLS', T(30337) % len(res['fixed']),
                xbmcgui.NOTIFICATION_INFO, 8000)
    except Exception as e:
        xbmc.log('[AbukarimTools Menu] relink failed: %s' % e, xbmc.LOGWARNING)


def _menu_sweep():
    """Body of the 'menu_sweep' invocation. Main thread, no directory."""
    _ensure_service()
    _menu_relink()
    try:
        from resources.lib import patch_watchdog, patcher
        if patch_watchdog.first_run_active():
            return                      # never sweep under first-run dialogs
        # 4.12.37: the self-heal is for a session WITHOUT a watchdog. With
        # one alive it already sweeps at boot, after every update and every
        # 30 min - a second full pass here only doubled the boot load (two
        # 434-entry runs side by side while Home loaded its widgets).
        if patch_watchdog.watchdog_alive():
            xbmc.log('[AbukarimTools MenuSweep] watchdog is running - skipped', xbmc.LOGDEBUG)
            return
        if patcher.patch_run_active():
            xbmc.log('[AbukarimTools MenuSweep] a patch run is in progress - skipped', xbmc.LOGDEBUG)
            return
        age = patcher.last_run_age()
        if age is not None and age < 600:
            xbmc.log('[AbukarimTools MenuSweep] last run %ds ago - skipped' % age, xbmc.LOGDEBUG)
            return
        ids = [a for a in patcher.target_addon_ids() if patch_watchdog._addon_path(a)]
        if ids:
            patcher.apply_set(addon_ids=ids)
            patcher.reload_skin_if_pending()
    except Exception as e:
        xbmc.log('[AbukarimTools MenuSweep] failed: %s' % e, xbmc.LOGWARNING)


def _continue_addons33_rebuild():
    """If an Addons33 rebuild is mid-flight (phase 2: DB deleted, Kodi has
    rebuilt a fresh one), finish it when the menu is opened even if the boot
    service never ran. No-op otherwise.

    3.1.7: no longer runs inline. Phase 2 waits ~25 s, enables add-ons and
    reboots; doing that inside this directory listing blocked the menu (the
    box looked frozen on "Programs"). It now runs as its own RunPlugin
    invocation (mode=addons33_continue), like the menu sweep."""
    try:
        from resources.lib import addons33_rebuild
        if addons33_rebuild._read_step() == '2':
            xbmc.executebuiltin(
                'RunPlugin(plugin://%s/?mode=addons33_continue)' % ADDON_ID)
    except Exception:
        pass


def _mlog(msg):
    """Menu-open trace (DEBUG level; was WARNING in the 3.1.0.13/14 diagnostics)."""
    try:
        xbmc.log('[AbukarimTools Menu] %s' % msg, xbmc.LOGDEBUG)
    except Exception:
        pass


def main_menu():
    _mlog('open: start (argv=%r)' % (sys.argv,))
    from resources.lib.i18n import T
    _mlog('i18n imported')
    _continue_addons33_rebuild()
    _mlog('addons33 continue checked')
    _ensure_fallback_font()
    _mlog('fallback font checked')
    for cat_key, label_id, icon_key, _items in CATEGORIES:
        label = T(label_id)
        _mlog('item %s: label ok' % cat_key)
        _add_folder(label, cat_key, icon_key)
        _mlog('item %s: added' % cat_key)
    # 3.2.33: Buy Me a Coffee (opens a QR)
    _add_item(T(30610), 'support', is_folder=False)
    # 4.8.23: back to the settings window (the plain launch opens it again)
    _add_item(T(32191), 'settings_view', is_folder=False)
    xbmcplugin.setContent(HANDLE, 'files')
    _mlog('setContent done - calling endOfDirectory')
    xbmcplugin.endOfDirectory(HANDLE)
    _mlog('endOfDirectory returned')
    # The self-heal sweep is queued only AFTER the listing is handed back, so
    # nothing it does can overlap with building the menu.
    _ensure_patches()
    _mlog('sweep queued - done')


def category_menu(cat_key):
    from resources.lib.i18n import T
    # 4.9.3: a group of the Mods category lists like a category of its own
    cats = list(CATEGORIES) + [(k, g[0], k, g[2]) for k, g in GROUPS.items()]
    for c_key, _label_id, _icon, items in cats:
        if c_key != cat_key:
            continue
        for mode, label_id in items:
            if mode in GROUPS:
                _add_folder(T(label_id), mode, mode)
                continue
            # 4.6.31: listed only on a box whose Kodi rejects newer
            # addon_data settings.xml files (see settings_downgrade.py)
            if mode == 'settings_v4':
                from resources.lib import settings_downgrade
                if not settings_downgrade.applicable():
                    continue
            label = T(label_id)
            _add_item(label, mode, is_folder=(mode not in ACTION_MODES),
                      switch=_switch_state(mode), label2=_mode_label2(mode))
        break
    xbmcplugin.setContent(HANDLE, 'files')
    # not cached: the Toggles list shows live on/off states
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _wants_settings_window():
    """True when the user opened the add-on itself (Programs / Add-ons), not
    when a widget or another container is listing its root path."""
    if HANDLE < 0:
        return False
    try:
        from resources.lib import settings_window
        if not settings_window.enabled():
            return False
        return bool(xbmc.getCondVisibility(
            'Window.IsActive(programs) | Window.IsActive(addonbrowser) | '
            'Window.IsActive(addoninformation)'))
    except Exception:
        return False


def _end_directory():
    # 4.8.23: entries started from the settings window run as RunPlugin
    # (handle -1): there is no listing to end.
    if HANDLE < 0:
        return
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True,
                               updateListing=False, cacheToDisc=False)


def router():
    raw     = sys.argv[2][1:] if len(sys.argv) > 2 else ''
    params  = dict(parse_qsl(raw))
    mode    = params.get('mode')
    cat     = params.get('cat')      # set when a category folder is opened

    # --- Category folder ---
    if cat is not None and mode is None:
        category_menu(cat)
        return

    # --- Top-level menu ---
    if mode is None:
        # 4.8.23: a plain launch opens the settings window (categories on one
        # side, entries on the other, like the skin's own settings). The
        # classic listing stays for ?view=list and for any widget / shortcut
        # that lists this path while its window is not the one being opened.
        if params.get('view') != 'list' and _wants_settings_window():
            _continue_addons33_rebuild()
            _ensure_fallback_font()
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            xbmc.executebuiltin('RunPlugin(plugin://%s/?mode=settings_window)' % ADDON_ID)
            _ensure_patches()
            return
        main_menu()
        # 4.8.61: classic list opened by the user after an update
        if HANDLE >= 0 and xbmc.getCondVisibility('Window.IsActive(programs) | Window.IsActive(addonbrowser)'):
            xbmc.executebuiltin('RunPlugin(plugin://%s/?mode=whats_new)' % ADDON_ID)
        return

    if mode == 'whats_new':
        from resources.lib import whats_new
        if params.get('force'):
            whats_new.show()
        else:
            whats_new.maybe_show()
        return

    if mode == 'settings_view':
        # 4.8.23: classic list -> settings window again
        from resources.lib import settings_window
        settings_window.set_enabled(True)
        xbmc.executebuiltin('RunPlugin(plugin://%s/?mode=settings_window)' % ADDON_ID)
        return

    if mode == 'settings_window':
        # 4.8.23: handle -1 invocation; the window runs here until closed.
        # 4.8.61: after an update, What's New first (once).
        if not params.get('cat'):
            from resources.lib import whats_new
            whats_new.maybe_show()
        from resources.lib import settings_window
        settings_window.open_window(params.get('cat'))
        return

    if mode == 'menu_sweep':
        _menu_sweep()
        return

    if mode == 'addons33_continue':
        try:
            from resources.lib import addons33_rebuild
            addons33_rebuild.continue_if_pending(xbmc.Monitor())
        except Exception as e:
            xbmc.log('[AbukarimTools Addons33] continue failed: %s' % e,
                     xbmc.LOGWARNING)
        return

    if mode == 'first_run':
        # Non-folder action (3.1.0.20): no plugin listing is opened, and the
        # sequence runs as its own RunPlugin invocation (mode=first_run_exec), detached from this
        # plugin call and from the Programs container (whose refreshes during
        # add-on rescans were tearing setup dialogs down).
        from resources.lib.i18n import T
        if xbmcgui.Dialog().yesno(
                'ABUKARIM TOOLS',
                T(30050),
                yeslabel=T(30051), nolabel=T(30052)):
            # RunPlugin (not RunScript-by-path, which has no add-on context:
            # 3.1.0.20 crashed with "No valid addon id could be obtained").
            # handle=-1 invocation, detached from any directory listing.
            xbmc.executebuiltin(
                'RunPlugin(plugin://%s/?mode=first_run_exec)' % ADDON_ID)
        return

    if mode == 'first_run_exec':
        import_root = ADDON_PATH.rstrip('/\\')
        if import_root not in sys.path:
            sys.path.insert(0, import_root)
        import service
        service.run_now(remove_flag=True, force=True)
        return

    if mode == 'subtitle_list':
        # 4.6.14: AF3 OSD subtitle button while the Lucent Look is on
        from resources.lib import sub_list
        sub_list.open_list()
        return

    if mode == 'subtitle_style':
        # 4.6.2: AF3 OSD Subtitle Look button - height / font size / font panel.
        from resources.lib import sub_quick
        sub_quick.open_window()
        return

    if mode == 'disc_menu':
        # 4.7.36: AF3 OSD Disc Menu / Normal Player buttons (ISO streams)
        from resources.lib import disc_menu
        disc_menu.run(params.get('go', 'menu'))
        return

    if mode == 'subtitle_cycler':
        # 3.3.2: AF3 OSD Subtitle Cycler button when script.subtitle.cycler
        # is missing/disabled - install it from repository.taiseer, then run it.
        from resources.lib import subtitle_tools
        subtitle_tools.osd_cycler()
        return

    if mode == 'skin_install':
        _end_directory()
        from resources.lib import skin_installer
        skin_installer.run()

    elif mode == 'af3_shortcuts':
        from resources.lib import af3_shortcuts
        af3_shortcuts.run_menu()
    elif mode == 'trakt_hubs':
        from resources.lib import trakt_hubs
        trakt_hubs.run_menu()
    elif mode == 'streaming_rows':
        from resources.lib import streaming_rows
        streaming_rows.run()

    elif mode == 'phone_setup':
        from resources.lib import phone_setup
        phone_setup.run()

    elif mode == 'addon_portal':
        _end_directory()
        from resources.lib import addon_portal
        addon_portal.run()

    elif mode == 'skin_switch':
        # Non-folder action: don't open/close a plugin listing (that leaves an
        # empty container with a back arrow). Just run; the switcher closes
        # to the new skin's Home itself via _close_to_home().
        from resources.lib import skin_switcher
        skin_switcher.run()

    elif mode == 'backup':
        _end_directory()
        from resources.lib import backup_manager
        backup_manager.BackupManager().run()

    elif mode == 'abukarimwizard':
        # Non-folder action: only reached when the wizard link could not be
        # used (wizard missing) or from an old favourite/shortcut.
        from resources.lib import wizard_runner
        wizard_runner.open_wizard()

    elif mode == 'total_clean':
        from resources.lib import wizard_runner
        wizard_runner.run_total_clean()

    elif mode == 'old_thumbs':
        from resources.lib import wizard_runner
        wizard_runner.run_old_thumbs()

    elif mode == 'build_cleanup':
        from resources.lib import build_cleanup
        build_cleanup.run()

    elif mode == 'openwizard':
        # Legacy URL (<= 3.1.2 favourites / skin shortcuts), which were
        # opened as a folder: close that listing, then hand off.
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        from resources.lib import wizard_runner
        wizard_runner.open_wizard()

    elif mode == 'patcher':
        _end_directory()
        from resources.lib import patcher
        patcher.run()

    elif mode == 'players_update':
        _end_directory()
        from resources.lib import players_update
        players_update.run()

    elif mode == 'rebuild_addons33':
        _end_directory()
        from resources.lib import addons33_rebuild
        addons33_rebuild.run()

    elif mode == 'settings_v4':
        _end_directory()
        from resources.lib import settings_downgrade
        settings_downgrade.run()

    elif mode == 'speedtest':
        _end_directory()
        # Ookla speedtest-cli vendored at resources/lib/modules/speedtest.py.
        # Run it as a standalone script (RunScript adds its own directory to
        # sys.path so the sibling backtothefuture import resolves) — it draws
        # its own DialogProgress and shows the result image on completion.
        script = ADDON_PATH + 'resources/lib/modules/speedtest.py'
        xbmc.executebuiltin('RunScript(%s)' % script)

    elif mode == 'cpu_benchmark':
        # pystone CPU benchmark (port of script.pystone.benchmark) - runs in
        # the active skin's DialogTextViewer, no folder listing.
        from resources.lib import cpu_benchmark
        cpu_benchmark.run()

    elif mode == 'binary_install':
        _end_directory()
        from resources.lib import binary_installer
        binary_installer.run()

    elif mode == 'dplex_toggle':
        _end_directory()
        from resources.lib import dplex_toggle
        dplex_toggle.run()

    elif mode == 'korean_toggle':
        _end_directory()
        from resources.lib import korean_toggle
        korean_toggle.run()

    elif mode == 'ab_glass':
        from resources.lib import glass_look
        glass_look.toggle()
        xbmc.executebuiltin('Container.Refresh')

    elif mode == 'icons_toggle':
        _end_directory()
        from resources.lib import icons_toggle
        icons_toggle.run()

    elif mode == 'af3_trailers':
        from resources.lib import af3_trailers_toggle
        af3_trailers_toggle.run()

    elif mode == 'af3_waves':
        from resources.lib import af3_waves_toggle
        af3_waves_toggle.run()
    elif mode == 'af3_lucent':
        from resources.lib import af3_lucent_toggle
        af3_lucent_toggle.run()
    elif mode == 'af3_plotsize':
        from resources.lib import af3_plotsize
        af3_plotsize.run()
    elif mode == 'seek_preview':
        from resources.lib import seek_preview_toggle
        seek_preview_toggle.run()
    elif mode == 'search_folders':
        from resources.lib import local_folders
        local_folders.run()
    elif mode == 'search_usenet':           # 4.11.0
        from resources.lib import usenet_stream
        usenet_stream.run()
    elif mode == 'najd_subs':               # 4.12.1
        from resources.lib import najd_subs
        najd_subs.run()

    elif mode == 'af3_discmenu':
        from resources.lib import af3_discmenu_toggle
        af3_discmenu_toggle.run()
    elif mode == 'af3_defaultosd':
        from resources.lib import af3_defaultosd_toggle
        af3_defaultosd_toggle.run()
    elif mode == 'af3_percent':
        from resources.lib import af3_percent_toggle
        af3_percent_toggle.run()
    elif mode == 'af3_classicflags':        # 4.8.77: retired - now "Off" in OSD Flags Style
        from resources.lib import af3_flagstyle
        af3_flagstyle.run()
    elif mode == 'af3_flagstyle':
        from resources.lib import af3_flagstyle
        af3_flagstyle.run()
    elif mode == 'af3_lucentplayer':
        from resources.lib import af3_lucentplayer_toggle
        af3_lucentplayer_toggle.run()
    elif mode == 'lucent_from_af3':
        from resources.lib import lucent_from_af3
        lucent_from_af3.run()
    elif mode == 'lucent_theme':
        from resources.lib import lucent_toggle
        lucent_toggle.run()
    elif mode == 'ab_search':
        _ensure_service()       # 4.11.4: Search All alone (from a context menu) also starts the service
        from resources.lib import ab_search
        ab_search.run(params)
    elif mode == 'font_scale':
        from resources.lib import font_scale
        font_scale.run()

    elif mode == 'origin_fix':
        _end_directory()
        from resources.lib import origin_fix
        origin_fix.run()

    # ---- 3.2 ----
    elif mode == 'bootstrap':
        from resources.lib import bootstrap
        from resources.lib.i18n import T
        if not bootstrap.pending():
            xbmcgui.Dialog().notification('ABUKARIM TOOLS', T(30542))
        else:
            bootstrap.run()

    elif mode == 'hw_tuning':
        from resources.lib import hw_tuning
        hw_tuning.run()

    elif mode == 'webserver':
        from resources.lib import webserver_secure
        webserver_secure.run()

    elif mode == 'support':
        from resources.lib import support
        support.show()

    elif mode == 'log_share':
        from resources.lib import log_share
        log_share.run()

    elif mode == 'remote_refresh':
        from resources.lib import remote_config
        from resources.lib.i18n import T
        res = remote_config.refresh(force=True)
        lines = ['%s: %s' % kv for kv in sorted(res.items())]
        # 3.2.6: apply what was just downloaded now, not at the next sweep
        try:
            from resources.lib import patcher, patch_watchdog
            ids = [a for a in patcher.target_addon_ids() if patch_watchdog._addon_path(a)]
            ok_n, fail_n, written, _r = patcher.apply_set(addon_ids=ids)
            lines.append('')
            lines.append('patches: %d OK, %d failed, %d written' % (ok_n, fail_n, written))
        except Exception as e:
            lines.append('patches: %s' % e)
        xbmcgui.Dialog().ok('ABUKARIM TOOLS', T(30599) % '[CR]'.join(lines))

    elif mode == 'menu_reconcile':
        from resources.lib import menu_reconcile
        from resources.lib.i18n import T
        res = menu_reconcile.run(rebuild=True)
        xbmcgui.Dialog().notification('ABUKARIM TOOLS', T(30589) % (res['hidden'], res['shown']))

    elif mode == 'profile_export':
        from resources.lib import skin_profiles
        skin_profiles.export_current()

    elif mode == 'profile_restore':
        from resources.lib import skin_profiles
        skin_profiles.restore_backup()



# ---------------------------------------------------------------------------
# 4.7.14: stand-alone scripts run THROUGH the add-on.
# RunScript(special://.../service.py) runs a file with no add-on attached, so
# Kodi 22 logs "Script invoked without an addon ... will be removed in future
# version" and puts every installed module on sys.path. These now start as
#     RunPlugin(plugin://plugin.program.abukarimtools/?run=<name>[&args=a,b])
# (add-on context, no warning). RunScript(plugin.program.abukarimtools, <name>)
# also lands here; it used to crash on int('firstrun').
# ---------------------------------------------------------------------------
_RUN_SCRIPTS = {
    'service':      'service.py',
    'guardian':     'guardian.py',
    'trailers':     'trailers.py',
    'trailer_play': 'trailer_play.py',
    'firstrun':     'run.py',
}


def _script_request():
    """(name, args) when this invocation should run a stand-alone script."""
    argv = sys.argv
    if len(argv) > 1:
        try:
            int(argv[1])
        except ValueError:                       # RunScript(id, name, ...)
            name = argv[1].strip().lower()
            if name in _RUN_SCRIPTS:
                return name, [a.strip() for a in argv[2:]]
            xbmc.log('[AbukarimTools Menu] unknown RunScript entry %r' % argv[1],
                     xbmc.LOGWARNING)
            return 'none', []
    raw = argv[2][1:] if len(argv) > 2 else ''
    params = dict(parse_qsl(raw))
    name = params.get('run')
    if name in _RUN_SCRIPTS and 'mode' not in params and 'cat' not in params:
        return name, [a for a in (params.get('args') or '').split(',') if a]
    return None


def _run_script(name, args):
    if name not in _RUN_SCRIPTS:
        return
    import runpy
    path = ADDON_PATH + _RUN_SCRIPTS[name]
    sys.argv = [path] + list(args)
    runpy.run_path(path, run_name='__main__')


_REQ = _script_request()
if _REQ:
    _run_script(*_REQ)
else:
    router()
