# -*- coding: utf-8 -*-
# SPDX-License-Identifier: LicenseRef-ABTools
# Copyright (C) 2025-2026 Taiseer (Abukarim) - AB Tools. All rights reserved, see LICENSE.txt
"""Generate the Lucent window XMLs for Fen Light, Red Light, POV and Umbrella.

Dev tool (not used at runtime). Output: resources/lucent/xml/<profile>/<file>.xml

Look and textures: "Lucent" theme for Seren by djdirty60
(https://github.com/djdirty60/Seren-Thema). Every window here reads the shared
lucent.* properties written by resources/lucent/lucent_theme.py, plus the
add-on's own control ids / properties that its Python code depends on.

Run:  python3 tools/gen_lucent.py
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'resources', 'lucent', 'xml')
BADGES_SHOWN = 7

BG = '0B1119'


def esc(text):
    return text.replace('&', '&amp;')


# ───────────────────────── shared building blocks ─────────────────────────

def backdrop(fanart):
    return '''
        <!-- ============ Cinematic backdrop ============ -->
        <control type="group">
            <control type="image">
                <texture>lucent/white.png</texture>
                <colordiffuse>FF%(bg)s</colordiffuse>
            </control>
            <control type="image">
                <animation effect="fade" start="0" end="100" time="500">WindowOpen</animation>
                <aspectratio>scale</aspectratio>
                <texture background="true">%(fanart)s</texture>
            </control>
            <control type="image">
                <width>1500</width>
                <texture>lucent/grad_left.png</texture>
                <colordiffuse>F5%(bg)s</colordiffuse>
            </control>
            <control type="image">
                <top>440</top>
                <height>640</height>
                <texture>lucent/grad_bottom.png</texture>
                <colordiffuse>FF%(bg)s</colordiffuse>
            </control>
            <control type="image">
                <height>260</height>
                <texture>lucent/grad_top.png</texture>
                <colordiffuse>99%(bg)s</colordiffuse>
            </control>
            <control type="image">
                <texture>lucent/vignette.png</texture>
                <colordiffuse>99000000</colordiffuse>
            </control>
        </control>
''' % {'bg': BG, 'fanart': fanart}


def pill(label, visible, edge=False, bright=False):
    tex = 'lucent/pill44_edge.png' if edge else 'lucent/pill44.png'
    diffuse = '2EFFFFFF' if bright else '1AFFFFFF'
    color = 'FFFFFFFF' if bright else 'FFDCE2E7'
    return '''
                <control type="button">
                    <width>auto</width>
                    <height>44</height>
                    <font>font12</font>
                    <textoffsetx>20</textoffsetx>
                    <aligny>center</aligny>
                    <textcolor>%(c)s</textcolor>
                    <disabledcolor>%(c)s</disabledcolor>
                    <texturenofocus border="22" colordiffuse="%(d)s">%(t)s</texturenofocus>
                    <texturefocus border="22" colordiffuse="%(d)s">%(t)s</texturefocus>
                    <enable>false</enable>
                    <label>%(l)s</label>
                    <visible>%(v)s</visible>
                </control>''' % {'c': color, 'd': diffuse, 't': tex, 'l': label, 'v': visible}


def title_block(fade_cond=None, extra_anim='', ep_title=True, top=96, logo_h=220, pills_top=252):
    """Logo / title, meta pills and episode title (top of the left column).
    ep_title=False: no episode title line (Search All shows it under the plot)."""
    W = 'Window.Property(lucent.%s)'
    ept_xml = '''
            <control type="label">
                <top>320</top>
                <width>720</width>
                <height>44</height>
                <font>font27</font>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[%(ept)s][/B]</label>
                <visible>!String.IsEmpty(%(ept)s)</visible>
            </control>''' % {'ept': W % 'ep_title'} if ep_title else ''
    hide = ''
    if fade_cond:
        hide = '\n            <animation effect="fade" end="0" time="200" condition="%s">Conditional</animation>' % fade_cond
    return '''
        <!-- ============ Left column: logo / title / meta ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="100">WindowOpen</animation>
            <animation effect="slide" start="-60,0" end="0,0" time="350" delay="100" tween="cubic" easing="out">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>%(extra)s
            <left>96</left>
            <top>%(top)d</top>
            <width>720</width>
            <control type="image">
                <width>560</width>
                <height>%(logo_h)d</height>
                <aspectratio align="left" aligny="bottom">keep</aspectratio>
                <texture>$INFO[%(logo)s]</texture>
                <visible>!String.IsEmpty(%(logo)s)</visible>
            </control>
            <control type="textbox">
                <top>%(title_top)d</top>
                <width>720</width>
                <height>160</height>
                <font>font37</font>
                <textcolor>FFFFFFFF</textcolor>
                <aligny>bottom</aligny>
                <label>[B]$INFO[%(show)s][/B]</label>
                <visible>String.IsEmpty(%(logo)s)</visible>
            </control>
            <control type="grouplist">
                <top>%(pills_top)d</top>
                <height>44</height>
                <width>720</width>
                <orientation>horizontal</orientation>
                <itemgap>12</itemgap>
                <usecontrolcoords>true</usecontrolcoords>%(pills)s
            </control>%(ept)s
        </control>
''' % {
        'extra': hide + extra_anim, 'ept': ept_xml, 'top': top, 'logo_h': logo_h,
        'title_top': logo_h - 160, 'pills_top': pills_top,
        'logo': W % 'clearlogo', 'show': W % 'show_title',
        'pills': ''.join([
            pill('[B]$INFO[%s][/B]' % (W % 'ep_code'), '!String.IsEmpty(%s)' % (W % 'ep_code'), bright=True),
            pill('$INFO[%s]' % (W % 'year'), '!String.IsEmpty(%s)' % (W % 'year')),
            pill('★ $INFO[%s]' % (W % 'rating'), '!String.IsEmpty(%s)' % (W % 'rating')),
            pill('$INFO[%s]' % (W % 'mpaa'), '!String.IsEmpty(%s)' % (W % 'mpaa'), edge=True),
            pill('$INFO[%s]' % (W % 'genre'), '!String.IsEmpty(%s) + String.IsEmpty(%s)' % (W % 'genre', W % 'ep_code')),
        ])}


def plot_block(label, top=476, height=330, fade_cond=None, visible=None, font='font12'):
    hide = ''
    if fade_cond:
        hide = '\n            <animation effect="fade" end="0" time="200" condition="%s">Conditional</animation>' % fade_cond
    vis = '\n            <visible>%s</visible>' % visible if visible else ''
    return '''
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="150">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>%(hide)s%(vis)s
            <left>96</left>
            <top>%(top)d</top>
            <control type="textbox">
                <width>700</width>
                <height>%(h)d</height>
                <font>%(f)s</font>
                <textcolor>FFBDC8D1</textcolor>
                <label>%(l)s</label>
                <autoscroll delay="6000" time="2500" repeat="8000">true</autoscroll>
            </control>
        </control>
''' % {'hide': hide, 'vis': vis, 'top': top, 'h': height, 'l': label, 'f': font}


def glass(left, top, width, height):
    """Shadow + glass body + hairline edge, sized to the enclosing group."""
    return '''
            <control type="image">
                <left>-40</left>
                <top>-40</top>
                <width>%(w)d</width>
                <height>%(h)d</height>
                <texture border="88">lucent/panel_shadow.png</texture>
                <colordiffuse>99000000</colordiffuse>
            </control>
            <control type="image">
                <width>%(iw)d</width>
                <height>%(ih)d</height>
                <texture border="48">lucent/panel.png</texture>
                <colordiffuse>E0162532</colordiffuse>
            </control>
            <control type="image">
                <width>%(iw)d</width>
                <height>%(ih)d</height>
                <texture border="48">lucent/panel_edge.png</texture>
                <colordiffuse>2EFFFFFF</colordiffuse>
            </control>''' % {'w': width + 80, 'h': height + 80, 'iw': width, 'ih': height}


def action_button(cid, label, visible=None, nav=''):
    vis = '\n                    <visible>%s</visible>' % visible if visible else ''
    return '''
                <control type="button" id="%(id)s">
                    <width>auto</width>
                    <height>64</height>
                    <font>font12</font>
                    <textoffsetx>30</textoffsetx>
                    <align>center</align>
                    <aligny>center</aligny>
                    <textcolor>FFFFFFFF</textcolor>
                    <focusedcolor>FF%(bg)s</focusedcolor>
                    <texturefocus border="32" colordiffuse="FFFFFFFF">lucent/pill64.png</texturefocus>
                    <texturenofocus border="32" colordiffuse="24FFFFFF">lucent/pill64.png</texturenofocus>
                    <pulseonselect>false</pulseonselect>
                    <label>[B]%(l)s[/B]</label>%(nav)s%(vis)s
                </control>''' % {'id': cid, 'bg': BG, 'l': label, 'vis': vis, 'nav': nav}


def segmented_bar(prop, width=760, segments=40, top=0, left=0, visible=None):
    seg = width // segments
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    out = [('''
            <control type="group">
                <left>%d</left>
                <top>%d</top>
                <width>%d</width>
                <height>6</height>''' + vis + '''
                <control type="image">
                    <width>%d</width>
                    <height>6</height>
                    <texture border="3">lucent/pill6.png</texture>
                    <colordiffuse>1FFFFFFF</colordiffuse>
                </control>''') % (left, top, width, seg * segments)]
    for n in range(segments):
        threshold = max(1, int(round((n + 1) * 100.0 / segments)) - 1)
        out.append('''
                <control type="image">
                    <left>%d</left>
                    <width>%d</width>
                    <height>6</height>
                    <texture>lucent/white.png</texture>
                    <colordiffuse>FFFFFFFF</colordiffuse>
                    <visible>Integer.IsGreaterOrEqual(%s,%d)</visible>
                </control>''' % (n * seg, seg, prop, threshold))
    out.append('\n            </control>')
    return ''.join(out)


def native_progress(cid, top, left=40, width=760):
    return '''
            <control type="progress" id="%(id)s">
                <left>%(l)d</left>
                <top>%(t)d</top>
                <width>%(w)d</width>
                <height>6</height>
                <reveal>true</reveal>
                <texturebg border="3" colordiffuse="1FFFFFFF">lucent/pill6.png</texturebg>
                <lefttexture />
                <midtexture border="3" colordiffuse="FFFFFFFF">lucent/pill6.png</midtexture>
                <righttexture />
                <overlaytexture />
            </control>''' % {'id': cid, 't': top, 'l': left, 'w': width}


def spinner(visible, left, top):
    return '''
            <control type="image">
                <left>%d</left>
                <top>%d</top>
                <width>16</width>
                <height>16</height>
                <texture>lucent/dot.png</texture>
                <colordiffuse>FFFFFFFF</colordiffuse>
                <animation effect="fade" start="100" end="25" time="600" pulse="true" condition="true">Conditional</animation>
                <visible>%s</visible>
            </control>''' % (left, top, visible)


# ───────────────────────── stream cards ─────────────────────────

def badge_row(diffuse):
    out = []
    for n in range(1, BADGES_SHOWN + 1):
        out.append('''
                            <control type="image">
                                <left>%d</left>
                                <width>88</width>
                                <height>34</height>
                                <aspectratio>keep</aspectratio>
                                <texture>$INFO[ListItem.Property(lucent.badgepath_%d)]</texture>
                                <colordiffuse>%s</colordiffuse>
                                <visible>!String.IsEmpty(ListItem.Property(lucent.badge_%d))</visible>
                            </control>''' % ((n - 1) * 96, n, diffuse, n))
    return ''.join(out)


def card(state, profile):
    """state: 'idle' (itemlayout), 'dim' (focused item, list not focused), 'active'."""
    full = profile['full_prop']
    active = state == 'active'
    if state == 'idle':
        body = '''
                        <control type="image">
                            <texture border="32">lucent/card.png</texture>
                            <colordiffuse>0FFFFFFF</colordiffuse>
                        </control>'''
    elif state == 'dim':
        body = '''
                        <control type="image">
                            <texture border="32">lucent/card.png</texture>
                            <colordiffuse>24FFFFFF</colordiffuse>
                        </control>
                        <control type="image">
                            <texture border="32">lucent/card_edge.png</texture>
                            <colordiffuse>40FFFFFF</colordiffuse>
                        </control>'''
    else:
        body = '''
                        <control type="image">
                            <left>-24</left>
                            <top>-24</top>
                            <width>952</width>
                            <height>172</height>
                            <texture border="56">lucent/card_glow.png</texture>
                            <colordiffuse>66D6F0FF</colordiffuse>
                        </control>
                        <control type="image">
                            <texture border="32">lucent/card.png</texture>
                            <colordiffuse>FF2C3E4C</colordiffuse>
                        </control>
                        <control type="image">
                            <texture border="32">lucent/card_edge.png</texture>
                            <colordiffuse>F2FFFFFF</colordiffuse>
                        </control>'''
    zoom = ('\n                    <animation effect="zoom" start="98" end="100" center="auto" time="180" '
            'tween="cubic" easing="out">Focus</animation>') if active else ''
    pill_diffuse = 'FFFFFFFF' if active else '1AFFFFFF'
    pill_text = 'FF%s' % BG if active else 'FFDCE2E7'
    title_color = 'FFFFFFFF' if active else 'CCFFFFFF'
    meta_color = 'FFDCE2E7' if active else 'FF8F9BA6'
    badge_diffuse = '$INFO[ListItem.Property(lucent.badgelit)]' if active else '$INFO[ListItem.Property(lucent.badgedim)]'  # 4.8.76
    title_label = '[B]$INFO[ListItem.Property(lucent.title)][/B]' if active else '$INFO[ListItem.Property(lucent.title)]'
    scroll = ''
    full_label = profile['full_label']
    return '''
                <control type="group">
                    <left>16</left>
                    <top>12</top>
                    <width>904</width>
                    <height>124</height>%(zoom)s%(body)s
                    <!-- Stream -->
                    <control type="group">
                        <visible>String.IsEmpty(ListItem.Property(%(full)s))</visible>
                        <control type="image">
                            <left>20</left>
                            <top>20</top>
                            <width>124</width>
                            <height>42</height>
                            <texture border="21">lucent/pill42.png</texture>
                            <colordiffuse>%(pd)s</colordiffuse>
                            <visible>String.IsEmpty(ListItem.Property(lucent.lowq)) + String.IsEmpty(ListItem.Property(lucent.res))</visible>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <top>20</top>
                            <width>124</width>
                            <height>42</height>
                            <texture border="21">lucent/pill42.png</texture>
                            <colordiffuse>FFD9434B</colordiffuse>
                            <visible>!String.IsEmpty(ListItem.Property(lucent.lowq))</visible>
                        </control>
                        <control type="label">
                            <left>20</left>
                            <top>20</top>
                            <width>124</width>
                            <height>42</height>
                            <font>font12</font>
                            <align>center</align>
                            <aligny>center</aligny>
                            <textcolor>%(pt)s</textcolor>
                            <label>[B]$INFO[ListItem.Property(lucent.quality)][/B]</label>
                            <visible>String.IsEmpty(ListItem.Property(lucent.lowq)) + String.IsEmpty(ListItem.Property(lucent.res))</visible>
                        </control>
                        <!-- Resolution flag (Arctic Fuse 3 colour flags) -->
                        <control type="image">
                            <left>20</left>
                            <top>14</top>
                            <width>124</width>
                            <height>46</height>
                            <aspectratio>keep</aspectratio>
                            <texture>lucent/res/$INFO[ListItem.Property(lucent.res)].png</texture>
                            <colordiffuse>%(resd)s</colordiffuse>
                            <visible>!String.IsEmpty(ListItem.Property(lucent.res))</visible>
                        </control>
                        <control type="label">
                            <left>20</left>
                            <top>20</top>
                            <width>124</width>
                            <height>42</height>
                            <font>font12</font>
                            <align>center</align>
                            <aligny>center</aligny>
                            <textcolor>FFFFFFFF</textcolor>
                            <label>[B]$INFO[ListItem.Property(lucent.quality)][/B]</label>
                            <visible>!String.IsEmpty(ListItem.Property(lucent.lowq))</visible>
                        </control>
                        <!-- Debrid / service icon (AB Wizard account manager artwork) -->
                        <control type="image">
                            <left>58</left>
                            <top>66</top>
                            <width>48</width>
                            <height>48</height>
                            <aspectratio>keep</aspectratio>
                            <texture>$INFO[ListItem.Property(lucent.icon)]</texture>
                            <colordiffuse>%(icon)s</colordiffuse>
                            <visible>!String.IsEmpty(ListItem.Property(lucent.icon))</visible>
                        </control>
                        <control type="label">
                            <left>168</left>
                            <top>12</top>
                            <width>712</width>
                            <height>40</height>
                            <font>font12</font>
                            <textcolor>%(tc)s</textcolor>%(scroll)s
                            <label>%(tl)s</label>
                        </control>
                        <control type="label">
                            <left>168</left>
                            <top>46</top>
                            <width>712</width>
                            <height>34</height>
                            <font>font12</font>
                            <textcolor>%(mc)s</textcolor>
                            <label>[UPPERCASE]$INFO[ListItem.Property(lucent.meta)][/UPPERCASE]</label>
                        </control>
                        <control type="group">
                            <left>168</left>
                            <top>84</top>
                            <width>712</width>
                            <height>34</height>%(badges)s
                        </control>
                    </control>
                    <!-- Full search -->
                    <control type="label">
                        <left>40</left>
                        <width>824</width>
                        <height>124</height>
                        <font>font12</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>%(tc)s</textcolor>
                        <label>[B][UPPERCASE]%(fl)s[/UPPERCASE][/B]</label>
                        <visible>!String.IsEmpty(ListItem.Property(%(full)s))</visible>
                    </control>
                </control>''' % {
        'zoom': zoom, 'body': body, 'full': full, 'pd': pill_diffuse, 'pt': pill_text,
        'icon': 'FFFFFFFF' if active else 'D9FFFFFF', 'resd': 'FFFFFFFF' if active else 'D9FFFFFF', 'tc': title_color, 'mc': meta_color,
        'scroll': scroll, 'tl': title_label, 'badges': badge_row(badge_diffuse), 'fl': full_label}


def stream_list(lid, visible, profile, scroll_id):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    nav = profile['list_nav']
    return '''
            <!-- Stream list %(id)s -->
            <control type="scrollbar" id="%(sid)s">
                <left>962</left>
                <top>124</top>
                <width>6</width>
                <height>800</height>
                <onleft>%(id)s</onleft>
                <showonepage>false</showonepage>
                <orientation>vertical</orientation>
                <texturesliderbackground colordiffuse="14FFFFFF" border="3">lucent/pill6.png</texturesliderbackground>
                <texturesliderbar colordiffuse="4DFFFFFF" border="3">lucent/pill6.png</texturesliderbar>
                <texturesliderbarfocus colordiffuse="FFFFFFFF" border="3">lucent/pill6.png</texturesliderbarfocus>%(vis)s
            </control>
            <control type="label">
                <right>40</right>
                <top>30</top>
                <width>300</width>
                <height>50</height>
                <font>font12</font>
                <align>right</align>
                <textcolor>FFBDC8D1</textcolor>
                <label>$INFO[Container(%(id)s).CurrentItem]$INFO[Container(%(id)s).NumItems, / ,]</label>%(vis)s
            </control>
            <control type="list" id="%(id)s">
                <left>24</left>
                <top>116</top>
                <width>936</width>
                <height>836</height>
                <orientation>vertical</orientation>
                <pagecontrol>%(sid)s</pagecontrol>
                <scrolltime tween="cubic" easing="out">250</scrolltime>
                <focusposition>1</focusposition>
                <movement>3</movement>%(nav)s
                <onright>%(right)s</onright>%(vis)s
                <itemlayout height="148" width="936">%(idle)s
                </itemlayout>
                <focusedlayout height="148" width="936" condition="!Control.HasFocus(%(id)s)">%(dim)s
                </focusedlayout>
                <focusedlayout height="148" width="936" condition="Control.HasFocus(%(id)s)">%(active)s
                </focusedlayout>
            </control>
''' % {'id': lid, 'sid': scroll_id, 'vis': vis, 'nav': nav, 'right': profile.get('onright', lid),
           'idle': card('idle', profile), 'dim': card('dim', profile), 'active': card('active', profile)}


# 4.8.51: the "Selected stream" tiles of Search All in the single-player window
# (left column, under a shorter plot). Values come from lucent_theme's
# lucent.sp_* item properties; only the list the add-on filled has items, so
# the labels simply join every list's value.
SP_PLOT_H = 130                        # plot 476 .. 606 (4 lines)
SP_TOP = 624                           # heading; tiles 680 .. 992
SP_TILE_H, SP_GAP = 96, 12


def sp_panel(list_ids, fade_cond=None):
    def val(key):
        return ''.join('$INFO[Container(%s).ListItem.Property(lucent.sp_%s)]' % (lid, key) for lid in list_ids)

    def empty(key):
        return ' + '.join('String.IsEmpty(Container(%s).ListItem.Property(lucent.sp_%s))' % (lid, key) for lid in list_ids)
    tiles = []
    for n, (key, _x) in enumerate(AB_SPEC_TILES):
        col, row = n % AB_SPEC_COLS, n // AB_SPEC_COLS
        tiles.append('''
                <control type="group">
                    <left>%(l)d</left>
                    <top>%(t)d</top>
                    <width>%(w)d</width>
                    <height>%(h)d</height>
                    <control type="image">
                        <texture border="32">lucent/card.png</texture>
                        <colordiffuse>17FFFFFF</colordiffuse>
                    </control>
                    <control type="image">
                        <texture border="32">lucent/card_edge.png</texture>
                        <colordiffuse>1FFFFFFF</colordiffuse>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>6</top>
                        <width>%(iw)d</width>
                        <height>26</height>
                        <font>abk_srch_s</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>FF8F9BA6</textcolor>
                        <label>$INFO[Window.Property(lucent.sl_%(k)s)]</label>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>32</top>
                        <width>%(iw)d</width>
                        <height>36</height>
                        <font>abk_srch_m</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]%(v)s[/B]</label>
                        <visible>!%(e)s + %(ie)s</visible>
                    </control>
                    <!-- AB Tools 4.12.27: the badge / service logo in place of the text -->
                    <control type="image">
                        <left>12</left>
                        <top>31</top>
                        <width>%(iw)d</width>
                        <height>38</height>
                        <aspectratio>keep</aspectratio>
                        <texture>%(icon)s</texture>
                        <visible>!%(ie)s</visible>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>32</top>
                        <width>%(iw)d</width>
                        <height>36</height>
                        <font>abk_srch_m</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>4DFFFFFF</textcolor>
                        <label>—</label>
                        <visible>%(e)s</visible>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>66</top>
                        <width>%(iw)d</width>
                        <height>26</height>
                        <font>abk_srch_s</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>FFBDC8D1</textcolor>
                        <label>%(sub)s</label>
                    </control>
                </control>''' % {'l': col * (AB_SPEC_W + AB_SPEC_GAP), 't': row * (SP_TILE_H + SP_GAP),
                                 'w': AB_SPEC_W, 'h': SP_TILE_H, 'iw': AB_SPEC_W - 24, 'k': key,
                                 'v': val(key), 'e': '[%s]' % empty(key), 'sub': val(key + '_sub'),
                                 'icon': val(key + '_icon'), 'ie': '[%s]' % empty(key + '_icon')})
    hide = ''
    if fade_cond:
        hide = '\n            <animation effect="fade" end="0" time="200" condition="%s">Conditional</animation>' % fade_cond
    return '''
        <!-- ============ Left: details of the focused stream (4.8.51, as in Search All) ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="200">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>%(hide)s
            <left>96</left>
            <top>%(top)d</top>
            <width>700</width>
            <control type="label">
                <width>420</width>
                <height>40</height>
                <font>abk_srch_s</font>
                <textcolor>FF8F9BA6</textcolor>
                <label>[B][UPPERCASE]$INFO[Window.Property(lucent.sl_heading)][/UPPERCASE][/B]</label>
            </control>
            <control type="label">
                <left>300</left>
                <width>400</width>
                <height>40</height>
                <font>abk_srch_s</font>
                <align>right</align>
                <textcolor>FFBDC8D1</textcolor>
                <label>[B]%(lang)s[/B]</label>
            </control>
            <control type="image">
                <top>44</top>
                <width>700</width>
                <height>1</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>1AFFFFFF</colordiffuse>
            </control>
            <control type="group">
                <top>56</top>%(tiles)s
            </control>
        </control>''' % {'hide': hide, 'top': SP_TOP, 'lang': val('lang'), 'tiles': ''.join(tiles)}


def results_window(profile):
    lists = ''.join(stream_list(lid, vis, profile, sid) for lid, vis, sid in profile['lists'])
    left_extra = profile.get('left_extra', '')
    fade_cond = profile.get('plot_fade_cond')
    return '''<?xml version="1.0" encoding="UTF-8"?>
<!-- LUCENT for %(name)s - source results. Generated by AB Tools (tools/gen_lucent.py). -->
<!-- Look and textures: Lucent theme for Seren by djdirty60 (github.com/djdirty60/Seren-Thema). -->
<window type="dialog">
    <coordinates>
        <left>0</left>
        <top>0</top>
        <width>1920</width>
        <height>1080</height>
    </coordinates>
    <defaultcontrol always="true">%(default)s</defaultcontrol>
    <controls>%(bg)s%(title)s%(plot)s%(specs)s%(left_extra)s
        <!-- ============ Right: glass stream panel ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="150">WindowOpen</animation>
            <animation effect="slide" start="120,0" end="0,0" time="400" delay="150" tween="cubic" easing="out">WindowOpen</animation>
            <animation effect="slide" end="200,0" time="300" tween="cubic" easing="in">WindowClose</animation>
            <animation effect="fade" end="0" time="300">WindowClose</animation>
            <left>880</left>
            <top>56</top>
            <width>984</width>
            <height>968</height>%(glass)s
            <control type="label">
                <left>40</left>
                <top>30</top>
                <width>600</width>
                <height>50</height>
                <font>font27</font>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]Streams[/B]</label>
            </control>
            <control type="label">
                <left>40</left>
                <top>72</top>
                <width>900</width>
                <height>26</height>
                <font>font12</font>
                <textcolor>FF8F9BA6</textcolor>
                <label>%(subhead)s</label>
            </control>
            <control type="image">
                <left>40</left>
                <top>106</top>
                <width>904</width>
                <height>1</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>1AFFFFFF</colordiffuse>
            </control>%(lists)s
        </control>%(hidden)s
    </controls>
</window>
''' % {'name': profile['name'], 'default': profile['lists'][0][0],
           'bg': backdrop('$INFO[Window.Property(lucent.fanart)]'),
           'title': title_block(),
           'plot': plot_block('$INFO[Window.Property(lucent.plot)]', height=SP_PLOT_H, fade_cond=fade_cond),
           'specs': sp_panel([lid for lid, _v, _s in profile['lists']], fade_cond=fade_cond),
           'left_extra': left_extra, 'glass': glass(0, 0, 984, 968),
           'subhead': profile['subhead'], 'lists': lists, 'hidden': profile.get('hidden', '')}


# ───────────────────────── progress windows ─────────────────────────

def progress_card(inner, height=344, visible=None):
    vis = '\n            <visible>%s</visible>' % visible if visible else ''
    return '''
        <!-- ============ Glass progress card ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="100">WindowOpen</animation>
            <animation effect="slide" start="0,60" end="0,0" time="400" delay="100" tween="cubic" easing="out">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>%(vis)s
            <left>96</left>
            <top>%(top)d</top>
            <width>840</width>
            <height>%(h)d</height>%(glass)s%(inner)s
        </control>
''' % {'vis': vis, 'top': 1080 - 96 - height, 'h': height, 'glass': glass(0, 0, 840, height), 'inner': inner}


def header(label, visible=None, right=None):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    out = '''
            <control type="label">
                <left>40</left>
                <top>28</top>
                <width>600</width>
                <height>44</height>
                <font>font27</font>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]%s[/B]</label>%s
            </control>''' % (label, vis)
    if right:
        out += '''
            <control type="label">
                <right>40</right>
                <top>28</top>
                <width>200</width>
                <height>44</height>
                <font>font27</font>
                <align>right</align>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]%s[/B]</label>%s
            </control>''' % (right, vis)
    return out


def counts_row(values, top, visible=None):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    cells = []
    for n, (label, value) in enumerate(values):
        cells.append('''
                <control type="group">
                    <left>%d</left>
                    <width>176</width>
                    <height>84</height>
                    <control type="image">
                        <width>176</width>
                        <height>84</height>
                        <texture border="32">lucent/card.png</texture>
                        <colordiffuse>14FFFFFF</colordiffuse>
                    </control>
                    <control type="label">
                        <top>8</top>
                        <width>176</width>
                        <height>40</height>
                        <font>font27</font>
                        <align>center</align>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]$INFO[%s][/B]</label>
                    </control>
                    <control type="label">
                        <top>46</top>
                        <width>176</width>
                        <height>30</height>
                        <font>font12</font>
                        <align>center</align>
                        <textcolor>FF8F9BA6</textcolor>
                        <label>%s</label>
                    </control>
                </control>''' % (n * 190, value, label))
    return '''
            <control type="group">
                <left>40</left>
                <top>%d</top>%s%s
            </control>''' % (top, vis, ''.join(cells))


def textbox(cid, top, height, label='', visible=None, color='FF8F9BA6'):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    idattr = ' id="%s"' % cid if cid else ''
    lab = '\n                <label>%s</label>' % label if label else ''
    return '''
            <control type="textbox"%s>
                <left>40</left>
                <top>%d</top>
                <width>760</width>
                <height>%d</height>
                <font>font12</font>
                <textcolor>%s</textcolor>%s%s
            </control>''' % (idattr, top, height, color, lab, vis)


def button_row(buttons, top, visible=None, gid=None):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    idattr = ' id="%s"' % gid if gid else ''
    return '''
            <control type="grouplist"%s>
                <left>40</left>
                <top>%d</top>
                <width>760</width>
                <height>64</height>
                <orientation>horizontal</orientation>
                <itemgap>16</itemgap>%s%s
            </control>''' % (idattr, top, vis, ''.join(buttons))


def window_shell(name, what, body, default=None):
    dc = '\n    <defaultcontrol always="true">%s</defaultcontrol>' % default if default else ''
    return '''<?xml version="1.0" encoding="UTF-8"?>
<!-- LUCENT for %s - %s. Generated by AB Tools (tools/gen_lucent.py). -->
<!-- Look and textures: Lucent theme for Seren by djdirty60 (github.com/djdirty60/Seren-Thema). -->
<window type="dialog">
    <coordinates>
        <left>0</left>
        <top>0</top>
        <width>1920</width>
        <height>1080</height>
    </coordinates>%s
    <controls>%s
    </controls>
</window>
''' % (name, what, dc, body)


def fen_playback(name, counts, percent_expr, resume_percent_expr, resume_buttons):
    """Fen Light / Red Light sources_playback.xml (scraper, resolver and resume modes)."""
    mode = 'String.IsEqual(Window.Property(window_mode),%s)'
    scraper, resolver, resume = mode % 'scraper', mode % 'resolver', mode % 'resume'
    busy = 'String.IsEqual(Window.Property(enable_busy_spinner),true)'
    inner = ''.join([
        header('Searching for streams', scraper, right='$INFO[%s]' % counts[-1][1]),
        header('Opening stream', resolver),
        header('Resume playback?', resume),
        spinner(busy, 620, 42),
        segmented_bar(percent_expr, top=96, left=40, visible='!' + resume if resume_percent_expr != percent_expr else None),
        counts_row(counts[:-1], 128, scraper),
        textbox('2001', 232, 84, visible=scraper),
        textbox('2002', 128, 188, visible=resolver, color='FFDCE2E7'),
        segmented_bar(resume_percent_expr, top=96, left=40, visible=resume) if resume_percent_expr != percent_expr else '',
        resume_buttons,
    ])
    body = ''.join([
        backdrop('$INFO[Window.Property(lucent.fanart)]'),
        title_block(),
        plot_block('$INFO[Window.Property(lucent.plot)]', top=476, height=130, visible='!' + resolver),
        plot_block('$INFO[Window.Property(text)]', top=476, height=130, visible=resolver),
        progress_card(inner),
    ])
    return window_shell(name, 'scraping / resolving', body)


# ───────────────────────── profiles ─────────────────────────

def fen_results_profile(name):
    fmt = 'String.IsEqual(Window.Property(window_format),%s)'
    filter_list = '''
        <!-- ============ Filters (left of the stream list) ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="150">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>
            <left>96</left>
            <top>476</top>
            <control type="group">
                <animation effect="fade" end="0" time="200" condition="!Control.HasFocus(2100)">Conditional</animation>
                <control type="label">
                    <width>700</width>
                    <height>40</height>
                    <font>font27</font>
                    <textcolor>FFFFFFFF</textcolor>
                    <label>[B]Filter[/B]</label>
                </control>
            </control>
            <control type="fixedlist" id="2100">
                <animation effect="fade" end="0" time="200" condition="!Control.HasFocus(2100)">Conditional</animation>
                <top>52</top>
                <width>700</width>
                <height>380</height>
                <onup>2100</onup>
                <ondown>2100</ondown>
                <orientation>vertical</orientation>
                <focusposition>2</focusposition>
                <movement>2</movement>
                <scrolltime tween="cubic" easing="out">200</scrolltime>
                <itemlayout height="76" width="700">
                    <control type="label">
                        <left>28</left>
                        <width>640</width>
                        <height>64</height>
                        <font>font12</font>
                        <aligny>center</aligny>
                        <textcolor>FFDCE2E7</textcolor>
                        <label>$INFO[ListItem.Property(label)]</label>
                    </control>
                </itemlayout>
                <focusedlayout height="76" width="700">
                    <control type="image">
                        <width>700</width>
                        <height>64</height>
                        <texture border="32">lucent/pill64.png</texture>
                        <colordiffuse>FFFFFFFF</colordiffuse>
                    </control>
                    <control type="label">
                        <left>28</left>
                        <width>640</width>
                        <height>64</height>
                        <font>font12</font>
                        <aligny>center</aligny>
                        <textcolor>FF%(bg)s</textcolor>
                        <label>[B]$INFO[ListItem.Property(label)][/B]</label>
                    </control>
                </focusedlayout>
            </control>
            <control type="label">
                <top>528</top>
                <width>700</width>
                <height>40</height>
                <font>font12</font>
                <textcolor>FF8F9BA6</textcolor>
                <label>▶  Press RIGHT to filter</label>
                <visible>!Control.HasFocus(2100) + !String.IsEqual(Window.Property(filter_applied),true)</visible>
            </control>
            <control type="label">
                <top>528</top>
                <width>700</width>
                <height>40</height>
                <font>font12</font>
                <textcolor>FFDCE2E7</textcolor>
                <label>Filter active  ·  press BACK to clear</label>
                <visible>!Control.HasFocus(2100) + String.IsEqual(Window.Property(filter_applied),true)</visible>
            </control>
        </control>
''' % {'bg': BG}
    return {
        'name': name,
        'lists': [('2000', fmt % 'list', '2060'), ('2001', fmt % 'rows', '2063'), ('2002', fmt % 'widelist', '2064')],
        'list_nav': '\n                <onleft>2100</onleft>',
        'full_prop': 'perform_full_search', 'full_label': 'Perform Full Search',
        'subhead': '[UPPERCASE]$INFO[Window.Property(total_results)] Results $INFO[Window.Property(filters_ignored)] $INFO[Window.Property(filter_info)][/UPPERCASE]',
        'left_extra': filter_list, 'plot_fade_cond': 'Control.HasFocus(2100)',
        # set_poster() writes the poster into image 200 - keep the control, unseen.
        'hidden': '''
        <control type="image" id="200">
            <width>1</width>
            <height>1</height>
            <visible>false</visible>
        </control>''',
    }


def pov_results_profile():
    fmt = 'String.StartsWith(Window.Property(tikiskins.window_style),%s)'
    return {
        'name': 'POV',
        'lists': [('2000', fmt % 'list', '2060'), ('2001', fmt % 'infolist', '2061'), ('2002', fmt % 'widelist', '2062')],
        'list_nav': '',
        'full_prop': 'tikiskins.perform_full_search',
        'full_label': '$INFO[ListItem.Property(tikiskins.start_full_scrape)]',
        'subhead': '[UPPERCASE]$INFO[Window.Property(tikiskins.total_results)] Results$INFO[Window.Property(tikiskins.scrape_time),  ·  ,s] $INFO[Window.Property(tikiskins.filters_ignored)][/UPPERCASE]',
        'left_extra': '''
        <control type="label">
            <left>96</left>
            <top>1004</top>
            <width>720</width>
            <height>40</height>
            <font>font12</font>
            <textcolor>FF8F9BA6</textcolor>
            <label>RIGHT to filter  ·  MENU for options  ·  INFO for details</label>
        </control>''',
    }


def umbrella_results_profile(list_id, what, buttons=True):
    extra = ''
    nav = ''
    if buttons:
        nav = '\n                <onleft>2090</onleft>'
        extra = '''
        <!-- ============ Action pills ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="150">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>
            <left>96</left>
            <top>1000</top>%s
        </control>''' % button_row([
            action_button('2051', 'Back', 'String.IsEqual(Window().Property(umbrella.sourcebackbutton),1)'),
            action_button('2001', '$ADDON[plugin.video.umbrella 32639]'),
        ], 0, gid='2090').replace('<left>40</left>', '<left>0</left>', 1).replace(
            '<itemgap>16</itemgap>', '<itemgap>16</itemgap>\n                <onright>%s</onright>\n                <onup>%s</onup>' % (list_id, list_id))
    return {
        'name': 'Umbrella (%s)' % what,
        'lists': [(list_id, None, '5060')],
        'list_nav': nav,
        'full_prop': 'lucent.never_set', 'full_label': '',
        'subhead': '[UPPERCASE]$INFO[Window().Property(umbrella.total_results)] Results$INFO[Window.Property(lucent.filter_info),  ·  Filter: ,  ·  BACK to clear][/UPPERCASE]',
        # 4.8.51: the stream tiles take the space; the action pills sit under
        # them, the hint only where there are no pills
        'left_extra': extra + ('' if buttons else '''
        <control type="label">
            <left>96</left>
            <top>1004</top>
            <width>720</width>
            <height>40</height>
            <font>font12</font>
            <textcolor>FF8F9BA6</textcolor>
            <label>RIGHT to filter  ·  MENU for options  ·  INFO for details</label>
        </control>'''),
    }


LC = 'Window.Property(lucent.%s)'
COUNTS_ON = 'String.IsEqual(Window.Property(lucent.counts),true)'
PARSED_TILES = [('4K', LC % 'c_4k'), ('1080P', LC % 'c_1080p'), ('720P', LC % 'c_720p'), ('SD', LC % 'c_sd')]
SHIFT = '\n                <animation effect="slide" end="0,104" time="0" condition="%s">Conditional</animation>' % COUNTS_ON


def shifted_textbox(cid, top, height, color='FFDCE2E7'):
    return textbox(cid, top, height, color=color).replace('<font>font12</font>', '<font>font12</font>' + SHIFT, 1)


def flplus_info(top=110, alt=None):
    """4.8.4: Fen Light+ style title block - clearlogo (or title), "year |
    running time | ends at", "certificate | genres | rating", plot.
    lucent.line1 / lucent.line2 come from lucent_theme.lucent_window().
    alt=(label, condition): show that text in the plot slot while condition holds."""
    pvis = alt_box = ''
    if alt:
        pvis = '\n                <visible>!%s</visible>' % alt[1]
        alt_box = '''
            <control type="textbox">
                <top>318</top>
                <width>1060</width>
                <height>150</height>
                <font>font12</font>
                <textcolor>FFE6E9ED</textcolor>
                <label>%s</label>
                <visible>%s</visible>
            </control>''' % alt
    return '''
        <!-- ============ Fen Light+ style info ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350">WindowOpen</animation>
            <animation effect="fade" end="0" time="200">WindowClose</animation>
            <left>90</left>
            <top>%(top)d</top>
            <control type="image">
                <width>760</width>
                <height>190</height>
                <aspectratio align="left" aligny="bottom">keep</aspectratio>
                <texture background="true">$INFO[Window.Property(lucent.clearlogo)]</texture>
                <visible>!String.IsEmpty(Window.Property(lucent.clearlogo))</visible>
            </control>
            <control type="textbox">
                <width>1100</width>
                <height>190</height>
                <font>font37</font>
                <aligny>bottom</aligny>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[Window.Property(lucent.show_title)][/B]</label>
                <visible>String.IsEmpty(Window.Property(lucent.clearlogo))</visible>
            </control>
            <control type="label">
                <top>202</top>
                <width>1500</width>
                <height>48</height>
                <font>font27</font>
                <textcolor>FFFFFFFF</textcolor>
                <label>$INFO[Window.Property(lucent.line1)]</label>
            </control>
            <control type="label">
                <top>256</top>
                <width>1500</width>
                <height>40</height>
                <font>font12</font>
                <textcolor>FFC4CBD3</textcolor>
                <label>$INFO[Window.Property(lucent.line2)]</label>
            </control>
            <control type="textbox">
                <top>318</top>
                <width>1060</width>
                <height>150</height>
                <font>font12</font>
                <textcolor>FFE6E9ED</textcolor>
                <label>$INFO[Window.Property(lucent.plot)]</label>
                <autoscroll delay="6000" time="2500" repeat="8000">true</autoscroll>%(pvis)s
            </control>%(alt)s
        </control>''' % {'top': top, 'pvis': pvis, 'alt': alt_box}


def umbrella_progress():
    """4.8.4: Fen Light+ style - backdrop + info top left, the stream being
    opened, the status with its percentage and a full-width bar at the bottom."""
    shown = '!String.IsEqual(Window.Property(umbrella.icononly),true) + !String.IsEqual(Window.Property(umbrella.isHidden),true)'
    icon_only = 'String.IsEqual(Window.Property(umbrella.icononly),true) + !String.IsEqual(Window.Property(umbrella.isHidden),true)'
    status = '''
        <!-- ============ status (bottom) ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="100">WindowOpen</animation>
            <animation effect="fade" end="0" time="200">WindowClose</animation>
            <left>90</left>
            <top>780</top>
            <width>1740</width>
            <height>270</height>%(counts)s
            <control type="textbox" id="2001">
                <top>96</top>
                <width>1740</width>
                <height>96</height>
                <font>font12</font>
                <textcolor>FFDCE2E7</textcolor>
            </control>
            <control type="label">
                <top>200</top>
                <width>1300</width>
                <height>44</height>
                <font>font27</font>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[Window.Property(lucent.heading)][/B]</label>
            </control>
            <control type="label">
                <right>0</right>
                <top>200</top>
                <width>300</width>
                <height>44</height>
                <font>font27</font>
                <align>right</align>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[Window().Property(percent)]%%[/B]</label>
            </control>%(bar)s
        </control>''' % {
        'counts': counts_row(PARSED_TILES, 0, COUNTS_ON).replace('\n', '\n    '),
        'bar': segmented_bar('Window().Property(percent)', width=1740, segments=58, top=262, left=0)}
    body = '''
        <control type="group">
            <visible>%(shown)s</visible>%(bg)s%(info)s%(status)s
        </control>
        <!-- Icon-only mode: small glass pill top right -->
        <control type="group">
            <visible>%(icon)s</visible>
            <right>48</right>
            <top>36</top>
            <width>220</width>
            <height>56</height>
            <control type="image">
                <texture border="28">lucent/pill60.png</texture>
                <colordiffuse>E0162532</colordiffuse>
            </control>%(spin)s
            <control type="label">
                <left>56</left>
                <width>150</width>
                <height>56</height>
                <font>font12</font>
                <aligny>center</aligny>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[Window().Property(percent)]%%[/B]</label>
            </control>
        </control>''' % {
        'shown': shown, 'icon': icon_only,
        'bg': backdrop('$INFO[Window.Property(umbrella.fanart)]').replace('\n', '\n    '),
        'info': flplus_info().replace('\n', '\n    '),
        'status': status.replace('\n', '\n    '),
        'spin': spinner('true', 24, 20)}
    return window_shell('Umbrella', 'progress', body)


def flplus_status(inner, delay=100):
    """4.8.5: the bottom status group shared by the Fen Light+ style progress
    screens (Umbrella layout): row 0 tiles, 96 text, 200 heading + percent, 262 bar."""
    return """
        <!-- ============ status (bottom) ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="%d">WindowOpen</animation>
            <animation effect="fade" end="0" time="200">WindowClose</animation>
            <left>90</left>
            <top>780</top>
            <width>1740</width>
            <height>270</height>%s
        </control>""" % (delay, inner.replace('\n', '\n    '))


def status_label(label, visible=None, right=False, top=200):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    if right:
        pos, width, align = '\n                <right>0</right>', 300, '\n                <align>right</align>'
    else:
        pos, width, align = '', 1300, ''
    return """
            <control type="label">%s
                <top>%d</top>
                <width>%d</width>
                <height>44</height>
                <font>font27</font>%s
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]%s[/B]</label>%s
            </control>""" % (pos, top, width, align, label, vis)


def status_textbox(cid, visible=None, top=96, color='FFDCE2E7'):
    vis = '\n                <visible>%s</visible>' % visible if visible else ''
    idattr = ' id="%s"' % cid if cid else ''
    return """
            <control type="textbox"%s>
                <top>%d</top>
                <width>1740</width>
                <height>96</height>
                <font>font12</font>
                <textcolor>%s</textcolor>%s
            </control>""" % (idattr, top, color, vis)


# ───────── 4.10.6: source grid while searching (Fen Light+ style) ─────────
# Fed by the add-on's scrape loop through lucent_theme (lucent_chip_feed /
# lucent_chips_draw): panel 7700, 7 chips a row, up to 4 rows growing up from
# the heading; the tiles and the running time move up with it. Without a
# feed (lucent.chips empty) the screen is the 4.8.5 one, text line included.
CHIPS_ON = 'String.IsEqual(Window.Property(lucent.chips),true)'
CHIP_COLS, CHIP_ROWS, CHIP_PITCH, CHIP_H = 7, 4, 52, 44
CHIP_CELL = 1740 // CHIP_COLS                  # 248
CHIP_W = CHIP_CELL - 12                        # 236
CHIP_TOP = 196 - CHIP_PITCH                    # one row: 144 .. 188 (heading at 200)
CHIP_CNT = 56


def _chip_rows_anim(shift):
    """Slide up by shift(rows) for 2 .. 4 rows."""
    return ''.join('''
                <animation effect="slide" end="0,-%d" time="0" condition="String.IsEqual(Window.Property(lucent.chip_rows),%d)">Conditional</animation>''' % (shift(r), r)
        for r in range(2, CHIP_ROWS + 1) if shift(r) > 0)


def _tiles_lift(r):
    return max(0, 84 + 12 - (CHIP_TOP - (r - 1) * CHIP_PITCH))


def chip_lift(xml):
    """Tiles row / time label: move up when the grid has more rows."""
    return xml.replace('<control type="group">', '<control type="group">' + _chip_rows_anim(_tiles_lift), 1)


def lucent_chip_item():
    st = 'String.IsEqual(ListItem.Property(lucent.state),%s)'
    dot = '''
                        <control type="image">
                            <left>16</left>
                            <top>%(t)d</top>
                            <width>12</width>
                            <height>12</height>
                            <texture>lucent/dot.png</texture>
                            <colordiffuse>%(c)s</colordiffuse>%(anim)s
                            <visible>%(v)s</visible>
                        </control>'''
    pulse = '''
                            <animation effect="fade" start="100" end="20" time="500" pulse="true" condition="true">Conditional</animation>'''
    dots = ''.join(dot % {'t': (CHIP_H - 12) // 2, 'c': c, 'anim': a, 'v': st % s_}
                   for s_, c, a in (('done', 'FFFFFFFF', ''), ('scanning', '8CFFFFFF', pulse), ('failed', 'FFE5484D', '')))
    count = '''
                        <control type="label">
                            <left>%(l)d</left>
                            <width>%(w)d</width>
                            <height>%(h)d</height>
                            <font>font12</font>
                            <align>right</align>
                            <aligny>center</aligny>
                            <textcolor>%(c)s</textcolor>
                            <label>[B]$INFO[ListItem.Label2][/B]</label>
                            <visible>%(v)s</visible>
                        </control>'''
    return '''
                        <control type="image">
                            <width>%(w)d</width>
                            <height>%(h)d</height>
                            <texture border="22">lucent/pill44.png</texture>
                            <colordiffuse>1AFFFFFF</colordiffuse>
                        </control>%(dots)s
                        <control type="label">
                            <left>36</left>
                            <width>%(nw)d</width>
                            <height>%(h)d</height>
                            <font>font12</font>
                            <aligny>center</aligny>
                            <textcolor>FFFFFFFF</textcolor>
                            <label>[B]$INFO[ListItem.Label][/B]</label>
                        </control>%(cnt)s%(bad)s''' % {
        'w': CHIP_W, 'h': CHIP_H, 'dots': dots, 'nw': CHIP_W - 36 - CHIP_CNT - 14,
        'cnt': count % {'l': CHIP_W - CHIP_CNT - 14, 'w': CHIP_CNT, 'h': CHIP_H, 'c': 'FFBDC8D1', 'v': '!' + st % 'failed'},
        'bad': count % {'l': CHIP_W - CHIP_CNT - 14, 'w': CHIP_CNT, 'h': CHIP_H, 'c': 'FFE5484D', 'v': st % 'failed'}}


def chip_grid(visible=None):
    vis = CHIPS_ON + (' + ' + visible if visible else '')
    item = lucent_chip_item()
    return '''
            <!-- 4.10.6: source grid (Fen Light+ style) -->
            <control type="group">
                <visible>%(vis)s</visible>
                <control type="group">%(tlift)s
                    <control type="label">
                        <right>0</right>
                        <top>6</top>
                        <width>500</width>
                        <height>44</height>
                        <font>font27</font>
                        <align>right</align>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]$INFO[Window.Property(lucent.chip_time)][/B]</label>
                    </control>
                    <control type="label">
                        <right>0</right>
                        <top>50</top>
                        <width>500</width>
                        <height>30</height>
                        <font>font12</font>
                        <align>right</align>
                        <textcolor>FFBDC8D1</textcolor>
                        <label>$INFO[Window.Property(lucent.chip_sub)]</label>
                    </control>
                </control>
                <control type="panel" id="7700">
                    <top>%(top)d</top>
                    <width>1740</width>
                    <height>%(gh)d</height>
                    <orientation>vertical</orientation>
                    <scrolltime>0</scrolltime>%(glift)s
                    <itemlayout width="%(cw)d" height="%(ch)d">%(item)s
                    </itemlayout>
                    <focusedlayout width="%(cw)d" height="%(ch)d">%(item)s
                    </focusedlayout>
                </control>
            </control>''' % {'vis': vis, 'top': CHIP_TOP, 'gh': CHIP_ROWS * CHIP_PITCH, 'cw': CHIP_CELL,
                             'ch': CHIP_PITCH, 'item': item,
                             'tlift': _chip_rows_anim(_tiles_lift).replace('\n                <', '\n                    <'),
                             'glift': _chip_rows_anim(lambda r: (r - 1) * CHIP_PITCH).replace('\n                <', '\n                    <')}


def _row_at_zero(row):
    return row.replace('<left>40</left>', '<left>0</left>', 1)


def redlight_playback(counts, percent_prop, resume_percent_prop):
    """4.8.5: Red Light sources_playback.xml in the Fen Light+ style (as
    Umbrella's progress screen): info top left, status + full-width bar
    at the bottom. Keeps the scraper / resolver / resume modes, textboxes
    2001 / 2002 and the resume buttons 3010-3012 (grouplist 3001)."""
    mode = 'String.IsEqual(Window.Property(window_mode),%s)'
    scraper, resolver, resume = mode % 'scraper', mode % 'resolver', mode % 'resume'
    busy = 'String.IsEqual(Window.Property(enable_busy_spinner),true)'
    inner = ''.join([
        chip_lift(counts_row(counts, 0, scraper)),
        status_textbox('2001', scraper + ' + !' + CHIPS_ON),
        chip_grid(scraper),
        status_textbox('2002', resolver),
        _row_at_zero(resume_buttons_redlight()).replace('<top>160</top>', '<top>96</top>', 1),
        spinner(busy, -30, 214),
        status_label('Searching for streams', scraper),
        status_label('Opening stream', resolver),
        status_label('Resume playback?', resume),
        status_label('$INFO[%s]%%' % percent_prop, '!' + resume, right=True),
        status_label('$INFO[%s]%%' % resume_percent_prop, resume, right=True),
        segmented_bar(percent_prop, width=1740, segments=58, top=262, left=0, visible='!' + resume),
        segmented_bar(resume_percent_prop, width=1740, segments=58, top=262, left=0, visible=resume),
    ])
    body = ''.join([
        backdrop('$INFO[Window.Property(lucent.fanart)]'),
        flplus_info(alt=('$INFO[Window.Property(text)]', resolver)),
        flplus_status(inner),
    ])
    return window_shell('Red Light', 'scraping / resolving', body)


def pov_progress():
    """4.8.5: POV progress_media.xml in the Fen Light+ style (as Umbrella's
    progress screen). Keeps textbox 2000, progress 5000 (now full width at
    the bottom) and the true/false buttons 10 / 11."""
    p = 'Window.Property(tikiskins.source_progress.%s)'
    buttons_on = 'String.IsEqual(%s,true)' % (p % 'buttons')
    has_heading = '!String.IsEmpty(%s)' % (LC % 'heading')
    inner = ''.join([
        chip_lift(counts_row(PARSED_TILES + [('TOTAL', LC % 'c_total')], 0, COUNTS_ON)),
        status_textbox('2000', '!' + CHIPS_ON),
        chip_grid(),
        _row_at_zero(button_row([
            action_button('10', '$INFO[%s]' % (p % 'true_button'), nav='\n                    <onright>11</onright>\n                    <onleft>11</onleft>'),
            action_button('11', '$INFO[%s]' % (p % 'false_button'), nav='\n                    <onright>10</onright>\n                    <onleft>10</onleft>'),
        ], -84, visible=buttons_on)),
        status_label('$INFO[%s]' % (LC % 'heading'), has_heading),
        status_label('$INFO[%s]%%' % (LC % 'percent'), has_heading, right=True),
        native_progress('5000', 262, left=0, width=1740),
    ])
    body = ''.join([
        backdrop('$INFO[%s]' % (p % 'fanart')),
        flplus_info(),
        flplus_status(inner),
    ])
    return window_shell('POV', 'progress', body)


def pov_contextmenu():
    """POV options dialog (long-press / MENU on a stream; also POV's image viewer).
    Contract: list 2020, ListItem.Property(tikiskins.context.label)."""
    label = '$INFO[ListItem.Property(tikiskins.context.label)]'
    body = '''
        <control type="image">
            <texture>lucent/white.png</texture>
            <colordiffuse>B3000000</colordiffuse>
            <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>
            <animation effect="fade" end="0" time="150">WindowClose</animation>
        </control>
        <control type="group">
            <animation effect="fade" start="0" end="100" time="220">WindowOpen</animation>
            <animation effect="zoom" start="94" end="100" center="auto" time="220" tween="cubic" easing="out">WindowOpen</animation>
            <animation effect="fade" end="0" time="150">WindowClose</animation>
            <centerleft>50%%</centerleft>
            <centertop>50%%</centertop>
            <width>640</width>
            <height max="760">auto</height>
            <control type="image">
                <texture border="48">lucent/panel.png</texture>
                <colordiffuse>F2162532</colordiffuse>
            </control>
            <control type="image">
                <texture border="48">lucent/panel_edge.png</texture>
                <colordiffuse>2EFFFFFF</colordiffuse>
            </control>
            <control type="image">
                <left>32</left>
                <top>28</top>
                <width>48</width>
                <height>48</height>
                <aspectratio>keep</aspectratio>
                <texture>$INFO[Window.Property(tikiskins.pov.icon)]</texture>
            </control>
            <control type="label">
                <left>96</left>
                <top>28</top>
                <width>500</width>
                <height>48</height>
                <font>font27</font>
                <aligny>center</aligny>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]Options[/B]</label>
            </control>
            <control type="image">
                <left>32</left>
                <top>100</top>
                <width>576</width>
                <height>1</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>1AFFFFFF</colordiffuse>
            </control>
            <control type="list" id="2020">
                <left>24</left>
                <top>116</top>
                <width>592</width>
                <height max="616">auto</height>
                <onup>2020</onup>
                <ondown>2020</ondown>
                <orientation>vertical</orientation>
                <scrolltime tween="cubic" easing="out">200</scrolltime>
                <itemlayout height="77" width="592">
                    <control type="label">
                        <left>32</left>
                        <width>528</width>
                        <height>64</height>
                        <font>font12</font>
                        <aligny>center</aligny>
                        <textcolor>FFDCE2E7</textcolor>
                        <label>%(label)s</label>
                    </control>
                </itemlayout>
                <focusedlayout height="77" width="592">
                    <control type="image">
                        <width>592</width>
                        <height>64</height>
                        <texture border="32">lucent/pill64.png</texture>
                        <colordiffuse>FFFFFFFF</colordiffuse>
                        <animation effect="zoom" start="97" end="100" center="auto" time="160" tween="cubic" easing="out">Focus</animation>
                    </control>
                    <control type="label">
                        <left>32</left>
                        <width>528</width>
                        <height>64</height>
                        <font>font12</font>
                        <aligny>center</aligny>
                        <textcolor>FF%(bg)s</textcolor>
                        <label>[B]%(label)s[/B]</label>
                    </control>
                </focusedlayout>
            </control>
        </control>''' % {'label': label, 'bg': BG}
    return window_shell('POV', 'options menu', body)


def resume_buttons_fen():
    resume = 'String.IsEqual(Window.Property(window_mode),resume)'
    return button_row([
        action_button('10', 'Resume $INFO[Window.Property(resume_percent)]%', nav='\n                    <onleft>12</onleft>\n                    <onright>11</onright>'),
        action_button('11', 'Start Over', nav='\n                    <onleft>10</onleft>\n                    <onright>12</onright>'),
        action_button('12', 'Cancel', nav='\n                    <onleft>11</onleft>\n                    <onright>10</onright>'),
    ], 160, visible=resume)


def resume_buttons_redlight():
    vis = 'String.IsEqual(Window.Property(window_mode),resume) + String.IsEqual(Window.Property(resume_ready),true)'
    return button_row([
        action_button('3010', '$INFO[Window.Property(resume_btn_label)]', nav='\n                    <onleft>3012</onleft>\n                    <onright>3011</onright>'),
        action_button('3011', '$INFO[Window.Property(startover_btn_label)]', nav='\n                    <onleft>3010</onleft>\n                    <onright>3012</onright>'),
        action_button('3012', '$INFO[Window.Property(cancel_btn_label)]', nav='\n                    <onleft>3011</onleft>\n                    <onright>3010</onright>'),
    ], 160, visible=vis, gid='3001')



SEL_W, SEL_ROW, SEL_HEAD, SEL_PAD, SEL_MAX = 900, 76, 148, 24, 8


def _sel_h(n):
    return SEL_HEAD + SEL_ROW * n + SEL_PAD


def lucent_select():
    """Themed select / multi-select used by the helper's filter menus
    (Fen Light / Red Light RIGHT, Umbrella filter). Contract (lucent_theme.py):
    list 5000; Window props lucent.heading, lucent.subtitle, lucent.multi,
    lucent.rows (1..8); ListItem label / label2 (count), props lucent.checked,
    lucent.kind=apply (first row of a multi-select)."""
    L = SEL_W
    left = (1920 - L) // 2
    top8 = (1080 - _sel_h(SEL_MAX)) // 2
    rows = 'Window.Property(lucent.rows)'
    multi = 'String.IsEqual(Window.Property(lucent.multi),true)'
    panels, shifts = [], []
    for n in range(1, SEL_MAX + 1):
        h = _sel_h(n)
        t = (1080 - h) // 2
        cond = 'String.IsEqual(%s,%d)' % (rows, n)
        panels.append("""
            <control type="group">
                <top>%(t)d</top>
                <visible>%(c)s</visible>
                <control type="image">
                    <left>-40</left>
                    <top>-40</top>
                    <width>%(sw)d</width>
                    <height>%(sh)d</height>
                    <texture border="88">lucent/panel_shadow.png</texture>
                    <colordiffuse>B3000000</colordiffuse>
                </control>
                <control type="image">
                    <width>%(w)d</width>
                    <height>%(h)d</height>
                    <texture border="48">lucent/panel.png</texture>
                    <colordiffuse>F5162532</colordiffuse>
                </control>
                <control type="image">
                    <width>%(w)d</width>
                    <height>%(h)d</height>
                    <texture border="48">lucent/panel_edge.png</texture>
                    <colordiffuse>2EFFFFFF</colordiffuse>
                </control>
            </control>""" % {'t': t, 'c': cond, 'w': L, 'h': h, 'sw': L + 80, 'sh': h + 80})
        if n < SEL_MAX:
            shifts.append('\n            <animation effect="slide" end="0,%d" time="0" condition="%s">Conditional</animation>'
                          % (t - top8, cond))

    def row(focused):
        pill = ''
        if focused:
            pill = """
                        <control type="image">
                            <width>%d</width>
                            <height>64</height>
                            <texture border="32">lucent/pill64.png</texture>
                            <colordiffuse>FFFFFFFF</colordiffuse>
                        </control>""" % (L - 40)
        txt = 'FF%s' % BG if focused else 'FFDCE2E7'
        cnt_bg = '1F%s' % BG if focused else '1AFFFFFF'
        cnt_txt = 'FF%s' % BG if focused else 'FFBDC8D1'
        circle_off = '66%s' % BG if focused else '40FFFFFF'
        circle_on = 'FF%s' % BG if focused else 'FFFFFFFF'
        dot_on = 'FFFFFFFF' if focused else 'FF%s' % BG
        bold = '[B]%s[/B]' if focused else '%s'
        not_apply = 'String.IsEmpty(ListItem.Property(lucent.kind))'
        return """
                    <control type="group">%(pill)s
                        <!-- multi-select check circle -->
                        <control type="group">
                            <visible>%(multi)s + %(na)s</visible>
                            <control type="image">
                                <left>28</left>
                                <top>15</top>
                                <width>34</width>
                                <height>34</height>
                                <texture border="17">lucent/pill42.png</texture>
                                <colordiffuse>%(coff)s</colordiffuse>
                                <visible>String.IsEmpty(ListItem.Property(lucent.checked))</visible>
                            </control>
                            <control type="image">
                                <left>28</left>
                                <top>15</top>
                                <width>34</width>
                                <height>34</height>
                                <texture border="17">lucent/pill42.png</texture>
                                <colordiffuse>%(con)s</colordiffuse>
                                <visible>!String.IsEmpty(ListItem.Property(lucent.checked))</visible>
                            </control>
                            <control type="image">
                                <left>38</left>
                                <top>25</top>
                                <width>14</width>
                                <height>14</height>
                                <texture>lucent/dot.png</texture>
                                <colordiffuse>%(don)s</colordiffuse>
                                <visible>!String.IsEmpty(ListItem.Property(lucent.checked))</visible>
                            </control>
                        </control>
                        <!-- label: plain list -->
                        <control type="label">
                            <left>36</left>
                            <width>%(lw)d</width>
                            <height>64</height>
                            <font>font12</font>
                            <aligny>center</aligny>
                            <textcolor>%(txt)s</textcolor>
                            <label>%(lab)s</label>
                            <visible>!%(multi)s + !%(icons)s</visible>
                        </control>
                        <!-- icon rows (totals screen): resolution badge + service icon + label -->
                        <control type="group">
                            <visible>!%(multi)s + %(icons)s</visible>
                            <control type="image">
                                <left>24</left>
                                <top>9</top>
                                <width>110</width>
                                <height>46</height>
                                <aspectratio>keep</aspectratio>
                                <texture>$INFO[ListItem.Art(icon)]</texture>
                                <visible>!String.IsEmpty(ListItem.Art(icon))</visible>
                            </control>
                            <control type="image">
                                <left>146</left>
                                <top>10</top>
                                <width>44</width>
                                <height>44</height>
                                <aspectratio>keep</aspectratio>
                                <texture>$INFO[ListItem.Art(thumb)]</texture>
                                <visible>!String.IsEmpty(ListItem.Art(thumb))</visible>
                            </control>
                            <control type="label">
                                <left>206</left>
                                <width>%(lw3)d</width>
                                <height>64</height>
                                <font>font12</font>
                                <aligny>center</aligny>
                                <textcolor>%(txt)s</textcolor>
                                <label>%(lab)s</label>
                            </control>
                        </control>
                        <!-- label: multi-select rows -->
                        <control type="label">
                            <left>84</left>
                            <width>%(lw2)d</width>
                            <height>64</height>
                            <font>font12</font>
                            <aligny>center</aligny>
                            <textcolor>%(txt)s</textcolor>
                            <label>%(lab)s</label>
                            <visible>%(multi)s + %(na)s</visible>
                        </control>
                        <!-- label: Apply row -->
                        <control type="label">
                            <left>36</left>
                            <width>%(lw)d</width>
                            <height>64</height>
                            <font>font12</font>
                            <aligny>center</aligny>
                            <textcolor>%(apc)s</textcolor>
                            <label>[B]✓  $INFO[ListItem.Label][/B]</label>
                            <visible>!%(na)s</visible>
                        </control>
                        <!-- count pill -->
                        <control type="group">
                            <left>%(cl)d</left>
                            <top>11</top>
                            <visible>!String.IsEmpty(ListItem.Label2)</visible>
                            <control type="image">
                                <width>150</width>
                                <height>42</height>
                                <texture border="21">lucent/pill42.png</texture>
                                <colordiffuse>%(cbg)s</colordiffuse>
                            </control>
                            <control type="label">
                                <width>150</width>
                                <height>42</height>
                                <font>font12</font>
                                <align>center</align>
                                <aligny>center</aligny>
                                <textcolor>%(ctx)s</textcolor>
                                <label>[B]$INFO[ListItem.Label2][/B]</label>
                            </control>
                        </control>
                    </control>""" % {
            'pill': pill, 'multi': multi, 'na': not_apply, 'coff': circle_off, 'con': circle_on, 'don': dot_on,
            'lw': L - 40 - 36 - 190, 'lw2': L - 40 - 84 - 190, 'lw3': L - 40 - 206 - 190, 'txt': txt,
            'icons': 'String.IsEqual(Window.Property(lucent.icons),true)',
            'lab': bold % '$INFO[ListItem.Label]', 'apc': txt if focused else 'FFD6F0FF',
            'cl': L - 40 - 150 - 22, 'cbg': cnt_bg, 'ctx': cnt_txt}

    body = """
        <control type="image">
            <texture>lucent/white.png</texture>
            <colordiffuse>C0000000</colordiffuse>
            <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>
            <animation effect="fade" end="0" time="150">WindowClose</animation>
        </control>
        <control type="group">
            <animation effect="fade" start="0" end="100" time="220">WindowOpen</animation>
            <animation effect="zoom" start="95" end="100" center="960,540" time="240" tween="cubic" easing="out">WindowOpen</animation>
            <animation effect="fade" end="0" time="150">WindowClose</animation>
            <left>%(left)d</left>
            <width>%(w)d</width>%(panels)s
            <control type="group">
                <top>%(top8)d</top>%(shifts)s
                <control type="label">
                    <left>40</left>
                    <top>32</top>
                    <width>%(tw)d</width>
                    <height>48</height>
                    <font>font27</font>
                    <textcolor>FFFFFFFF</textcolor>
                    <label>[B]$INFO[Window.Property(lucent.heading)][/B]</label>
                </control>
                <control type="label">
                    <left>40</left>
                    <top>80</top>
                    <width>%(tw)d</width>
                    <height>30</height>
                    <font>font12</font>
                    <textcolor>FF8F9BA6</textcolor>
                    <label>[UPPERCASE]$INFO[Window.Property(lucent.subtitle)][/UPPERCASE]</label>
                </control>
                <control type="label">
                    <right>40</right>
                    <top>36</top>
                    <width>200</width>
                    <height>40</height>
                    <font>font12</font>
                    <align>right</align>
                    <textcolor>FFBDC8D1</textcolor>
                    <label>$INFO[Container(5000).CurrentItem]$INFO[Container(5000).NumItems, / ,]</label>
                </control>
                <control type="image">
                    <left>40</left>
                    <top>124</top>
                    <width>%(tw)d</width>
                    <height>1</height>
                    <texture>lucent/white.png</texture>
                    <colordiffuse>1AFFFFFF</colordiffuse>
                </control>
                <control type="list" id="5000">
                    <left>20</left>
                    <top>%(lt)d</top>
                    <width>%(lw)d</width>
                    <height>%(lh)d</height>
                    <onup>5000</onup>
                    <ondown>5000</ondown>
                    <onleft>5000</onleft>
                    <onright>5000</onright>
                    <orientation>vertical</orientation>
                    <scrolltime tween="cubic" easing="out">200</scrolltime>
                    <itemlayout height="%(rh)d" width="%(lw)d">%(idle)s
                    </itemlayout>
                    <focusedlayout height="%(rh)d" width="%(lw)d">
                        <control type="group">
                            <animation effect="zoom" start="98" end="100" center="auto" time="160" tween="cubic" easing="out">Focus</animation>%(foc)s
                        </control>
                    </focusedlayout>
                </control>
            </control>
        </control>""" % {
        'left': left, 'w': L, 'panels': ''.join(panels), 'top8': top8, 'shifts': ''.join(shifts),
        'tw': L - 80, 'lt': SEL_HEAD - 8, 'lw': L - 40, 'lh': SEL_ROW * SEL_MAX, 'rh': SEL_ROW,
        'idle': row(False), 'foc': row(True)}
    return window_shell('Fen Light / Red Light / Umbrella', 'filter menu', body, default='5000')


# ───────────────────────── AB Tools "Search All" window ─────────────────────────
# Lives in AB Tools' own skin folder; textures are read straight from
# resources/lucent/media (absolute special:// paths, no second copy).

AB_MEDIA = 'special://home/addons/plugin.program.abukarimtools/resources/lucent/media/'
# (key, colour) in ab_search.ADDONS order: the key picks the dot / tag colour
AB_ADDONS = (('rl', 'FFE5484D'), ('fl', 'FF3E9BFF'), ('umb', 'FF9B6BFF'), ('pov', 'FF2BC48A'),
             ('aio', 'FFF5A524'),      # 4.6.32 AIOStreams (orange)
             ('dex', 'FFEC4899'),      # 4.7.13 Dex Hub (pink)
             ('en', 'FF22D3EE'),       # 4.7.16 EasyNews (cyan)
             ('nn', 'FFFACC15'),       # 4.11.0 Usenet (yellow)
             ('loc', 'FFA3E635'))      # 4.10.0 My folders (lime)
# 4.10.6: the add-on lines became a source grid (Fen Light+ style): 3 x 7
# chips under the plot - the add-ons first, then every scraper / site.
# AB_SRC_* must match ab_search.SRC_GRID / _SRC_SLOTS.
AB_SRC_ID = 2500
# 4.12.25: one add-on per line (was 3 x 7 chips): 9 lines of 42 end at
# 566 + 56 + 378 = 1000; the panel scrolls if there are ever more
AB_SRC_COLS, AB_SRC_ROWS = 1, 9
AB_SRC_PITCH = 42
AB_SRC_PANEL_W = 700                  # 4.12.28: full column again - icon + name, count at the right edge
AB_SRC_W = AB_SRC_PANEL_W // AB_SRC_COLS - 12    # 338
AB_SRC_H = 36
AB_SRC_CNT = 80                       # count column (4.12.28: 80, 4-digit counts)
# 4.7.40: left column all the way up (logo / title from y 48, was 96 + a
# 220 px logo box), the plot right under the pills and the add-on list under
# the plot (was y 736).
AB_TOP = 48
AB_LOGO_H = 150                       # logo box / title line (title bottom-aligned in it)
AB_PLOT_TOP = AB_TOP + AB_LOGO_H + 18 + 44 + 22        # 282: under the pills
# 4.8.6: the plot in abk_srch_m (26 px, was 22) and down to the add-on list
AB_PLOT_H = 266                       # movies: ~8 lines, ends 16 px above the list heading (was 232)
AB_PLOT_H_EP = 140                    # episodes: 4 lines, then the episode name (was 130)
AB_EP_TOP = AB_PLOT_TOP + AB_PLOT_H_EP + 18            # 440
AB_LIST_TOP = 566                     # heading; 7 lines of 54 end at 566 + 56 + 378 = 1000
# 4.8.25: when the search is done the add-on list gives way to the details
# of the focused stream - 3 x 3 tiles in the same place (y 566 .. ~986).
AB_SPEC_TILES = (('res', 'res'), ('size', 'size'), ('rate', 'rate'),
                 ('video', 'video'), ('hdr', 'hdr'), ('audio', 'audio'),
                 ('ch', 'ch'), ('rel', 'rel'), ('svc', 'svc'))
AB_SPEC_COLS, AB_SPEC_GAP = 3, 14
AB_SPEC_W = (700 - (AB_SPEC_COLS - 1) * AB_SPEC_GAP) // AB_SPEC_COLS     # 224
AB_SPEC_H = 112
AB_TAGS = 4
AB_TAG_W = 64
# 4.12.23: add-on icons in place of the names (lucent/addons/<key>.png);
# Usenet and My folders have no icon and keep their text
AB_ICON_KEYS = ('rl', 'fl', 'umb', 'pov', 'aio', 'dex', 'en', 'nn', 'loc')   # 4.12.26: + Usenet, My folders
_AB_HAS_ICON = ' | '.join('String.IsEqual(ListItem.Property(%%s),%s)' % k for k in AB_ICON_KEYS)


def _ab_has_icon(prop):
    return '[%s]' % (_AB_HAS_ICON % ((prop,) * len(AB_ICON_KEYS)))


def _ab_icons(prop, left, top, size, diffuse='FFFFFFFF', pulse=''):
    """One image per add-on key, shown when ListItem.Property(prop) is that key."""
    anim = ('\n                        <animation effect="fade" start="100" end="25" time="500" pulse="true" '
            'condition="%s">Conditional</animation>' % pulse) if pulse else ''
    return ''.join('''
                        <control type="image">
                            <left>%d</left>
                            <top>%d</top>
                            <width>%d</width>
                            <height>%d</height>
                            <aspectratio>keep</aspectratio>
                            <texture>lucent/addons/%s.png</texture>
                            <colordiffuse>%s</colordiffuse>%s
                            <visible>String.IsEqual(ListItem.Property(%s),%s)</visible>
                        </control>''' % (left, top, size, size, k, diffuse, anim, prop, k) for k in AB_ICON_KEYS)


def _ab_tags(active):
    """Up to 4 add-on tags at the right end of the meta line (slot 1 rightmost);
    the meta text is fitted shorter in Python to leave room for them."""
    out = []
    for n in range(1, AB_TAGS + 1):
        left = 904 - 20 - n * (AB_TAG_W + 6) + 6
        out.append(_ab_icons('abs.tag_%d' % n, left + (AB_TAG_W - 34) // 2, 46, 34,
                             'FFFFFFFF' if active else 'A6FFFFFF'))
        for key, color in AB_ADDONS:
            if key in AB_ICON_KEYS:
                continue
            out.append('''
                        <control type="image">
                            <left>%d</left>
                            <top>49</top>
                            <width>%d</width>
                            <height>28</height>
                            <texture border="14">lucent/pill42.png</texture>
                            <colordiffuse>%s</colordiffuse>
                            <visible>String.IsEqual(ListItem.Property(abs.tag_%d),%s)</visible>
                        </control>''' % (left, AB_TAG_W, color if active else 'A6' + color[2:], n, key))
        out.append('''
                        <control type="label">
                            <left>%d</left>
                            <top>49</top>
                            <width>%d</width>
                            <height>28</height>
                            <font>font12</font>
                            <align>center</align>
                            <aligny>center</aligny>
                            <textcolor>FFFFFFFF</textcolor>
                            <label>[B]$INFO[ListItem.Property(abs.tagtxt_%d)][/B]</label>
                            <visible>!%s</visible>
                        </control>''' % (left, AB_TAG_W, n, _ab_has_icon('abs.tag_%d' % n)))
    return ''.join(out)


def ab_card(state):
    """Glass stream card (same as the add-ons' windows) + add-on tags."""
    xml = card(state, {'full_prop': 'abs.never', 'full_label': ''})
    # 4.5.7: no coloured resolution flag and no service icon in Search All
    import re as _re
    xml, a = _re.subn(r'[ \t]*<!-- Resolution flag \(Arctic Fuse 3 colour flags\) -->\n'
                      r'[ \t]*<control type="image">(?:(?!</control>).)*?</control>\n', '', xml, flags=_re.S)
    xml, b = _re.subn(r'[ \t]*<!-- Debrid / service icon \(AB Wizard account manager artwork\) -->\n'
                      r'[ \t]*<control type="image">(?:(?!</control>).)*?</control>\n', '', xml, flags=_re.S)
    assert a == 1 and b == 1, (a, b)
    xml = xml.replace(' + String.IsEmpty(ListItem.Property(lucent.res))', '')
    # 4.7.8: the title line is 740 wide (Python fits it to _TITLE_PX); the
    # FOCUSED card shows the whole title (lucent.title_full), scrolling
    title_head = ('                            <left>168</left>\n'
                  '                            <top>12</top>\n'
                  '                            <width>712</width>\n'
                  '                            <height>40</height>\n')
    assert xml.count(title_head) == 1
    xml = xml.replace(title_head, title_head.replace('<width>712</width>', '<width>740</width>'))
    if state == 'active':
        old = '                            <label>[B]$INFO[ListItem.Property(lucent.title)][/B]</label>'
        assert xml.count(old) == 1
        xml = xml.replace(old, '                            <scroll>true</scroll>\n'
                               '                            <scrollspeed>45</scrollspeed>\n'
                               '                            <label>[B]$INFO[ListItem.Property(lucent.title_full)][/B]</label>')
    marker = '\n                    <!-- Full search -->'
    assert marker in xml
    # 4.6.1: service icon (RD / AD / PM ..., AB Wizard artwork) under the quality;
    #        the plain code pill only when no icon exists for the service
    svc = '''
                        <control type="image">
                            <left>60</left>
                            <top>68</top>
                            <width>44</width>
                            <height>44</height>
                            <aspectratio>keep</aspectratio>
                            <texture>$INFO[ListItem.Property(abs.svcicon)]</texture>
                            <colordiffuse>%(icon)s</colordiffuse>
                            <visible>!String.IsEmpty(ListItem.Property(abs.svcicon))</visible>
                        </control>
                        <control type="image">
                            <left>20</left>
                            <top>70</top>
                            <width>124</width>
                            <height>36</height>
                            <texture border="18">lucent/pill42.png</texture>
                            <colordiffuse>%(pill)s</colordiffuse>
                            <visible>!String.IsEmpty(ListItem.Property(abs.svc)) + String.IsEmpty(ListItem.Property(abs.svcicon))</visible>
                        </control>
                        <control type="label">
                            <left>20</left>
                            <top>70</top>
                            <width>124</width>
                            <height>36</height>
                            <font>font12</font>
                            <align>center</align>
                            <aligny>center</aligny>
                            <textcolor>FFDCE2E7</textcolor>
                            <label>[B]$INFO[ListItem.Property(abs.svc)][/B]</label>
                            <visible>!String.IsEmpty(ListItem.Property(abs.svc)) + String.IsEmpty(ListItem.Property(abs.svcicon))</visible>
                        </control>''' % ({'icon': 'FFFFFFFF', 'pill': '2EFFFFFF'} if state == 'active'
                           else {'icon': 'FFFFFFFF', 'pill': '14FFFFFF'})    # 4.11.2: colour logos at full strength
    return xml.replace(marker, svc + _ab_tags(state == 'active') + marker, 1)


def ab_chip(focused):
    if focused:
        bg = '''
                    <control type="image">
                        <width>246</width>
                        <height>52</height>
                        <texture border="26">lucent/pill60.png</texture>
                        <colordiffuse>FFFFFFFF</colordiffuse>
                    </control>'''
        tc, cc = 'FF%s' % BG, 'FF%s' % BG
    else:
        bg = '''
                    <control type="image">
                        <width>246</width>
                        <height>52</height>
                        <texture border="26">lucent/pill60.png</texture>
                        <colordiffuse>1AFFFFFF</colordiffuse>
                        <visible>String.IsEmpty(ListItem.Property(abs.active))</visible>
                    </control>
                    <!-- 4.8.50: the active filter is an outlined chip, not a filled
                         one - a fill read as a second focus next to the stream list -->
                    <control type="image">
                        <width>246</width>
                        <height>52</height>
                        <texture border="26">lucent/pill60.png</texture>
                        <colordiffuse>1AFFFFFF</colordiffuse>
                        <visible>!String.IsEmpty(ListItem.Property(abs.active))</visible>
                    </control>
                    <control type="image">
                        <width>246</width>
                        <height>52</height>
                        <texture border="26,0,26,0">lucent/pill52_edge.png</texture>
                        <colordiffuse>99FFFFFF</colordiffuse>
                        <visible>!String.IsEmpty(ListItem.Property(abs.active))</visible>
                    </control>'''
        tc, cc = 'FFFFFFFF', 'FFBDC8D1'
    dots = ''.join('''
                    <control type="image">
                        <left>16</left>
                        <top>19</top>
                        <width>14</width>
                        <height>14</height>
                        <texture>lucent/dot.png</texture>
                        <colordiffuse>%s</colordiffuse>
                        <visible>String.IsEqual(ListItem.Property(abs.key),%s) + String.IsEmpty(ListItem.Property(abs.loading))</visible>
                    </control>''' % (color, key) for key, color in AB_ADDONS if key not in AB_ICON_KEYS)
    dots += _ab_icons('abs.key', 12, 10, 32, pulse='!String.IsEmpty(ListItem.Property(abs.loading))')   # 4.12.26: 32 px
    # 4.6.1: service chips carry the service icon in place of the dot
    dots += '''
                    <control type="image">
                        <left>10</left>
                        <top>12</top>
                        <width>28</width>
                        <height>28</height>
                        <aspectratio>keep</aspectratio>
                        <texture>$INFO[ListItem.Property(abs.chipicon)]</texture>
                        <colordiffuse>%s</colordiffuse>
                        <visible>!String.IsEmpty(ListItem.Property(abs.chipicon))</visible>
                    </control>''' % 'FFFFFFFF'   # 4.11.2: colour logo, untinted (was B&W, 4.8.58)
    return '''%(bg)s%(dots)s
                    <control type="image">
                        <left>16</left>
                        <top>19</top>
                        <width>14</width>
                        <height>14</height>
                        <texture>lucent/dot.png</texture>
                        <colordiffuse>%(cc)s</colordiffuse>
                        <animation effect="fade" start="100" end="15" time="500" pulse="true" condition="true">Conditional</animation>
                        <visible>!String.IsEmpty(ListItem.Property(abs.loading)) + !%(hasicon)s</visible>
                    </control>
                    <!-- name and count in separate labels: one mixed label was
                         re-ordered and cut from the start with Kodi in Arabic -->
                    <control type="label">
                        <left>38</left>
                        <width>148</width>
                        <height>52</height>
                        <font>font12</font>
                        <align>left</align>
                        <aligny>center</aligny>
                        <textcolor>%(tc)s</textcolor>
                        <label>[B]$INFO[ListItem.Label][/B]</label>
                        <visible>!%(hasicon)s</visible>
                    </control>
                    <control type="label">
                        <left>186</left>
                        <width>50</width>
                        <height>52</height>
                        <font>font12</font>
                        <align>right</align>
                        <aligny>center</aligny>
                        <textcolor>%(tc)s</textcolor>
                        <label>$INFO[ListItem.Label2]</label>
                    </control>''' % {'bg': bg, 'dots': dots, 'tc': tc, 'cc': cc, 'hasicon': _ab_has_icon('abs.key')}


def ab_panel(expanded, visible, W):
    """Glass stream panel. Default: right half, one column (ids 2400 / 2300 /
    2000 / 2001). Expanded (4.6.7): the whole page under the title, the same
    cards in two columns (ids 2410 / 2310 / 2002 / 2003)."""
    if expanded:
        gl, gt, gw, gh = 12, 112, 1896, 952
        geo = {'what': 'Expanded: streams over the whole page', 'cid': '2310', 'lid': '2002', 'sid': '2003',
               'bid': '2410', 'ltype': 'panel', 'll': 12, 'lw': 1872, 'lh': 740, 'lextra': '', 'sbl': 1880}
    else:
        gl, gt, gw, gh = 880, 56, 984, 968
        geo = {'what': 'Right: glass stream panel', 'cid': '2300', 'lid': '2000', 'sid': '2001',
               'bid': '2400', 'ltype': 'list', 'll': 24, 'lw': 936, 'lh': 768,
               'lextra': '\n                <focusposition>1</focusposition>\n                <movement>2</movement>',
               'sbl': 962}
    iw = gw - 80                                   # inner width (40 px margins)
    bw = 180                                       # Expand / Collapse button
    geo.update({'vis': visible, 'gl': gl, 'gt': gt, 'gw': gw, 'gh': gh, 'iw': iw,
                'bw': bw, 'bl': 40 + iw - bw, 'cntl': 40 + iw - bw - 16 - 320,
                'headw': iw - bw - 16 - 320, 'dotl': 40 + iw // 2 - 16,
                'vlabel': W % 'viewlabel', 'bgc': BG,
                'glass': glass(0, 0, gw, gh), 'head': W % 'heading', 'sub': W % 'subhead',
                'chip': ab_chip(False), 'chipf': ab_chip(True), 'empty': W % 'empty', 'waitmsg': W % 'waitmsg',
                'idle': ab_card('idle'), 'dim': ab_card('dim'), 'active': ab_card('active')})
    xml = '''
        <!-- ============ %(what)s ============ -->
        <control type="group">
            <visible>%(vis)s</visible>
            <animation effect="fade" start="0" end="100" time="350" delay="150">WindowOpen</animation>
            <animation effect="slide" start="120,0" end="0,0" time="400" delay="150" tween="cubic" easing="out">WindowOpen</animation>
            <animation effect="slide" end="200,0" time="300" tween="cubic" easing="in">WindowClose</animation>
            <animation effect="fade" end="0" time="300">WindowClose</animation>
            <left>%(gl)d</left>
            <top>%(gt)d</top>
            <width>%(gw)d</width>
            <height>%(gh)d</height>%(glass)s
            <control type="label">
                <left>40</left>
                <top>26</top>
                <width>%(headw)d</width>
                <height>50</height>
                <font>font27</font>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[%(head)s][/B]</label>
            </control>
            <control type="label">
                <left>%(cntl)d</left>
                <top>26</top>
                <width>320</width>
                <height>50</height>
                <font>font12</font>
                <align>right</align>
                <aligny>center</aligny>
                <textcolor>FFBDC8D1</textcolor>
                <label>$INFO[Container(%(lid)s).CurrentItem]$INFO[Container(%(lid)s).NumItems, / ,]</label>
                <visible>Integer.IsGreater(Container(%(lid)s).NumItems,0)</visible>
            </control>
            <control type="label">
                <left>40</left>
                <top>70</top>
                <width>%(iw)d</width>
                <height>26</height>
                <font>font12</font>
                <textcolor>FF8F9BA6</textcolor>
                <label>$INFO[%(sub)s]</label>
            </control>
            <!-- 4.6.7: Expand / Collapse -->
            <control type="button" id="%(bid)s">
                <left>%(bl)d</left>
                <top>29</top>
                <width>%(bw)d</width>
                <height>44</height>
                <font>font12</font>
                <align>center</align>
                <aligny>center</aligny>
                <textcolor>FFDCE2E7</textcolor>
                <focusedcolor>FF%(bgc)s</focusedcolor>
                <texturenofocus border="22" colordiffuse="1AFFFFFF">lucent/pill44.png</texturenofocus>
                <texturefocus border="22" colordiffuse="FFFFFFFF">lucent/pill44.png</texturefocus>
                <label>[B]$INFO[%(vlabel)s][/B]</label>
                <ondown>%(cid)s</ondown>
            </control>
            <!-- Filter chips: All, each add-on, each quality -->
            <control type="list" id="%(cid)s">
                <left>40</left>
                <top>110</top>
                <width>%(iw)d</width>
                <height>52</height>
                <orientation>horizontal</orientation>
                <scrolltime tween="cubic" easing="out">200</scrolltime>
                <onup>%(bid)s</onup>
                <ondown>%(lid)s</ondown>
                <itemlayout height="52" width="258">%(chip)s
                </itemlayout>
                <focusedlayout height="52" width="258" condition="!Control.HasFocus(%(cid)s)">%(chip)s
                </focusedlayout>
                <focusedlayout height="52" width="258" condition="Control.HasFocus(%(cid)s)">%(chipf)s
                </focusedlayout>
            </control>
            <control type="image">
                <left>40</left>
                <top>178</top>
                <width>%(iw)d</width>
                <height>1</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>1AFFFFFF</colordiffuse>
            </control>
            <control type="scrollbar" id="%(sid)s">
                <left>%(sbl)d</left>
                <top>196</top>
                <width>6</width>
                <height>740</height>
                <onleft>%(lid)s</onleft>
                <showonepage>false</showonepage>
                <orientation>vertical</orientation>
                <texturesliderbackground colordiffuse="14FFFFFF" border="3">lucent/pill6.png</texturesliderbackground>
                <texturesliderbar colordiffuse="4DFFFFFF" border="3">lucent/pill6.png</texturesliderbar>
                <texturesliderbarfocus colordiffuse="FFFFFFFF" border="3">lucent/pill6.png</texturesliderbarfocus>
            </control>
            <control type="%(ltype)s" id="%(lid)s">
                <left>%(ll)d</left>
                <top>184</top>
                <width>%(lw)d</width>
                <height>%(lh)d</height>
                <orientation>vertical</orientation>
                <pagecontrol>%(sid)s</pagecontrol>
                <scrolltime tween="cubic" easing="out">250</scrolltime>%(lextra)s
                <onup>%(cid)s</onup>
                <itemlayout height="148" width="936">%(idle)s
                </itemlayout>
                <focusedlayout height="148" width="936" condition="!Control.HasFocus(%(lid)s)">%(dim)s
                </focusedlayout>
                <focusedlayout height="148" width="936" condition="Control.HasFocus(%(lid)s)">%(active)s
                </focusedlayout>
            </control>
            <!-- Still searching / nothing found -->
            <control type="group">
                <top>420</top>
                <visible>!Integer.IsGreater(Container(%(lid)s).NumItems,0)</visible>
                <control type="image">
                    <left>%(dotl)d</left>
                    <width>32</width>
                    <height>32</height>
                    <texture>lucent/dot.png</texture>
                    <colordiffuse>FFFFFFFF</colordiffuse>
                    <animation effect="fade" start="100" end="15" time="500" pulse="true" condition="true">Conditional</animation>
                    <visible>String.IsEmpty(%(empty)s)</visible>
                </control>
                <control type="label">
                    <left>40</left>
                    <top>56</top>
                    <width>%(iw)d</width>
                    <height>50</height>
                    <font>font27</font>
                    <align>center</align>
                    <aligny>center</aligny>
                    <textcolor>FFDCE2E7</textcolor>
                    <label>$INFO[%(waitmsg)s]</label>
                </control>
            </control>
        </control>''' % geo
    return xml


def ab_source_chip():
    """4.10.6: one chip of the source grid (Fen Light+ style): coloured dot for
    an add-on (pulses while it searches), grey dot for a scraper / site, then
    name and count. Properties: abs.key (add-on key or empty), abs.state
    (searching / done / failed / off), Label = name, Label2 = count."""
    dots = ''.join('''
                    <control type="image">
                        <left>14</left>
                        <top>%(t)d</top>
                        <width>14</width>
                        <height>14</height>
                        <texture>lucent/dot.png</texture>
                        <colordiffuse>%(c)s</colordiffuse>
                        <animation effect="fade" start="100" end="15" time="500" pulse="true" condition="String.IsEqual(ListItem.Property(abs.state),searching)">Conditional</animation>
                        <visible>String.IsEqual(ListItem.Property(abs.key),%(k)s)</visible>
                    </control>''' % {'t': (AB_SRC_H - 14) // 2, 'c': color, 'k': key} for key, color in AB_ADDONS
                   if key not in AB_ICON_KEYS)
    dots += _ab_icons('abs.key', 0, (AB_SRC_H - 34) // 2, 34,
                      pulse='String.IsEqual(ListItem.Property(abs.state),searching)')
    return '''
                <control type="group">
                    <animation effect="fade" start="100" end="40" time="0" condition="String.IsEqual(ListItem.Property(abs.state),off)">Conditional</animation>
%(dots)s
                    <control type="image">
                        <left>14</left>
                        <top>%(t)d</top>
                        <width>14</width>
                        <height>14</height>
                        <texture>lucent/dot.png</texture>
                        <colordiffuse>99FFFFFF</colordiffuse>
                        <animation effect="fade" start="100" end="15" time="500" pulse="true" condition="String.IsEqual(ListItem.Property(abs.state),searching)">Conditional</animation>
                        <visible>String.IsEmpty(ListItem.Property(abs.key))</visible>
                    </control>
                    <!-- name and count in separate labels (Arabic UI re-orders one mixed label) -->
                    <control type="label">
                        <left>36</left>
                        <width>%(nw)d</width>
                        <height>%(h)d</height>
                        <font>font12</font>
                        <aligny>center</aligny>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]$INFO[ListItem.Label][/B]</label>
                        <visible>!%(hasicon)s</visible>
                    </control>
                    <!-- 4.12.28: the add-on name next to its icon -->
                    <control type="label">
                        <left>48</left>
                        <width>%(inw)d</width>
                        <height>%(h)d</height>
                        <font>font12</font>
                        <aligny>center</aligny>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]$INFO[ListItem.Label][/B]</label>
                        <visible>%(hasicon)s</visible>
                    </control>
                    <control type="label">
                        <left>%(cl)d</left>
                        <width>%(cw)d</width>
                        <height>%(h)d</height>
                        <font>font12</font>
                        <align>right</align>
                        <aligny>center</aligny>
                        <textcolor>FFBDC8D1</textcolor>
                        <label>[B]$INFO[ListItem.Label2][/B]</label>
                        <visible>!String.IsEqual(ListItem.Property(abs.state),failed) + !%(hasicon)s</visible>
                    </control>
                    <!-- 4.12.24: add-on with an icon - count at the right edge -->
                    <control type="label">
                        <left>%(cl)d</left>
                        <width>%(cw)d</width>
                        <height>%(h)d</height>
                        <font>font12</font>
                        <align>right</align>
                        <aligny>center</aligny>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]$INFO[ListItem.Label2][/B]</label>
                        <visible>!String.IsEqual(ListItem.Property(abs.state),failed) + %(hasicon)s</visible>
                    </control>
                    <control type="label">
                        <left>%(cl)d</left>
                        <width>%(cw)d</width>
                        <height>%(h)d</height>
                        <font>font12</font>
                        <align>right</align>
                        <aligny>center</aligny>
                        <textcolor>FFE5484D</textcolor>
                        <label>[B]$INFO[ListItem.Label2][/B]</label>
                        <visible>String.IsEqual(ListItem.Property(abs.state),failed)</visible>
                    </control>
                </control>''' % {'w': AB_SRC_W, 'h': AB_SRC_H, 'dots': dots, 't': (AB_SRC_H - 14) // 2,
                               'nw': AB_SRC_W - 36 - AB_SRC_CNT - 12, 'cl': AB_SRC_W - AB_SRC_CNT - 14,
                               'cw': AB_SRC_CNT, 'hasicon': _ab_has_icon('abs.key'),
                               'inw': AB_SRC_W - 48 - AB_SRC_CNT - 24}


def ab_search_window():
    W = 'Window.Property(abs.%s)'
    chip = ab_source_chip()
    slots = ['''
                <!-- 4.10.6: source grid (Fen Light+ style) - one chip per add-on,
                     then one per scraper / site with the streams it found -->
                <control type="panel" id="%(id)d">
                    <width>%(pw)d</width>
                    <height>%(gh)d</height>
                    <orientation>vertical</orientation>
                    <scrolltime>0</scrolltime>
                    <itemlayout width="%(cw)d" height="%(ch)d">%(chip)s
                    </itemlayout>
                    <focusedlayout width="%(cw)d" height="%(ch)d">%(chip)s
                    </focusedlayout>
                </control>''' % {'id': AB_SRC_ID, 'gh': AB_SRC_ROWS * AB_SRC_PITCH, 'cw': AB_SRC_PANEL_W // AB_SRC_COLS, 'pw': AB_SRC_PANEL_W,
                                  'ch': AB_SRC_PITCH, 'chip': chip}]
    status = '''
        <!-- ============ Left: one line per add-on (searching / N streams) ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="200">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>
            <left>96</left>
            <top>%(top)d</top>
            <width>700</width>
            <control type="label">
                <width>700</width>
                <height>40</height>
                <font>font12</font>
                <textcolor>FF8F9BA6</textcolor>
                <label>[B][UPPERCASE]$INFO[%(heading)s][/UPPERCASE][/B]</label>
            </control>
            <control type="label">
                <left>300</left>
                <width>400</width>
                <height>40</height>
                <font>font12</font>
                <align>right</align>
                <textcolor>FFBDC8D1</textcolor>
                <label>[B]$INFO[%(timer)s][/B]</label>
            </control>
            <control type="image">
                <top>44</top>
                <width>700</width>
                <height>1</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>1AFFFFFF</colordiffuse>
            </control>
            <control type="group">
                <top>56</top>%(slots)s
            </control>
        </control>''' % {'heading': W % 'addons_heading', 'timer': W % 'elapsed', 'slots': ''.join(slots), 'top': AB_LIST_TOP}
    # 4.8.25: search done + results -> stream details instead of the add-on list
    done = ('String.IsEqual(Window.Property(abs.empty),true) + '
            'Integer.IsGreater(Container(2000).NumItems,0)')
    sp = 'Container(2000).ListItem.Property(abs.sp_%s)'
    tiles = []
    for n, (key, _x) in enumerate(AB_SPEC_TILES):
        col, row = n % AB_SPEC_COLS, n // AB_SPEC_COLS
        tiles.append('''
                <control type="group">
                    <left>%(l)d</left>
                    <top>%(t)d</top>
                    <width>%(w)d</width>
                    <height>%(h)d</height>
                    <control type="image">
                        <texture border="32">lucent/card.png</texture>
                        <colordiffuse>17FFFFFF</colordiffuse>
                    </control>
                    <control type="image">
                        <texture border="32">lucent/card_edge.png</texture>
                        <colordiffuse>1FFFFFFF</colordiffuse>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>10</top>
                        <width>%(iw)d</width>
                        <height>28</height>
                        <font>font12</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>FF8F9BA6</textcolor>
                        <label>$INFO[Window.Property(abs.sl_%(k)s)]</label>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>38</top>
                        <width>%(iw)d</width>
                        <height>38</height>
                        <font>font27</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>FFFFFFFF</textcolor>
                        <label>[B]$INFO[%(v)s][/B]</label>
                        <visible>!String.IsEmpty(%(v)s) + String.IsEmpty(%(icon)s)</visible>
                    </control>
                    <!-- 4.12.24: the badge (or service logo) in place of the text -->
                    <control type="image">
                        <left>12</left>
                        <top>36</top>
                        <width>%(iw)d</width>
                        <height>42</height>
                        <aspectratio>keep</aspectratio>
                        <texture>$INFO[%(icon)s]</texture>
                        <visible>!String.IsEmpty(%(icon)s)</visible>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>38</top>
                        <width>%(iw)d</width>
                        <height>38</height>
                        <font>font27</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>4DFFFFFF</textcolor>
                        <label>—</label>
                        <visible>String.IsEmpty(%(v)s)</visible>
                    </control>
                    <control type="label">
                        <left>12</left>
                        <top>76</top>
                        <width>%(iw)d</width>
                        <height>28</height>
                        <font>font12</font>
                        <align>center</align>
                        <aligny>center</aligny>
                        <textcolor>FFBDC8D1</textcolor>
                        <label>$INFO[%(sub)s]</label>
                    </control>
                </control>''' % {'l': col * (AB_SPEC_W + AB_SPEC_GAP), 't': row * (AB_SPEC_H + AB_SPEC_GAP),
                                 'w': AB_SPEC_W, 'h': AB_SPEC_H, 'iw': AB_SPEC_W - 24, 'k': key,
                                 'v': sp % key, 'sub': sp % (key + '_sub'), 'icon': sp % (key + '_icon')})
    specs = '''
        <!-- ============ Left, search done: details of the focused stream (4.8.25) ============ -->
        <control type="group">
            <visible>%(done)s</visible>
            <animation effect="fade" start="0" end="100" time="300">Visible</animation>
            <animation effect="fade" start="100" end="0" time="150">Hidden</animation>
            <left>96</left>
            <top>%(top)d</top>
            <width>700</width>
            <control type="label">
                <width>420</width>
                <height>40</height>
                <font>font12</font>
                <textcolor>FF8F9BA6</textcolor>
                <label>[B][UPPERCASE]$INFO[Window.Property(abs.spec_heading)][/UPPERCASE][/B]</label>
            </control>
            <control type="label">
                <left>300</left>
                <width>400</width>
                <height>40</height>
                <font>font12</font>
                <align>right</align>
                <textcolor>FFBDC8D1</textcolor>
                <label>[B]$INFO[%(lang)s][/B]</label>
            </control>
            <control type="image">
                <top>44</top>
                <width>700</width>
                <height>1</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>1AFFFFFF</colordiffuse>
            </control>
            <control type="group">
                <top>56</top>%(tiles)s
            </control>
        </control>''' % {'done': done, 'top': AB_LIST_TOP, 'lang': sp % 'lang', 'tiles': ''.join(tiles)}
    status = status.replace('''
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="200">WindowOpen</animation>''', '''
        <control type="group">
            <visible>!$EXP_DONE</visible>
            <animation effect="fade" start="0" end="100" time="350" delay="200">WindowOpen</animation>''', 1).replace('$EXP_DONE', '[%s]' % done)
    xp = 'String.IsEmpty(%s)' % (W % 'expanded')       # default look
    xx = '!String.IsEmpty(%s)' % (W % 'expanded')      # expanded: streams over the whole page

    def hide_left(xml):
        return '''
        <control type="group">
            <visible>%s</visible>%s
        </control>''' % (xp, xml)
    top_title = '''
        <!-- ============ Expanded: title only, on top ============ -->
        <control type="group">
            <visible>%(xx)s</visible>
            <animation effect="fade" start="0" end="100" time="250">Visible</animation>
            <control type="label">
                <left>40</left>
                <top>28</top>
                <width>1840</width>
                <height>64</height>
                <font>font37</font>
                <aligny>center</aligny>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[%(show)s][/B]$INFO[%(ep)s,   [COLOR FFBDC8D1],[/COLOR]]</label>
            </control>
        </control>''' % {'xx': xx, 'show': 'Window.Property(lucent.show_title)',
                          'ep': 'Window.Property(lucent.ep_code)'}
    # 4.7.20: the episode name sits under the plot (the empty space there); the
    # plot moves up into the episode title's old line. Movies: full-height plot.
    E = 'Window.Property(abs.ep_%s)'
    has_ep = '!String.IsEmpty(%s)' % (E % 'name')
    has_orig = '!String.IsEmpty(%s)' % (E % 'orig')
    episode = '''
        <!-- ============ Left: episode name under the plot ============ -->
        <control type="group">
            <animation effect="fade" start="0" end="100" time="350" delay="180">WindowOpen</animation>
            <animation effect="fade" end="0" time="250">WindowClose</animation>
            <visible>%(has)s</visible>
            <left>96</left>
            <top>%(ep_top)d</top>
            <width>700</width>
            <control type="image">
                <top>4</top>
                <width>4</width>
                <height>66</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>80FFFFFF</colordiffuse>
                <visible>!%(has_orig)s</visible>
            </control>
            <control type="image">
                <top>4</top>
                <width>4</width>
                <height>98</height>
                <texture>lucent/white.png</texture>
                <colordiffuse>80FFFFFF</colordiffuse>
                <visible>%(has_orig)s</visible>
            </control>
            <control type="label">
                <left>20</left>
                <top>0</top>
                <width>680</width>
                <height>30</height>
                <font>font12</font>
                <aligny>center</aligny>
                <textcolor>FF8F9BA6</textcolor>
                <label>[B]$INFO[%(cap)s][/B]</label>
            </control>
            <control type="label">
                <left>20</left>
                <top>32</top>
                <width>680</width>
                <height>42</height>
                <font>font27</font>
                <aligny>center</aligny>
                <textcolor>FFFFFFFF</textcolor>
                <label>[B]$INFO[%(name)s][/B]</label>
            </control>
            <control type="label">
                <left>20</left>
                <top>74</top>
                <width>680</width>
                <height>32</height>
                <font>font12</font>
                <aligny>center</aligny>
                <textcolor>FFBDC8D1</textcolor>
                <label>$INFO[%(orig)s]</label>
                <visible>%(has_orig)s</visible>
            </control>
        </control>''' % {'has': has_ep, 'has_orig': has_orig, 'cap': E % 'caption', 'name': E % 'name',
                         'orig': E % 'orig', 'ep_top': AB_EP_TOP}
    plot = (plot_block('$INFO[Window.Property(lucent.plot)]', top=AB_PLOT_TOP, height=AB_PLOT_H_EP, visible=has_ep,
                       font='font27')
            + plot_block('$INFO[Window.Property(lucent.plot)]', top=AB_PLOT_TOP, height=AB_PLOT_H, visible='!' + has_ep,
                         font='font27'))
    body = ab_panel(False, xp, W) + ab_panel(True, xx, W)
    xml = '''<?xml version="1.0" encoding="UTF-8"?>
<!-- AB Tools - Search All (streams from every add-on). Generated by tools/gen_lucent.py. -->
<!-- Look and textures: Lucent theme for Seren by djdirty60 (github.com/djdirty60/Seren-Thema). -->
<window type="dialog">
    <coordinates>
        <left>0</left>
        <top>0</top>
        <width>1920</width>
        <height>1080</height>
    </coordinates>
    <controls>%(bg)s%(title)s%(plot)s%(episode)s%(status)s%(top)s%(body)s
    </controls>
</window>
''' % {'bg': backdrop('$INFO[Window.Property(lucent.fanart)]'), 'title': hide_left(title_block(ep_title=False, top=AB_TOP, logo_h=AB_LOGO_H,
                                                                          pills_top=AB_LOGO_H + 18)),
       'plot': hide_left(plot), 'episode': hide_left(episode),
       'status': hide_left(status + specs), 'top': top_title, 'body': body}
    return ab_paths(ab_fonts(xml))


# 4.7.7: Search All uses its own font names with fixed sizes (patcher
# _SRCH_FONTS registers them in every fontset of the active skin), so the
# window looks the same whatever sizes the skin gives font12 / 27 / 37.
AB_FONTS = (('font12', 'abk_srch_s'),     # 22 px: cards, rows, chips, info lines
            ('font27', 'abk_srch_m'),     # 26 px: headings, episode title, wait message
            ('font37', 'abk_srch_l'))     # 32 px: show title without clearlogo


def ab_fonts(xml):
    for skin_font, own in AB_FONTS:
        xml = xml.replace('<font>%s</font>' % skin_font, '<font>%s</font>' % own)
    return xml


def ab_paths(xml):
    """Textures straight from resources/lucent/media (AB Tools' own windows)."""
    import re as _re
    return _re.sub(r'(<texture[a-z]*(?: [^>]*)?>)lucent/', lambda m: m.group(1) + AB_MEDIA + 'lucent/', xml)


def build():
    files = {}
    fen_counts = [('4K', 'Window.Property(results_4k)'), ('1080P', 'Window.Property(results_1080p)'),
                  ('720P', 'Window.Property(results_720p)'), ('SD', 'Window.Property(results_sd)'),
                  ('TOTAL', 'Window.Property(results_total)')]
    rl = 'Window(10000).Property(redlight.scrape.%s)'
    rl_counts = [('4K', rl % 'results_4k'), ('1080P', rl % 'results_1080p'), ('720P', rl % 'results_720p'),
                 ('SD', rl % 'results_sd'), ('TOTAL', rl % 'results_total')]
    files['fenlight/sources_results.xml'] = results_window(fen_results_profile('Fen Light'))
    files['fenlight/sources_playback.xml'] = fen_playback('Fen Light', fen_counts, 'Window.Property(percent)',
                                                          'Window.Property(percent)', resume_buttons_fen())
    files['redlight/sources_results.xml'] = results_window(fen_results_profile('Red Light'))
    files['redlight/sources_playback.xml'] = redlight_playback(
        rl_counts, rl % 'percent', 'Window.Property(resume_timeout_percent)')
    files['pov/sources_results.xml'] = results_window(pov_results_profile())
    files['pov/progress_media.xml'] = pov_progress()
    files['pov/contextmenu.xml'] = pov_contextmenu()
    files['shared/lucent_select.xml'] = lucent_select()
    files['umbrella/source_results.xml'] = results_window(umbrella_results_profile('2000', 'results'))
    files['umbrella/uncached_results.xml'] = results_window(umbrella_results_profile('2001', 'uncached', buttons=False))
    files['umbrella/source_progress.xml'] = umbrella_progress()
    ab_path = os.path.join(ROOT, 'resources', 'skins', 'Default', '1080i', 'ab_search.xml')
    with open(ab_path, 'w', encoding='utf-8') as f:
        f.write(ab_search_window())
    # Search All's filter menu: the same themed select window
    with open(os.path.join(os.path.dirname(ab_path), 'lucent_select.xml'), 'w', encoding='utf-8') as f:
        f.write(ab_paths(files['shared/lucent_select.xml']))
    for rel, xml in files.items():
        path = os.path.join(OUT, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(xml)
    return files


if __name__ == '__main__':
    for rel in sorted(build()):
        print(rel)
