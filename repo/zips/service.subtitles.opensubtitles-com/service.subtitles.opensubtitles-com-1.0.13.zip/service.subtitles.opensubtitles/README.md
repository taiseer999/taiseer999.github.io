OpenSubtitles.com KODI add-on
=============================
Search and download subtitles for movies and TV-Series from OpenSubtitles.com. Search in 75 languages, 8.000.000+ subtitles, daily updates.

REST API implementation based on tomburke25 [python-opensubtitles-rest-api](https://github.com/tomburke25/python-opensubtitles-rest-api)                            

v1.0.13 (2026-08-10)
- TV episode searches now ask OpenSubtitles.com what the id supplied by the video add-on actually refers to, instead of assuming. One cached /features lookup says whether it is a show or an episode, and for an episode it also returns the show's id and the real season/episode numbers, so the search is built correctly whatever the add-on reported
- fixed TV episode searches for video add-ons that report the show's IMDb/TMDb id rather than the episode's (Umbrella, POV), which 1.0.11 broke by always treating the player's id as an episode id. Add-ons disagree about what they put in that field and nothing local tells the two apart, so the add-on no longer guesses: it tries the show reading first (id + season/episode), then the episode reading (id on its own), and only falls back to a title search if neither matches. That also stops the title fallback from surfacing subtitles for a different show with a similar name (thanks peno64)

v1.0.12 (2026-08-07)
- Test Connection now works with the credentials as typed: Kodi saves and closes the settings dialog before running the test, so you no longer have to press OK and reopen settings first. The settings reopen once you dismiss the result (thanks rosensama)

v1.0.11 (2026-08-06)
- fixed Test Connection failing with "ModuleNotFoundError: No module named 'resources.lib.osclient'" when another installed add-on ships its own top-level 'resources' package: the settings script now puts its own directory first on the import path (the v1.0.10 rename did not address this)
- fixed TV episode searches returning nothing when only the episode's own IMDb/TMDb id is known: the id is now sent on its own instead of alongside query/season/episode, with an automatic title fallback if it finds nothing (thanks peno64)
- fixed connection and timeout errors crashing with AttributeError instead of reporting the service as unavailable, during login, search and download

v1.0.10 (2026-07-01)
- fixed "ModuleNotFoundError: No module named 'resources.lib.os'" on some devices (notably Android): added package __init__.py files so imports no longer rely on implicit namespace packages, and renamed the internal 'os' package to 'osclient' to stop it shadowing Python's standard-library os module
- fixed subtitle search for TV shows in non-English (localized) libraries by querying the show's original title from the Kodi library instead of the translated on-screen title (thanks notoco)

v1.0.9 (2026-03-01)
- added Test Connection button in settings to verify credentials and view account info
- show specific error message when search or download fails
- added search results caching with configurable duration
- fixed trailing slash on subdirectory folder path

v1.0.8 (2025-10-07)
- performs a query to kodi library if imdb or tmdb ID is missing

v1.0.7 (2025-08-26)
- added IMDB and TMDB collection on files for more accurate search to the API

v1.0.6 (2024-11-29)
- fixed issue with RAR archives 
- handles default chinese language to zh-cn 

v1.0.5 (2024-07-30)
- fixed issue with portuguese file names
- added AI translated filter 

v1.0.4 (2024-01-15)
- Sanitize language query
- Improved sorting
- Improved error messages 
- Improved usage of moviehash 

v1.0.3 (2023-12-18)
- Fixed issue with file path

v1.0.2 (2023-08-28)
- Update user agent header

v1.0.1 (2023-07-28)
- Remove limit of 10 subtitles for the returned values
- Fix Portuguese and Brazilian flags

1.0.0
 Initial version, forked from https://github.com/juokelis/service.subtitles.opensubtitles
 Search fixed and improved