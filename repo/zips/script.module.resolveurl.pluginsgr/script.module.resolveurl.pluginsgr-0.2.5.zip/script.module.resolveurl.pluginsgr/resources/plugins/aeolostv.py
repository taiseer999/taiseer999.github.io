# -*- coding: utf-8 -*-

'''
    PluginsGR Module
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

import json
import re

from resolveurl import common
from resolveurl.lib import helpers
from resolveurl.resolver import ResolveUrl, ResolverError


class AeolosTVResolver(ResolveUrl):

    name = 'aeolostv'
    domains = ['aeolos.tv']
    pattern = r'(?://|\.)(aeolos\.tv)/(live)'

    def get_media_url(self, host, media_id):

        headers = {
            'User-Agent': common.RAND_UA
        }

        web_url = self.get_url(host, media_id)
        res = self.net.http_GET(web_url, headers=headers)

        match = re.search(r'source src="(https://.+\.m3u8)"', res.content)

        if match:
            stream = match.group(1) + helpers.append_headers(headers)
            return stream
        else:
            raise ResolverError('No stream found')

    def get_url(self, host, media_id):

        return self._default_get_url(host, media_id, template='https://{host}/{media_id}')

    @classmethod
    def _is_enabled(cls):
        return True