import sys
from lib import favourites

if (__name__ == '__main__'):
    favourites.MAIN(params=sys.argv)
