'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/taiseer999/taiseer999.github.io/refs/heads/main/Builds.txt'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
