import json
import base64
import xbmc
import xbmcgui
from uservar import notify_url, changelog_dir
from .maintenance import clear_packages_startup
from .addonvar import (setting, setting_set, addon_name, addon_icon, isBase64, headers,
                       dialog, local_string, addon_id, gui_save_default, UPDATE_VERSION,
                       CURRENT_BUILD, CURRENT_VERSION, BUILD_URL,
                       GUI_URL, OPTION2_URL, GUI_UPDATE_VERSION, GUI_UPDATE_MODE)
from .build_install import build_install
from .addons_enable import enable_addons
from .save_data import backup_gui_skin
from . import  notify


def _vtuple(v):
    """'2.10' -> (2, 10). Numeric compare so 2.10 > 2.9 (plain string compare gets this wrong)."""
    parts = []
    for p in str(v or '').strip().split('.'):
        num = ''.join(ch for ch in p if ch.isdigit())
        parts.append(int(num) if num else 0)
    while parts and parts[-1] == 0:
        parts.pop()
    return tuple(parts)


def is_newer(remote, local):
    if not remote:
        return False
    return _vtuple(remote) > _vtuple(local)

class Startup:
    def check_updates(self):
           if CURRENT_BUILD == 'No Build Installed':
               nobuild = dialog.yesnocustom(
                   addon_name,
                   'There is currently no build installed.\nWould you like to install one now?',
                   'Remind Later'
               )
               if nobuild == 1:
                   xbmc.executebuiltin(
                       f'ActivateWindow(10001, "plugin://{addon_id}/?mode=1",return)'
                   )
               elif nobuild == 0:
                   setting_set('buildname', 'No Build')
               return
           if not UPDATE_VERSION:
               return
           # "Ignore" applies to one version only: a newer build re-enables the popup.
           if setting('update_passed') == 'true' and is_newer(UPDATE_VERSION, setting('ignoredupdate') or CURRENT_VERSION):
               setting_set('update_passed', 'false')
           if True:
               if is_newer(UPDATE_VERSION, CURRENT_VERSION) and setting('update_passed') != 'true':
                   update_available = xbmcgui.Dialog().yesnocustom(
                       addon_name,
                       f'{local_string(30047)} {CURRENT_BUILD} {local_string(30048)}\n{local_string(30049)} {CURRENT_VERSION}\n{local_string(30050)} {UPDATE_VERSION}\n{local_string(30051)}',
                       yeslabel='Update Now', nolabel='Not Now', customlabel='View Changelog', defaultbutton=xbmcgui.DLG_YESNO_CUSTOM_BTN
                   )
                   
                   if update_available == 1:
                       name = CURRENT_BUILD
                       name2 = name
                       if BUILD_URL.startswith('https://www.dropbox.com'):
                           url = BUILD_URL.replace('dl=0', 'dl=1')
                       else:
                           url = BUILD_URL
                       build_install(name, name2, UPDATE_VERSION, url) 
                       
                   elif update_available == 0:
                       remind_later = xbmcgui.Dialog().yesno(addon_name, 'Would you like to be reminded later?', yeslabel='Remind Later', nolabel='Ignore', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
                       if remind_later:
                           setting_set('update_passed', 'false')
                       else:
                           setting_set('update_passed', 'true')
                           setting_set('ignoredupdate', str(UPDATE_VERSION))
                       
                   elif update_available == 2:
                       if changelog_dir in ('', 'http://', 'http://CHANGEME/'):
                           xbmcgui.Dialog().notification(addon_name, 'No Changelog to Display!!', addon_icon, 3000)
                           Startup().check_updates()
                       else:
                           message = notify.get_changelog()
                           notify.notification_clog(message)
                       
               elif _vtuple(UPDATE_VERSION) == _vtuple(CURRENT_VERSION) and setting('update_passed') == 'true':
                   setting_set('update_passed', 'false')
                   
    def check_gui_update(self):
        """Pushed no-wipe (shortcuts/menus) update. Fires when Builds.txt
        guiversion= for this box's build is newer than the local guiversion.
        A pending FULL build update wins (it already carries new shortcuts)."""
        if CURRENT_BUILD in ('No Build Installed', 'No Build') or not GUI_UPDATE_VERSION:
            return
        if is_newer(UPDATE_VERSION, CURRENT_VERSION):
            return
        local = setting('guiversion')
        if not local:
            # Box predates this feature: adopt the current number silently,
            # so only the NEXT bump you publish triggers the popup.
            # (Publish the first bump after users have this wizard version.)
            setting_set('guiversion', str(GUI_UPDATE_VERSION))
            return
        if not is_newer(GUI_UPDATE_VERSION, local):
            return
        if setting('ignoredgui') == str(GUI_UPDATE_VERSION):
            return
        url = OPTION2_URL if GUI_UPDATE_MODE == '2' else GUI_URL
        if not url or url in ('http://', 'https://'):
            xbmc.log('AB Wizard: guiversion %s pushed but no gui= url for mode %s' % (GUI_UPDATE_VERSION, GUI_UPDATE_MODE), xbmc.LOGWARNING)
            return
        if url.startswith('https://www.dropbox.com'):
            url = url.replace('dl=0', 'dl=1')
        msg = local_string(30121)
        if GUI_UPDATE_MODE == '2':
            msg += '\n' + local_string(30122)
        choice = xbmcgui.Dialog().yesnocustom(
            local_string(30120), msg,
            customlabel=local_string(30125),
            nolabel=local_string(30124),
            yeslabel=local_string(30123),
            defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
        )
        if choice == 1:
            from .build_install import patch_gui, patch_gui_no_wipe
            if GUI_UPDATE_MODE == '2':
                patch_gui_no_wipe(url, confirm=False)
            else:
                patch_gui(url, confirm=False)
        elif choice == 2:
            setting_set('ignoredgui', str(GUI_UPDATE_VERSION))

    def save_menu(self):
        choices = []
        preselect = []
        if setting('savedata') == 'true':
            choices.append('[I]Trakt & Debrid Data[/I][TABS]5[/TABS][Preselected]')
            preselect.append(0)
        else:
            choices.append('Trakt & Debrid Data')
        if setting('saveyoutube') == 'true':
            choices.append('[I]YouTube API Keys[/I][TABS]5[/TABS][Preselected]')
            preselect.append(1)
        else:
            choices.append('YouTube API Keys')
        if setting('saveadvanced') == 'true':
            choices.append('[I]Advanced Settings[/I][TABS]5[/TABS][Preselected]')
            preselect.append(2)
        else:
            choices.append('Advanced Settings')
        if setting('savegui') == 'true':
            choices.append('[I]GUI Settings[/I][TABS]6[/TABS][Preselected]')
            preselect.append(3)
        else:
            choices.append('GUI Settings')
        if setting('savefavs') == 'true':
            choices.append('[I]Favourites[/I][TABS]7[/TABS][Preselected]')
            preselect.append(4)
        else:
            choices.append('Favourites')
        if setting('savesources') == 'true':
            choices.append('[I]Sources[/I][TABS]7[/TABS][Preselected]')
            preselect.append(5)
        else:
            choices.append('Sources')
        save_select = dialog.multiselect(
            f'{addon_name} - {local_string(30052)}',
            choices,
            preselect=preselect
        )
        # Select Save Items
        if save_select is None:
            return
        save_items = [choices[index] for index in save_select]
                
        if 'Trakt & Debrid Data' in save_items:
            setting_set('savedata', 'true')
        elif '[I]Trakt & Debrid Data[/I][TABS]5[/TABS][Preselected]' in save_items:
            setting_set('savedata', 'true')
        else:
            setting_set('savedata', 'false')
            
        if 'YouTube API Keys' in save_items:
            setting_set('saveyoutube', 'true')
        elif '[I]YouTube API Keys[/I][TABS]5[/TABS][Preselected]' in save_items:
            setting_set('saveyoutube', 'true')
        else:
            setting_set('saveyoutube', 'false')

        if 'Advanced Settings' in save_items:
            setting_set('saveadvanced', 'true')
        elif '[I]Advanced Settings[/I][TABS]5[/TABS][Preselected]' in save_items:
            setting_set('saveadvanced', 'true')
        else:
            setting_set('saveadvanced', 'false')

        if 'GUI Settings' in save_items:
            setting_set('savegui', 'true')
        elif '[I]GUI Settings[/I][TABS]6[/TABS][Preselected]' in save_items:
            setting_set('savegui', 'true')
        else:
            setting_set('savegui', 'false')
            
        if 'Favourites' in save_items:
            setting_set('savefavs', 'true')
        elif '[I]Favourites[/I][TABS]7[/TABS][Preselected]' in save_items:
            setting_set('savefavs', 'true')
        else:
            setting_set('savefavs', 'false')
            
        if 'Sources' in save_items:
            setting_set('savesources', 'true')
        elif '[I]Sources[/I][TABS]7[/TABS][Preselected]' in save_items:
            setting_set('savesources', 'true')
        else:
            setting_set('savesources', 'false')
  
        setting_set('firstrunSave', 'true')

    def notify_check(self):
        if notify_url in ('http://CHANGEME', 'http://slamiousproject.com/wzrd/notify19.txt', '', 'http://'):
            return
        
        info = notify.get_notify()
        if not info:
            return
        current_notify = int(setting('notifyversion'))
        notify_version = info[0]
        message = info[1]

        # Pop the notification whenever a new build update is available,
        # once per new build version.
        update_available = is_newer(UPDATE_VERSION, CURRENT_VERSION)
        update_not_announced = update_available and setting('notifiedupdate') != str(UPDATE_VERSION)

        if setting('firstrunNotify') != 'true' or notify_version > current_notify or update_not_announced:
            notify.notification(message)
            setting_set('firstrunNotify', 'true')
            setting_set('notifyversion', str(notify_version))
            if update_available:
                setting_set('notifiedupdate', str(UPDATE_VERSION))
    
    def run_startup(self):
        # Make Arabic readable in the wizard menu (and every skin surface) by
        # installing an Arabic-capable global fallback font. Best-effort and
        # fully fenced - must never stop startup. Takes effect next Kodi start.
        try:
            from .font_fallback import install as _install_fallback_font
            _install_fallback_font()
        except Exception:
            pass
        # Save-items multiselect no longer auto-pops at startup;
        # the same options remain available in the addon Settings.
        if setting('firstrun') == 'true':
            enable_addons()
            backup_gui_skin(gui_save_default)
            setting_set('firstrun', 'false')
        else:
            clear_packages_startup()
            try:
                from .maint_tools import auto_clean
                auto_clean()
            except Exception as e:
                xbmc.log('Auto Clean failed: %s' % e, xbmc.LOGERROR)
            xbmc.sleep(1000)
            try:
                self.notify_check()
            except Exception as e:
                xbmc.log('AB Wizard: notify check failed: %s' % e, xbmc.LOGERROR)
            xbmc.sleep(3000)  # Delay Build Update Notification
            self.check_updates()
            try:
                self.check_gui_update()
            except Exception as e:
                xbmc.log('AB Wizard: gui update check failed: %s' % e, xbmc.LOGERROR)
