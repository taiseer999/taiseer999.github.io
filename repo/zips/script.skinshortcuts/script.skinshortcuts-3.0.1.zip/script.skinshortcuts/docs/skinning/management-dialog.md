# Management Dialog

The management dialog (`script-skinshortcuts.xml`) provides the UI for editing menus.

---

## Table of Contents

* [Overview](#overview)
* [Dialog XML](#dialog-xml)
* [Control IDs](#control-ids)
* [Window Properties](#window-properties)
* [ListItem Properties](#listitem-properties)
* [Subdialogs](#subdialogs)
* [Script Commands](#script-commands)

---

## Overview

The script opens a WindowXMLDialog from your skin's `script-skinshortcuts.xml`. You design the layout and controls; the script handles the logic.

---

## Dialog XML

Create `script-skinshortcuts.xml` in your skin's XML folder:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<window>
  <defaultcontrol always="true">211</defaultcontrol>

  <controls>
    <!-- Menu items list -->
    <control type="list" id="211">
      <itemlayout>
        <control type="image">
          <texture>$INFO[ListItem.Icon]</texture>
        </control>
        <control type="label">
          <label>$INFO[ListItem.Label]</label>
        </control>
      </itemlayout>
      <focusedlayout>...</focusedlayout>
    </control>

    <!-- Action buttons -->
    <control type="button" id="301">
      <label>$ADDON[script.skinshortcuts 32000]</label>  <!-- Add -->
    </control>
    <control type="button" id="302">
      <label>$ADDON[script.skinshortcuts 32001]</label>  <!-- Delete -->
    </control>
    <control type="button" id="303">
      <label>$ADDON[script.skinshortcuts 32002]</label>  <!-- Move Up -->
    </control>
    <control type="button" id="304">
      <label>$ADDON[script.skinshortcuts 32003]</label>  <!-- Move Down -->
    </control>
    <control type="button" id="305">
      <label>$ADDON[script.skinshortcuts 32025]</label>  <!-- Set label -->
    </control>
    <control type="button" id="306">
      <label>$LOCALIZE[19284]</label>  <!-- Choose icon -->
    </control>
    <control type="button" id="307">
      <label>$ADDON[script.skinshortcuts 32027]</label>  <!-- Change action -->
    </control>

    <!-- Optional buttons -->
    <control type="button" id="311">
      <label>$ADDON[script.skinshortcuts 32028]</label>  <!-- Restore menu items -->
    </control>
    <control type="button" id="312">
      <label>$ADDON[script.skinshortcuts 32104]</label>  <!-- Reset to skin defaults -->
    </control>
    <control type="button" id="313">
      <label>$ADDON[script.skinshortcuts 32117]</label>  <!-- Disable shortcut -->
    </control>
    <control type="button" id="401">
      <label>$ADDON[script.skinshortcuts 32043]</label>  <!-- Choose shortcut category -->
    </control>
    <control type="button" id="405">
      <label>$ADDON[script.skinshortcuts 32072]</label>  <!-- Customize Submenu -->
    </control>
  </controls>
</window>
```

---

## Control IDs

### Required Controls

| ID | Function |
|----|----------|
| `211` | Menu items list (required) |
| `212` | Subdialog context list (optional) |

Control 212 is a single-item list that mirrors the currently selected item from 211. Use it in subdialogs to read item properties without conflicting with the main list:

```xml
<!-- In subdialog mode, read from 212 instead of 211 -->
<label>$INFO[Container(212).ListItem.Property(widgetLabel)]</label>
```

### Built-in Buttons

| ID | Function |
|----|----------|
| `301` | Add new item |
| `302` | Delete selected item |
| `303` | Move item up |
| `304` | Move item down |
| `305` | Change label (keyboard input) |
| `306` | Change icon (file browser) |
| `307` | Change action (keyboard input) |
| `311` | Restore a deleted item |
| `312` | Reset current item to default |
| `313` | Toggle disabled state |
| `401` | Choose shortcut from groupings |
| `405` | Edit submenu |

### Custom Buttons

All property buttons (widget, background, custom options) are configured in `properties.xml`. Common conventions:

| ID Range | Typical Use |
|----------|-------------|
| `309` | Widget picker |
| `310` | Background picker |
| `350-399` | Custom property buttons |
| `800+` | Subdialog triggers (via `menus.xml`) |

These aren't built-in. Define button mappings in your `properties.xml`.

> **See also:** [Properties](properties.md#button-mappings) for configuring property buttons

---

## Window Properties

Properties set on the dialog window for conditional visibility:

### Menu Context

| Property | Description |
|----------|-------------|
| `menuname` | Current menu ID (e.g., `mainmenu`) |
| `disableWidgets` | `true` if disabled (empty if allowed) |
| `disableBackgrounds` | `true` if disabled (empty if allowed) |
| `disableSubmenus` | `true` if disabled (empty if allowed) |
| `skinshortcuts-menutype` | Menu type: `widgets` for a widget menu, `submenu` for a submenu, empty for a normal menu |
| `skinshortcuts-hasdeleted` | `true` if deleted items exist |
| `additionalDialog` | `true` while a child management dialog is stacked on top of this one (submenu editing or a subdialog/onclose mode); empty once the child closes |

### Subdialog Mode

These properties are set on **both the dialog window and the Home window**. Read via `Window(home).Property(...)` if visibility needs to remain correct when a native dialog (DialogSelect, keyboard, file browser) is on top of the management dialog; otherwise either form works.

| Property | Description |
|----------|-------------|
| `skinshortcuts-dialog` | Current subdialog mode (empty for main) |
| `skinshortcuts-suffix` | Current property suffix (e.g., `.2`) |

### Usage

```xml
<!-- Menu context properties (dialog window only; read with Window.Property) -->
<!-- Show widget button only if widgets are allowed (not disabled) -->
<visible>String.IsEmpty(Window.Property(disableWidgets))</visible>

<!-- Subdialog properties (set on both; Window(home) recommended for cross-window visibility) -->
<visible>String.IsEmpty(Window(home).Property(skinshortcuts-dialog))</visible>
<visible>String.IsEqual(Window(home).Property(skinshortcuts-dialog),widget1)</visible>
<visible>String.IsEqual(Window(home).Property(skinshortcuts-suffix),.2)</visible>
```

---

## ListItem Properties

Properties available on items in the menu list (control 211):

### Core Properties

| Property | Description |
|----------|-------------|
| `ListItem.Label` | Display label |
| `ListItem.Label2` | Primary action |
| `ListItem.Icon` | Icon path |
| `ListItem.Property(name)` | Item identifier |
| `ListItem.Property(action)` | Full action string |
| `ListItem.Property(originalAction)` | Original action string before any override is applied |
| `ListItem.Property(path)` | Bare content path |
| `ListItem.Property(skinshortcuts-disabled)` | `True` or `False` |

### Widget Properties

| Property | Description |
|----------|-------------|
| `ListItem.Property(widget)` | Widget name |
| `ListItem.Property(widgetLabel)` | Widget display label |
| `ListItem.Property(widgetPath)` | Widget content path |
| `ListItem.Property(widgetType)` | Widget content type |
| `ListItem.Property(widgetTarget)` | Widget target window |
| `ListItem.Property(widgetSource)` | Widget source type (e.g., `library`, `playlist`, `addon`) |

### Background Properties

| Property | Description |
|----------|-------------|
| `ListItem.Property(background)` | Background name |
| `ListItem.Property(backgroundLabel)` | Background display label |
| `ListItem.Property(backgroundPath)` | Background image path |

### Submenu Properties

| Property | Description |
|----------|-------------|
| `ListItem.Property(hasSubmenu)` | `true` if item has submenu |
| `ListItem.Property(submenu)` | Submenu name |

### Status Properties

| Property | Description |
|----------|-------------|
| `ListItem.Property(isResettable)` | `true` if modified from default |
| `ListItem.Property(skinshortcuts-isRequired)` | `True` if item cannot be deleted/disabled |
| `ListItem.Property(skinshortcuts-isProtected)` | `True` if item has protection rules |

### Custom Properties

Any property defined in `properties.xml`:

```xml
<visible>!String.IsEmpty(Container(211).ListItem.Property(widgetStyle))</visible>
<label>$INFO[Container(211).ListItem.Property(widgetStyleLabel)]</label>
```

Properties with options also get a `{name}Label` property with the resolved label.

> **See also:** [Built-in Properties](builtin-properties.md) for properties in generated includes

---

## Subdialogs

Subdialogs support multi-widget editing by opening the same dialog with a different mode.

### Configuration

In `menus.xml`:

```xml
<dialogs>
  <subdialog buttonID="800" mode="widget1" setfocus="309" />
  <subdialog buttonID="801" mode="widget2" setfocus="309" suffix=".2">
    <onclose condition="widgetType.2=custom" action="menu" menu="{item}.customwidget.2" />
  </subdialog>
  <!-- Direct menu opening (no mode change) -->
  <subdialog buttonID="850" menu="{customWidget}" suffix=".2" />
</dialogs>
```

**Direct menu opening:** When `menu` is set without `mode`, the menu opens directly without changing dialog mode. Useful for custom widget editing buttons that don't need a full subdialog.

### Dialog Behavior

When button 800 is clicked:

1. `Window.Property(skinshortcuts-dialog)` = `widget1`
2. Focus moves to control 309
3. UI updates to show widget 1 controls

When button 801 is clicked:

1. `Window.Property(skinshortcuts-dialog)` = `widget2`
2. `Window.Property(skinshortcuts-suffix)` = `.2`
3. Property reads/writes use `.2` suffix (e.g., `widgetPath.2`)

### Skin Layout

Use visibility conditions to show different controls:

```xml
<!-- Main dialog controls -->
<control type="group">
  <visible>String.IsEmpty(Window.Property(skinshortcuts-dialog))</visible>
  <!-- Main menu editing controls -->
</control>

<!-- Widget 1 subdialog controls -->
<control type="group">
  <visible>String.IsEqual(Window.Property(skinshortcuts-dialog),widget1)</visible>
  <!-- Widget editing controls -->
</control>

<!-- Widget 2 subdialog controls -->
<control type="group">
  <visible>String.IsEqual(Window.Property(skinshortcuts-dialog),widget2)</visible>
  <!-- Widget editing controls (same layout, different suffix) -->
</control>
```

### OnClose Actions

Execute actions when subdialog closes:

```xml
<onclose condition="widgetType.2=custom" action="menu" menu="{item}.customwidget.2" />
```

* `{item}` is replaced with current item name
* Opens item editor for custom widget menu

---

## Script Commands

### Open Management Dialog

```xml
<onclick>RunScript(script.skinshortcuts,type=manage,menu=mainmenu)</onclick>
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `type` | Yes | `manage` |
| `menu` | No | Menu ID to edit (defaults to `mainmenu`) |
| `path` | No | Custom shortcuts path |

### Build Includes

```xml
<onclick>RunScript(script.skinshortcuts,type=buildxml)</onclick>
<onclick>RunScript(script.skinshortcuts,type=buildxml,force=true)</onclick>
```

| Parameter | Description |
|-----------|-------------|
| `type` | `buildxml` |
| `force` | `true` to force rebuild |
| `path` | Custom shortcuts path |
| `output` | Custom output path |

### Reset All

```xml
<onclick>RunScript(script.skinshortcuts,type=resetall)</onclick>
```

Prompts for confirmation, then deletes all userdata (menus and views) and rebuilds.

### Reset Menus Only

```xml
<onclick>RunScript(script.skinshortcuts,type=resetmenus)</onclick>
```

Prompts for confirmation, resets all menus to defaults but preserves view selections.

### Reset Views Only

```xml
<onclick>RunScript(script.skinshortcuts,type=resetviews)</onclick>
```

Prompts for confirmation, resets all view selections to defaults but preserves menu customizations.

### Reset Single Menu

```xml
<onclick>RunScript(script.skinshortcuts,type=reset,menu=mainmenu)</onclick>
```

Prompts for confirmation, then resets a specific menu to skin defaults.

| Parameter | Description |
|-----------|-------------|
| `type` | `reset` |
| `menu` | Menu ID to reset |
| `submenus` | `true` to also reset all submenus |
| `path` | Custom shortcuts path |

### Reset Menu and Submenus

```xml
<onclick>RunScript(script.skinshortcuts,type=reset,menu=mainmenu,submenus=true)</onclick>
```

Prompts for confirmation, then resets a menu and all submenus referenced by item `submenu` properties (recursive).

### Reset All Submenus

```xml
<onclick>RunScript(script.skinshortcuts,type=resetsubmenus)</onclick>
```

Prompts for confirmation, then resets all submenus (menus defined with `<submenu>` tag) without affecting top-level menus.

### Clear Custom Widget

```xml
<onclick>RunScript(script.skinshortcuts,type=clear,menu=mainmenu,item=movies,property=widget)</onclick>
<onclick>RunScript(script.skinshortcuts,type=clear,menu=mainmenu,item=movies,suffix=.2,property=widget)</onclick>
```

| Parameter | Description |
|-----------|-------------|
| `type` | `clear` |
| `menu` | Parent menu ID (e.g., `mainmenu`) |
| `item` | Item ID to clear custom widget from |
| `suffix` | Widget slot suffix (e.g., `.2` for second slot) |
| `property` | Property prefix to clear (e.g., `widget`) |

### Window Property Pass-Through

Paired `prop=NAME,value=VALUE` arguments work with any entry type (`type=manage`, `type=skinstring`, or any other). Each pair is set on the Home window when the script starts and cleared when it exits. Useful for driving picker visibility conditions (e.g., flat groups) without manual `SetProperty`/`ClearProperty` calls in skin XML.

```xml
<onclick>RunScript(script.skinshortcuts,type=skinstring,prop=widgetContext,value=spotlight,skinPath=home.widget.path,skinLabel=home.widget.label)</onclick>
```

While the script runs, `Window(Home).Property(widgetContext)` reads as `spotlight`. After the picker closes (or the script errors out), the property is cleared automatically. Conditions like `String.IsEqual(Window(Home).Property(widgetContext),spotlight)` on widgets, groups, or backgrounds will match while the picker is open.

Multiple pairs are applied in order:

```xml
<onclick>RunScript(script.skinshortcuts,type=manage,menu=mainmenu,prop=widgetContext,value=spotlight,prop=widgetSlot,value=1)</onclick>
```

A `prop=` without a matching `value=` defaults to `true` (useful for boolean flags that conditions check via `Skin.HasSetting`-style truthiness):

```xml
<onclick>RunScript(script.skinshortcuts,type=manage,menu=mainmenu,prop=spotlightContext)</onclick>
```

| Argument | Behavior |
|----------|----------|
| `prop=<name>` paired with `value=<value>` | Set `<name>=<value>` on Home for the script's lifetime; cleared on exit |
| `prop=<name>` alone | Set `<name>=true` on Home for the script's lifetime; cleared on exit |

Values containing `&` need URL escaping (`%26`) because the arg string is parsed as a query string.

---

## Dialog Flow

1. User clicks "Edit Menu" button in skin
2. Script opens `script-skinshortcuts.xml`
3. List control 211 populates with menu items
4. User edits items using control buttons
5. User presses back/close
6. Script saves changes and closes dialog
7. Script rebuilds includes if changes were made
8. Skin reloads to apply new includes

---

[↑ Top](#management-dialog) · [Skinning Docs](index.md)
