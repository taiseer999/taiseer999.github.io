# loaders/menu.py

**Path:** `resources/lib/skinshortcuts/loaders/menu.py`
**Purpose:** Load menus, groupings, and related configuration from menus.xml.

***

## Overview

Primary loader for menu configuration. Parses menus.xml containing menu definitions, shortcut groupings, icon sources, subdialog definitions, and action overrides.

***

## Public Functions

### load_menus(path) → MenuConfig

Load complete menu configuration. Returns MenuConfig containing:
- `menus` - All Menu objects
- `groupings` - Shortcut picker groups
- `icon_sources` - Icon picker sources
- `subdialogs` - Subdialog definitions
- `action_overrides` - Action replacement rules
- `icon_overrides` - DefaultX.png -> override-path map from `<overrides><icons>`
- `show_context_menu` - Context menu visibility

### load_groupings(path, menu_id="") → list[ShortcutGroup]

Load shortcut groupings for the picker. If `menu_id` is provided, a `<groupings menu="...">` element takes priority over the default.

***

## Internal Parsers

| Function | Parses |
|----------|--------|
| `_parse_menus` | `<menu>` and `<submenu>` elements |
| `_parse_menu` | Single menu with items, defaults, allow, controltype, startid |
| `_parse_item` | Menu item with label, actions, properties, protection, includes |
| `_parse_defaults` | Menu-wide default properties, actions, includes |
| `_parse_allow` | Feature toggles (widgets, backgrounds, submenus) |
| `_parse_shortcut_groupings` | `<groupings>` element with groups/shortcuts/content/inputs |
| `_parse_shortcut_group` | Group with nested groups, shortcuts, content, inputs |
| `_parse_shortcut` | Shortcut in action or browse mode |
| `_parse_input` | User input prompt element |
| `_parse_icons` | Icon sources (simple path or advanced with conditions) |
| `_parse_dialogs` | Subdialog definitions |
| `_parse_onclose` | `<onclose>` actions inside a `<subdialog>` |
| `_parse_overrides` | Action replacement rules |
| `_parse_icon_overrides` | `<overrides><icons>` icon substitution map |
| `_parse_context_menu` | `<contextmenu>` show/hide setting |

***

## Special Handling

### Multiple Visibility Elements

When an item has multiple `<visible>` child elements, they are combined with ` + ` (AND operator in Kodi):

```xml
<!-- Input -->
<visible>System.CanPowerDown</visible>
<visible>!System.HasAlarm(shutdowntimer)</visible>

<!-- Result: item.visible = "System.CanPowerDown + !System.HasAlarm(shutdowntimer)" -->
```

### Include Reference Positioning

`<skinshortcuts include="...">` elements in items and defaults track position relative to `<action>` elements:

- Before any action → `position = "before-onclick"`
- After any action → `position = "after-onclick"`

***

## XML Reference

See [skinning/menus.md](../../skinning/menus.md) for full XML documentation.
